import com.example.tray.ViewModels.CallBackFunctions;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000 \u000e2\u00020\u0001:\u0001\u000eB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\n\u001a\u0004\u0018\u00010\u0005J\u0010\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0005R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t¨\u0006\u000f"},
   d2 = {"LSingletonClass;", "", "<init>", "()V", "callBackFunctions", "Lcom/example/tray/ViewModels/CallBackFunctions;", "getCallBackFunctions", "()Lcom/example/tray/ViewModels/CallBackFunctions;", "setCallBackFunctions", "(Lcom/example/tray/ViewModels/CallBackFunctions;)V", "getYourObject", "setYourObject", "", "yourObject", "Companion", "Tray_release"}
)
public final class SingletonClass {
   @NotNull
   public static final SingletonClass.Companion Companion = new SingletonClass.Companion((DefaultConstructorMarker)null);
   @Nullable
   private CallBackFunctions callBackFunctions;
   @Nullable
   private static volatile SingletonClass instance;

   private SingletonClass() {
   }

   @Nullable
   public final CallBackFunctions getCallBackFunctions() {
      return this.callBackFunctions;
   }

   public final void setCallBackFunctions(@Nullable CallBackFunctions var1) {
      this.callBackFunctions = var1;
   }

   @Nullable
   public final CallBackFunctions getYourObject() {
      return this.callBackFunctions;
   }

   public final void setYourObject(@Nullable CallBackFunctions yourObject) {
      this.callBackFunctions = yourObject;
   }

   // $FF: synthetic method
   public static final SingletonClass access$getInstance$cp() {
      return instance;
   }

   // $FF: synthetic method
   public static final void access$setInstance$cp(SingletonClass var0) {
      instance = var0;
   }

   // $FF: synthetic method
   public SingletonClass(DefaultConstructorMarker $constructor_marker) {
      this();
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0006\u001a\u00020\u0005R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"LSingletonClass$Companion;", "", "<init>", "()V", "instance", "LSingletonClass;", "getInstance", "Tray_release"}
   )
   @SourceDebugExtension({"SMAP\nSingletonClass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SingletonClass.kt\nSingletonClass$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,35:1\n1#2:36\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final SingletonClass getInstance() {
         // $FF: Couldn't be decompiled
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
