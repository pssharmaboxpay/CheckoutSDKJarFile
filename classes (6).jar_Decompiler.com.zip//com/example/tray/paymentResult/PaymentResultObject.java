package com.example.tray.paymentResult;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\u0005¨\u0006\n"},
   d2 = {"Lcom/example/tray/paymentResult/PaymentResultObject;", "", "resultFetched", "", "<init>", "(Ljava/lang/String;)V", "status", "getStatus", "()Ljava/lang/String;", "setStatus", "Tray_release"}
)
public final class PaymentResultObject {
   @NotNull
   private final String resultFetched;
   @Nullable
   private String status;

   public PaymentResultObject(@NotNull String resultFetched) {
      Intrinsics.checkNotNullParameter(resultFetched, "resultFetched");
      super();
      this.resultFetched = resultFetched;
      this.status = this.resultFetched;
   }

   @Nullable
   public final String getStatus() {
      return this.status;
   }

   public final void setStatus(@Nullable String var1) {
      this.status = var1;
   }
}
