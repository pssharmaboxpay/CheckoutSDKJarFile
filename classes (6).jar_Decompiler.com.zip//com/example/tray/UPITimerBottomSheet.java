package com.example.tray;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.ViewModels.CallBackFunctions;
import com.example.tray.ViewModels.SharedViewModel;
import com.example.tray.databinding.FragmentUPITimerBottomSheetBinding;
import com.example.tray.paymentResult.PaymentResultObject;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.Arrays;
import kotlin.Function;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0000\u0018\u0000 92\u00020\u00012\u00020\u0002:\u00019B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0012\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016J\u0006\u0010#\u001a\u00020 J\b\u0010$\u001a\u00020 H\u0016J\u0012\u0010%\u001a\u00020&2\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016J&\u0010'\u001a\u0004\u0018\u00010(2\u0006\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010,2\b\u0010!\u001a\u0004\u0018\u00010\"H\u0016J\b\u0010-\u001a\u00020 H\u0002J\b\u0010.\u001a\u00020 H\u0002J\b\u0010/\u001a\u00020 H\u0002J\u0010\u00100\u001a\u00020 2\u0006\u00101\u001a\u000202H\u0016J\u000e\u00103\u001a\u00020 2\u0006\u00104\u001a\u000205J\u0010\u00106\u001a\u00020 2\u0006\u00107\u001a\u00020\rH\u0002J\b\u00108\u001a\u00020 H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010\u0019\u001a\u00020\u001a8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001b\u0010\u001c¨\u0006:"},
   d2 = {"Lcom/example/tray/UPITimerBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "Lcom/example/tray/CancelConfirmationBottomSheet$ConfirmationListener;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentUPITimerBottomSheetBinding;", "countdownTimer", "Landroid/os/CountDownTimer;", "countdownTimerForAPI", "requestQueue", "Lcom/android/volley/RequestQueue;", "token", "", "successScreenFullReferencePath", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "virtualPaymentAddress", "isBottomSheetShown", "", "()Z", "setBottomSheetShown", "(Z)V", "Base_Session_API_URL", "sharedViewModel", "Lcom/example/tray/ViewModels/SharedViewModel;", "getSharedViewModel", "()Lcom/example/tray/ViewModels/SharedViewModel;", "sharedViewModel$delegate", "Lkotlin/Lazy;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "explicitDismiss", "onResume", "onCreateDialog", "Landroid/app/Dialog;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "fetchTransactionDetailsFromSharedPreferences", "startTimer", "startTimerForAPICalls", "onDismiss", "dialog", "Landroid/content/DialogInterface;", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "fetchStatusAndReason", "url", "onConfirmation", "Companion", "Tray_release"}
)
@SourceDebugExtension({"SMAP\nUPITimerBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 UPITimerBottomSheet.kt\ncom/example/tray/UPITimerBottomSheet\n+ 2 FragmentViewModelLazy.kt\nandroidx/fragment/app/FragmentViewModelLazyKt\n*L\n1#1,377:1\n77#2,6:378\n*S KotlinDebug\n*F\n+ 1 UPITimerBottomSheet.kt\ncom/example/tray/UPITimerBottomSheet\n*L\n47#1:378,6\n*E\n"})
public final class UPITimerBottomSheet extends BottomSheetDialogFragment implements CancelConfirmationBottomSheet.ConfirmationListener {
   @NotNull
   public static final UPITimerBottomSheet.Companion Companion = new UPITimerBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentUPITimerBottomSheetBinding binding;
   private CountDownTimer countdownTimer;
   private CountDownTimer countdownTimerForAPI;
   private RequestQueue requestQueue;
   @Nullable
   private String token;
   @Nullable
   private String successScreenFullReferencePath;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @Nullable
   private String virtualPaymentAddress;
   private boolean isBottomSheetShown;
   private String Base_Session_API_URL;
   @NotNull
   private final Lazy sharedViewModel$delegate;

   public UPITimerBottomSheet() {
      Fragment $this$activityViewModels_u24default$iv = (Fragment)this;
      Function0 factoryProducer$iv = null;
      int $i$f$activityViewModels = false;
      this.sharedViewModel$delegate = FragmentViewModelLazyKt.createViewModelLazy($this$activityViewModels_u24default$iv, Reflection.getOrCreateKotlinClass(SharedViewModel.class), (Function0)(new UPITimerBottomSheet$special$$inlined$activityViewModels$default$1($this$activityViewModels_u24default$iv)), (Function0)(new UPITimerBottomSheet$special$$inlined$activityViewModels$default$2($this$activityViewModels_u24default$iv)));
   }

   public final boolean isBottomSheetShown() {
      return this.isBottomSheetShown;
   }

   public final void setBottomSheetShown(boolean var1) {
      this.isBottomSheetShown = var1;
   }

   @NotNull
   public final SharedViewModel getSharedViewModel() {
      Lazy var1 = this.sharedViewModel$delegate;
      return (SharedViewModel)var1.getValue();
   }

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.requestQueue = Volley.newRequestQueue(this.requireContext());
      Bundle var10000 = this.getArguments();
      if (var10000 != null) {
         Bundle it = var10000;
         int var3 = false;
         this.virtualPaymentAddress = it.getString("virtualPaymentAddress");
      }

   }

   public final void explicitDismiss() {
      Log.d("cancel confirmation bottom sheet", "explicit dismiss called");
      CountDownTimer var10000 = this.countdownTimer;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
         var10000 = null;
      }

      var10000.cancel();
      var10000 = this.countdownTimerForAPI;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimerForAPI");
         var10000 = null;
      }

      var10000.cancel();
      this.dismiss();
   }

   public void onResume() {
      super.onResume();
      Dialog var10000 = this.getDialog();
      if (var10000 != null) {
         var10000.setOnKeyListener(UPITimerBottomSheet::onResume$lambda$1);
      }

   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(UPITimerBottomSheet::onCreateDialog$lambda$3);
      return dialog;
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentUPITimerBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      LiveData var10000 = this.getSharedViewModel().getDismissBottomSheetEvent();
      LifecycleOwner var10001 = this.getViewLifecycleOwner();
      Function1 var4 = UPITimerBottomSheet::onCreateView$lambda$4;
      var10000.observe(var10001, (Observer)(new Observer(var4) {
         // $FF: synthetic field
         private final Function1 function;

         {
            Intrinsics.checkNotNullParameter(function, "function");
            this.function = function;
         }

         // $FF: synthetic method
         public final void onChanged(Object value) {
            this.function.invoke(value);
         }

         @NotNull
         public final Function<?> getFunctionDelegate() {
            return (Function)this.function;
         }

         public final boolean equals(@Nullable Object other) {
            return other instanceof Observer ? (other instanceof FunctionAdapter ? Intrinsics.areEqual(((FunctionAdapter)this).getFunctionDelegate(), ((FunctionAdapter)other).getFunctionDelegate()) : false) : false;
         }

         public final int hashCode() {
            return ((FunctionAdapter)this).getFunctionDelegate().hashCode();
         }
      }));
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.requireActivity().setRequestedOrientation(1);
      }

      SharedPreferences sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      Editor editor = sharedPreferences.edit();
      String environmentFetched = sharedPreferences.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchTransactionDetailsFromSharedPreferences();
      FragmentUPITimerBottomSheetBinding var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      var10.UPIIDTextView.setText((CharSequence)("UPI ID : " + this.virtualPaymentAddress));
      var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      var10.circularProgressBar.setStartAngle(90.0F);
      var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      var10.cancelPaymentTextView.setOnClickListener(UPITimerBottomSheet::onCreateView$lambda$5);
      this.startTimer();
      this.startTimerForAPICalls();
      BooleanRef goneOrVisible = new BooleanRef();
      var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      var10.textView.setOnClickListener(UPITimerBottomSheet::onCreateView$lambda$6);
      var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      var10.retryButton.setOnClickListener(UPITimerBottomSheet::onCreateView$lambda$7);
      var10 = this.binding;
      if (var10 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10 = null;
      }

      return (View)var10.getRoot();
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      this.token = sharedPreferences.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      this.successScreenFullReferencePath = sharedPreferences.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   private final void startTimer() {
      this.countdownTimer = (CountDownTimer)(new CountDownTimer() {
         public void onTick(long millisUntilFinished) {
            long minutes = millisUntilFinished / (long)1000 / (long)60;
            long seconds = millisUntilFinished / (long)1000 % (long)60;
            StringCompanionObject var10000 = StringCompanionObject.INSTANCE;
            String var9 = "%02d:%02d";
            Object[] var10 = new Object[]{minutes, seconds};
            String var11 = String.format(var9, Arrays.copyOf(var10, var10.length));
            Intrinsics.checkNotNullExpressionValue(var11, "format(...)");
            String timeString = var11;
            FragmentUPITimerBottomSheetBinding var12 = UPITimerBottomSheet.this.binding;
            if (var12 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var12 = null;
            }

            var12.progressTextView.setText((CharSequence)timeString);
            int progress = (int)((float)millisUntilFinished / (float)300000 * (float)100);
            var12 = UPITimerBottomSheet.this.binding;
            if (var12 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var12 = null;
            }

            var12.circularProgressBar.setProgress((float)progress * 1.0F);
         }

         public void onFinish() {
            FragmentUPITimerBottomSheetBinding var10000 = UPITimerBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.progressTextView.setText((CharSequence)"00:00");
            var10000 = UPITimerBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.circularProgressBar.setProgress(0.0F);
            var10000 = UPITimerBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cancelPaymentTextView.setVisibility(8);
            var10000 = UPITimerBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.retryButton.setVisibility(0);
         }
      });
      CountDownTimer var10000 = this.countdownTimer;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
         var10000 = null;
      }

      var10000.start();
   }

   private final void startTimerForAPICalls() {
      this.countdownTimerForAPI = (CountDownTimer)(new CountDownTimer() {
         public void onTick(long millisUntilFinished) {
            UPITimerBottomSheet var10000 = UPITimerBottomSheet.this;
            StringBuilder var10001 = new StringBuilder();
            String var10002 = UPITimerBottomSheet.this.Base_Session_API_URL;
            if (var10002 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
               var10002 = null;
            }

            var10000.fetchStatusAndReason(var10001.append(var10002).append(UPITimerBottomSheet.this.token).append("/status").toString());
         }

         public void onFinish() {
         }
      });
      CountDownTimer var10000 = this.countdownTimerForAPI;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimerForAPI");
         var10000 = null;
      }

      var10000.start();
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onDismiss(dialog);
      this.dismiss();
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Fetch Status", jsonStr);
   }

   private final void fetchStatusAndReason(String url) {
      Log.d("fetching function called correctly", "Fine");
      JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, url, (JSONObject)null, UPITimerBottomSheet::fetchStatusAndReason$lambda$8, UPITimerBottomSheet::fetchStatusAndReason$lambda$9);
      RequestQueue var10000 = this.requestQueue;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("requestQueue");
         var10000 = null;
      }

      var10000.add((Request)jsonObjectRequest);
   }

   public void onConfirmation() {
      Log.d("parent called successfully", "onConfirmation");
      this.dismiss();
   }

   private static final boolean onResume$lambda$1(UPITimerBottomSheet this$0, DialogInterface var1, int keyCode, KeyEvent var3) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      boolean var10000;
      if (keyCode == 4 && !this$0.isBottomSheetShown) {
         CancelConfirmationBottomSheet bottomSheet = new CancelConfirmationBottomSheet();
         bottomSheet.show(this$0.getParentFragmentManager(), "CancelConfirmationBottomSheet");
         var10000 = true;
      } else {
         Log.d("onResume called", "not back");
         var10000 = false;
      }

      return var10000;
   }

   private static final void onCreateDialog$lambda$3(final UPITimerBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      int screenHeight = this$0.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.8D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      Window window = d.getWindow();
      if (window != null) {
         int var11 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      ((BottomSheetDialog)dialog).setCancelable(false);
      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismiss();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final Unit onCreateView$lambda$4(UPITimerBottomSheet this$0, Boolean dismissed) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (dismissed) {
         this$0.explicitDismiss();
         this$0.getSharedViewModel().bottomSheetDismissed();
      }

      return Unit.INSTANCE;
   }

   private static final void onCreateView$lambda$5(UPITimerBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      CancelConfirmationBottomSheet bottomsheet = new CancelConfirmationBottomSheet();
      bottomsheet.show(this$0.getParentFragmentManager(), "CancellationConfirmation");
   }

   private static final void onCreateView$lambda$6(BooleanRef $goneOrVisible, UPITimerBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter($goneOrVisible, "$goneOrVisible");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentUPITimerBottomSheetBinding var10000;
      if ($goneOrVisible.element) {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.retryButton.setVisibility(0);
      } else {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.retryButton.setVisibility(8);
      }

      $goneOrVisible.element = !$goneOrVisible.element;
   }

   private static final void onCreateView$lambda$7(UPITimerBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      CountDownTimer var10000 = this$0.countdownTimer;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
         var10000 = null;
      }

      var10000.cancel();
      var10000 = this$0.countdownTimerForAPI;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimerForAPI");
         var10000 = null;
      }

      var10000.cancel();
      this$0.dismiss();
   }

   private static final void fetchStatusAndReason$lambda$8(UPITimerBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObject(response);
         String status = response.getString("status");
         String statusReason = response.getString("statusReason");
         Log.d("Status", status);
         Log.d("Status Reason", statusReason);
         Intrinsics.checkNotNull(statusReason);
         CountDownTimer var10000;
         if (!StringsKt.contains((CharSequence)statusReason, (CharSequence)"Received by BoxPay for processing", true) && !StringsKt.contains((CharSequence)statusReason, (CharSequence)"Approved by PSP", true)) {
            Intrinsics.checkNotNull(status);
            if (!StringsKt.contains((CharSequence)status, (CharSequence)"PAID", true)) {
               if (!StringsKt.contains((CharSequence)status, (CharSequence)"PENDING", true) && !StringsKt.contains((CharSequence)status, (CharSequence)"EXPIRED", true) && !StringsKt.contains((CharSequence)status, (CharSequence)"PROCESSING", true) && StringsKt.contains((CharSequence)status, (CharSequence)"FAILED", true)) {
                  .FailureScreenSharedViewModel callback = FailureScreenCallBackSingletonClass.Companion.getInstance().getYourObject();
                  if (callback == null) {
                     Log.d("callback is null", "PaymentFailedWithDetailsSheet");
                  } else {
                     callback.getOpenFailureScreen().invoke();
                  }

                  var10000 = this$0.countdownTimer;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
                     var10000 = null;
                  }

                  var10000.cancel();
                  var10000 = this$0.countdownTimerForAPI;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("countdownTimerForAPI");
                     var10000 = null;
                  }

                  var10000.cancel();
                  this$0.dismiss();
               }

               return;
            }
         }

         CallBackFunctions callback = .SingletonClass.Companion.getInstance().getYourObject();
         if (callback == null) {
            Log.d("call back is null", "failed");
         } else {
            callback.getOnPaymentResult().invoke(new PaymentResultObject("Success"));
         }

         var10000 = this$0.countdownTimer;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
            var10000 = null;
         }

         var10000.cancel();
         var10000 = this$0.countdownTimerForAPI;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("countdownTimerForAPI");
            var10000 = null;
         }

         var10000.cancel();
         this$0.dismiss();
      } catch (JSONException var5) {
         var5.printStackTrace();
      }

   }

   private static final void fetchStatusAndReason$lambda$9(VolleyError error) {
      Log.d("Error here", error.toString());
      error.printStackTrace();
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¨\u0006\b"},
      d2 = {"Lcom/example/tray/UPITimerBottomSheet$Companion;", "", "<init>", "()V", "newInstance", "Lcom/example/tray/UPITimerBottomSheet;", "virtualPaymentAddress", "", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final UPITimerBottomSheet newInstance(@Nullable String virtualPaymentAddress) {
         UPITimerBottomSheet fragment = new UPITimerBottomSheet();
         Bundle args = new Bundle();
         args.putString("virtualPaymentAddress", virtualPaymentAddress);
         fragment.setArguments(args);
         return fragment;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
