package com.example.tray;

import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.InputFilter.LengthFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.R.drawable;
import com.example.tray.databinding.FragmentAddCardBottomSheetBinding;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0096\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u0000 b2\u00020\u0001:\u0002abB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u0010\u0010&\u001a\u00020#2\u0006\u0010'\u001a\u00020(H\u0016J\u0016\u0010)\u001a\u00020#2\u0006\u0010*\u001a\u00020+2\u0006\u0010\u000f\u001a\u00020\rJ\u0010\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020\rH\u0002J\u0010\u0010/\u001a\u00020#2\u0006\u00100\u001a\u00020\rH\u0002J\u0016\u00101\u001a\u00020#2\f\u00102\u001a\b\u0012\u0004\u0012\u00020\r03H\u0002J\b\u00104\u001a\u00020#H\u0002J\b\u00105\u001a\u00020#H\u0002J&\u00106\u001a\u0004\u0018\u0001072\u0006\u00108\u001a\u0002092\b\u0010:\u001a\u0004\u0018\u00010;2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\u0016\u0010<\u001a\u00020\u00152\u0006\u0010=\u001a\u00020\r2\u0006\u0010>\u001a\u00020\rJ\u000e\u0010?\u001a\u00020\u00152\u0006\u0010@\u001a\u00020-J\u0010\u0010A\u001a\u00020\u00152\u0006\u0010B\u001a\u00020\rH\u0002J\u0010\u0010C\u001a\u00020\u00152\u0006\u0010D\u001a\u00020\rH\u0002J\u0010\u0010E\u001a\u00020#2\u0006\u0010'\u001a\u00020(H\u0016J\u0012\u0010F\u001a\u00020G2\b\u0010$\u001a\u0004\u0018\u00010%H\u0016J\b\u0010H\u001a\u00020#H\u0002J\b\u0010I\u001a\u00020#H\u0002J\u0010\u0010J\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rH\u0002J\u0010\u0010K\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rH\u0002J\u0010\u0010L\u001a\u00020\r2\u0006\u0010M\u001a\u00020\rH\u0002J\b\u0010N\u001a\u00020#H\u0002J\u0010\u0010O\u001a\u00020#2\u0006\u0010P\u001a\u00020\rH\u0002J\u000e\u0010Q\u001a\u00020#2\u0006\u0010*\u001a\u00020+J\u0010\u0010R\u001a\u00020\r2\u0006\u0010S\u001a\u00020\rH\u0002J\u0010\u0010T\u001a\u0004\u0018\u00010\r2\u0006\u0010U\u001a\u00020\rJ\u0006\u0010V\u001a\u00020#J\u0006\u0010W\u001a\u00020#J\b\u0010X\u001a\u00020#H\u0002J\b\u0010Y\u001a\u00020#H\u0002J\u0010\u0010Z\u001a\u00020\r2\u0006\u0010M\u001a\u00020\rH\u0002J\u000e\u0010[\u001a\u00020#2\u0006\u0010\\\u001a\u00020]J\u000e\u0010^\u001a\u00020#2\u0006\u0010_\u001a\u00020\rJ\u000e\u0010`\u001a\u00020#2\u0006\u0010U\u001a\u00020\rR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006c"},
   d2 = {"Lcom/example/tray/AddCardBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentAddCardBottomSheetBinding;", "viewModel", "LDismissViewModel;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "bottomSheet", "Base_Session_API_URL", "", "token", "cardNumber", "cardExpiryYYYY_MM", "cvv", "cardHolderName", "proceedButtonIsEnabled", "Landroidx/lifecycle/MutableLiveData;", "", "isCardNumberValid", "isCardValidityValid", "isCardCVVValid", "isNameOnCardValid", "successScreenFullReferencePath", "isAmericanExpressCard", "transactionId", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "cardNetworkFound", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCancel", "dialog", "Landroid/content/DialogInterface;", "makeCardNetworkIdentificationCall", "context", "Landroid/content/Context;", "getImageDrawableForItem", "", "item", "removeAndAddImageCardNetworks", "cardNetworkName", "updateCardNetwork", "brands", "", "dismissAndMakeButtonsOfMainBottomSheetEnabled", "dismissMainBottomSheet", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "isValidExpirationDate", "inputExpMonth", "inputExpYear", "isValidCVC", "inputCVC", "isValidCardNumberByLuhn", "stringInputCardNumber", "isValidCardNumberLength", "inputCardNumber", "onDismiss", "onCreateDialog", "Landroid/app/Dialog;", "removeErrors", "giveErrors", "formatCardNumber", "deformatCardNumber", "formatMMYY", "date", "fetchTransactionDetailsFromSharedPreferences", "updateTransactionIDInSharedPreferences", "transactionIdArg", "postRequest", "removeSpaces", "stringWithSpaces", "extractMessageFromErrorResponse", "response", "hideLoadingInButton", "showLoadingInButton", "enableProceedButton", "disableProceedButton", "addDashInsteadOfSlash", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "getMessageForFieldErrorItems", "errorString", "getStatusReasonFromResponse", "AsteriskPasswordTransformationMethod", "Companion", "Tray_release"}
)
@SourceDebugExtension({"SMAP\nAddCardBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AddCardBottomSheet.kt\ncom/example/tray/AddCardBottomSheet\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,1223:1\n425#2:1224\n507#2,5:1225\n*S KotlinDebug\n*F\n+ 1 AddCardBottomSheet.kt\ncom/example/tray/AddCardBottomSheet\n*L\n242#1:1224\n242#1:1225,5\n*E\n"})
public final class AddCardBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final AddCardBottomSheet.Companion Companion = new AddCardBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentAddCardBottomSheetBinding binding;
   private .DismissViewModel viewModel;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @Nullable
   private FrameLayout bottomSheet;
   private String Base_Session_API_URL;
   @Nullable
   private String token;
   @Nullable
   private String cardNumber;
   @Nullable
   private String cardExpiryYYYY_MM;
   @Nullable
   private String cvv;
   @Nullable
   private String cardHolderName;
   @NotNull
   private MutableLiveData<Boolean> proceedButtonIsEnabled = new MutableLiveData();
   private boolean isCardNumberValid;
   private boolean isCardValidityValid;
   private boolean isCardCVVValid;
   private boolean isNameOnCardValid;
   @Nullable
   private String successScreenFullReferencePath;
   @NotNull
   private MutableLiveData<Boolean> isAmericanExpressCard = new MutableLiveData();
   @Nullable
   private String transactionId;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   private boolean cardNetworkFound;

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   public void onCancel(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onCancel(dialog);
      this.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   public final void makeCardNetworkIdentificationCall(@NotNull Context context, @NotNull String cardNumber) {
      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(cardNumber, "cardNumber");
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue queue = var10000;
      Log.d("makeCardNetworkIdentificationCall", cardNumber);
      StringBuilder var10 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String url = var10.append(var10001).append(this.token).append("/bank-identification-numbers/tokens/").append(cardNumber).toString();
      Log.d("BIN API CALL", url);
      JSONArray jsonData = new JSONArray();
      List brands = (List)(new ArrayList());
      Listener var8 = AddCardBottomSheet::makeCardNetworkIdentificationCall$lambda$0;
      ErrorListener var9 = AddCardBottomSheet::makeCardNetworkIdentificationCall$lambda$1;
      <undefinedtype> request = new JsonArrayRequest(url, jsonData, var8, var9) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("Content-Type", "application/json");
            ((Map)headers).put("Authorization", "Bearer afcGgCv6mOVIIpnFPWBL44RRciVU8oMteV5ZhC2nwjjjuw8z0obKMjdK8ShcwLOU6uRNjQryLKl1pLAsLAXSI");
            return (Map)headers;
         }
      };
      queue.add((Request)request);
   }

   private final int getImageDrawableForItem(String item) {
      int var10000;
      switch(item.hashCode()) {
      case -1802816241:
         if (item.equals("Maestro")) {
            var10000 = drawable.maestro;
            return var10000;
         }
         break;
      case -1794021524:
         if (item.equals("Bankcard")) {
            var10000 = drawable.bankcard;
            return var10000;
         }
         break;
      case -1242726992:
         if (item.equals("ChinaUnionPay")) {
            var10000 = drawable.chinaunionpay;
            return var10000;
         }
         break;
      case -342850559:
         if (item.equals("BancontactCard")) {
            var10000 = drawable.bancontact;
            return var10000;
         }
         break;
      case -217540848:
         if (item.equals("AmericanExpress")) {
            var10000 = drawable.american_express;
            return var10000;
         }
         break;
      case -45252462:
         if (item.equals("Mastercard")) {
            var10000 = drawable.mastercard;
            return var10000;
         }
         break;
      case 69768:
         if (item.equals("Elo")) {
            var10000 = drawable.elo;
            return var10000;
         }
         break;
      case 73257:
         if (item.equals("JCB")) {
            var10000 = drawable.jcb;
            return var10000;
         }
         break;
      case 2052483:
         if (item.equals("Aura")) {
            var10000 = drawable.auraaxis;
            return var10000;
         }
         break;
      case 2390321:
         if (item.equals("Mada")) {
            var10000 = drawable.mada;
            return var10000;
         }
         break;
      case 2597384:
         if (item.equals("UATP")) {
            var10000 = drawable.uatp;
            return var10000;
         }
         break;
      case 2615560:
         if (item.equals("Troy")) {
            var10000 = drawable.troy;
            return var10000;
         }
         break;
      case 2634817:
         if (item.equals("VISA")) {
            var10000 = drawable.visa;
            return var10000;
         }
         break;
      case 47520258:
         if (item.equals("Electron")) {
            var10000 = drawable.electron;
            return var10000;
         }
         break;
      case 47935951:
         if (item.equals("Supercharge")) {
            var10000 = drawable.charge;
            return var10000;
         }
         break;
      case 63947092:
         if (item.equals("Bajaj")) {
            var10000 = drawable.bajaj;
            return var10000;
         }
         break;
      case 73160331:
         if (item.equals("LaSer")) {
            var10000 = drawable.laser;
            return var10000;
         }
         break;
      case 78339941:
         if (item.equals("RUPAY")) {
            var10000 = drawable.rupay;
            return var10000;
         }
         break;
      case 79758000:
         if (item.equals("Sears")) {
            var10000 = drawable.sears;
            return var10000;
         }
         break;
      case 337828873:
         if (item.equals("Discover")) {
            var10000 = drawable.discover;
            return var10000;
         }
         break;
      case 572259998:
         if (item.equals("Keyfuels")) {
            var10000 = drawable.keyfuels;
            return var10000;
         }
         break;
      case 639825260:
         if (item.equals("Hipercard")) {
            var10000 = drawable.hipercard;
            return var10000;
         }
         break;
      case 752472947:
         if (item.equals("AllStar")) {
            var10000 = drawable.allstar;
            return var10000;
         }
         break;
      case 1189254518:
         if (item.equals("CartesBancaires")) {
            var10000 = drawable.cartesbancaires;
            return var10000;
         }
         break;
      case 1241342230:
         if (item.equals("Overdrive")) {
            var10000 = drawable.overdrive;
            return var10000;
         }
         break;
      case 1980702025:
         if (item.equals("CARNET")) {
            var10000 = drawable.carnet;
            return var10000;
         }
         break;
      case 2018632292:
         if (item.equals("Cirrus")) {
            var10000 = drawable.cirrus;
            return var10000;
         }
         break;
      case 2047129693:
         if (item.equals("Diners")) {
            var10000 = drawable.diners;
            return var10000;
         }
         break;
      case 2073177505:
         if (item.equals("Eftpos")) {
            var10000 = drawable.eftpos;
            return var10000;
         }
      }

      var10000 = drawable.card_02;
      return var10000;
   }

   private final void removeAndAddImageCardNetworks(String cardNetworkName) {
      this.isAmericanExpressCard.setValue(Intrinsics.areEqual(cardNetworkName, "AmericanExpress"));
      Log.d("removeAndAddImageCardNetworksCalled", cardNetworkName);
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.defaultCardNetworkLinearLayout.setVisibility(8);
      ImageView imageView = new ImageView(this.requireContext());
      LayoutParams layoutParams = new LayoutParams(-2, -2);
      imageView.setLayoutParams((android.view.ViewGroup.LayoutParams)layoutParams);
      int imageDrawable = this.getImageDrawableForItem(cardNetworkName);
      imageView.setImageResource(imageDrawable);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.fetchedCardNetwork.removeAllViews();
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.fetchedCardNetwork.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.fetchedCardNetwork.addView((View)imageView);
   }

   private final void updateCardNetwork(List<String> brands) {
      if (brands.size() == 1) {
         Log.d("Checking for card network", String.valueOf(brands.size()));
         this.removeAndAddImageCardNetworks((String)brands.get(0));
      } else {
         Log.d("updateCardNetworkRemoveAllViews", "here");
         FragmentAddCardBottomSheetBinding var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.fetchedCardNetwork.removeAllViews();
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.fetchedCardNetwork.setVisibility(8);
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.defaultCardNetworkLinearLayout.setVisibility(0);
      }

   }

   private final void dismissAndMakeButtonsOfMainBottomSheetEnabled() {
      Fragment var2 = this.getParentFragmentManager().findFragmentByTag("MainBottomSheet");
      MainBottomSheet mainBottomSheetFragment = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if (mainBottomSheetFragment != null) {
         mainBottomSheetFragment.enabledButtonsForAllPaymentMethods();
      }

      Log.d("dismissViewModel", "Add card dismiss called Works fine");
      .DismissViewModel var10000 = this.viewModel;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("viewModel");
         var10000 = null;
      }

      var10000.onChildDismissed();
      this.dismiss();
   }

   private final void dismissMainBottomSheet() {
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentAddCardBottomSheetBinding.inflate(inflater, container, false);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.requireActivity().setRequestedOrientation(1);
      }

      this.viewModel = (.DismissViewModel)(new ViewModelProvider((ViewModelStoreOwner)this)).get(.DismissViewModel.class);
      SharedPreferences var10000 = this.sharedPreferences;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10000 = null;
      }

      String environmentFetched = var10000.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchTransactionDetailsFromSharedPreferences();
      String allowedCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890. ";
      InputFilter filter = AddCardBottomSheet::onCreateView$lambda$3;
      FragmentAddCardBottomSheetBinding var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      EditText var12 = var11.editTextNameOnCard;
      InputFilter[] var8 = new InputFilter[]{filter};
      var12.setFilters(var8);
      Dialog var13 = this.getDialog();
      if (var13 != null) {
         Window var14 = var13.getWindow();
         if (var14 != null) {
            var14.setSoftInputMode(16);
         }
      }

      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.progressBar.setVisibility(4);
      this.proceedButtonIsEnabled.observe((LifecycleOwner)this, AddCardBottomSheet::onCreateView$lambda$4);
      this.isAmericanExpressCard.observe((LifecycleOwner)this, AddCardBottomSheet::onCreateView$lambda$5);
      this.proceedButtonIsEnabled.setValue(false);
      BooleanRef checked = new BooleanRef();
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.progressBar.setVisibility(4);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.ll1InvalidCardNumber.setVisibility(8);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.invalidCardValidity.setVisibility(8);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.invalidCVV.setVisibility(8);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.saveCardLinearLayout.setOnClickListener(AddCardBottomSheet::onCreateView$lambda$6);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.backButton.setOnClickListener(AddCardBottomSheet::onCreateView$lambda$7);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var12 = var11.editTextCardNumber;
      LengthFilter[] var9 = new LengthFilter[]{new LengthFilter(19)};
      var12.setFilters((InputFilter[])var9);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardNumber.addTextChangedListener((TextWatcher)(new TextWatcher() {
         private boolean isFormatting;
         private boolean userDeletingChars;

         public final boolean isFormatting() {
            return this.isFormatting;
         }

         public final void setFormatting(boolean var1) {
            this.isFormatting = var1;
         }

         public final boolean getUserDeletingChars() {
            return this.userDeletingChars;
         }

         public final void setUserDeletingChars(boolean var1) {
            this.userDeletingChars = var1;
         }

         public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            this.userDeletingChars = count > after;
         }

         public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            CharSequence var5 = (CharSequence)String.valueOf(s);
            if (var5 == null || StringsKt.isBlank(var5)) {
               AddCardBottomSheet.this.isCardNumberValid = false;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            } else {
               AddCardBottomSheet.this.isCardNumberValid = true;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
            }

         }

         public void afterTextChanged(Editable s) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            if (!this.isFormatting) {
               if (s != null) {
                  AddCardBottomSheet var3 = AddCardBottomSheet.this;
                  int var5 = false;
                  Log.d("editable text here", "" + s + '.');
                  String textNow = s.toString();
                  CharSequence var7 = (CharSequence)textNow;
                  Regex var8 = new Regex("\\s");
                  String var9 = "";
                  String text = var8.replace(var7, var9);
                  String formattedText = var3.formatCardNumber(text);
                  FragmentAddCardBottomSheetBinding var12;
                  if (!Intrinsics.areEqual(s.toString(), formattedText) && !this.userDeletingChars) {
                     Log.d("editable text here f", formattedText + '.');
                     this.isFormatting = true;
                     var12 = var3.binding;
                     if (var12 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("binding");
                        var12 = null;
                     }

                     var12.editTextCardNumber.setText((CharSequence)formattedText);
                     var12 = var3.binding;
                     if (var12 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("binding");
                        var12 = null;
                     }

                     var12.editTextCardNumber.setSelection(formattedText.length());
                  } else if (s.toString().length() > 1 && s.toString().charAt(s.toString().length() - 1) == ' ') {
                     s.delete(s.length() - 1, s.length());
                  }

                  this.isFormatting = false;
                  if (StringsKt.isBlank((CharSequence)text)) {
                     Log.d("text is blank", "card Number");
                     var3.isCardNumberValid = false;
                     var3.proceedButtonIsEnabled.setValue(false);
                  } else if (text.length() == 19) {
                     Log.d("text is not valid", String.valueOf(var3.isCardNumberValid));
                     if (var3.isValidCardNumberByLuhn(var3.removeSpaces(text))) {
                        var12 = var3.binding;
                        if (var12 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var12 = null;
                        }

                        var12.editTextCardValidity.requestFocus();
                        var3.isCardNumberValid = true;
                        var12 = var3.binding;
                        if (var12 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var12 = null;
                        }

                        var12.ll1InvalidCardNumber.setVisibility(8);
                        var3.proceedButtonIsEnabled.setValue(true);
                     } else {
                        var3.isCardNumberValid = false;
                        var12 = var3.binding;
                        if (var12 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var12 = null;
                        }

                        var12.ll1InvalidCardNumber.setVisibility(0);
                        var3.proceedButtonIsEnabled.setValue(false);
                     }
                  }

                  if (!var3.cardNetworkFound) {
                     Context var10001 = var3.requireContext();
                     Intrinsics.checkNotNullExpressionValue(var10001, "requireContext(...)");
                     var3.makeCardNetworkIdentificationCall(var10001, text);
                  }
               }
            }

         }
      }));
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var12 = var11.editTextCardValidity;
      var9 = new LengthFilter[]{new LengthFilter(7)};
      var12.setFilters((InputFilter[])var9);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardValidity.addTextChangedListener((TextWatcher)(new TextWatcher() {
         private boolean isFormatting;
         private boolean userDeletingChars;

         public final boolean isFormatting() {
            return this.isFormatting;
         }

         public final void setFormatting(boolean var1) {
            this.isFormatting = var1;
         }

         public final boolean getUserDeletingChars() {
            return this.userDeletingChars;
         }

         public final void setUserDeletingChars(boolean var1) {
            this.userDeletingChars = var1;
         }

         public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            this.userDeletingChars = count > after;
         }

         public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            CharSequence var5 = (CharSequence)String.valueOf(s);
            if (var5 == null || StringsKt.isBlank(var5)) {
               AddCardBottomSheet.this.isCardValidityValid = true;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
            } else {
               AddCardBottomSheet.this.isCardValidityValid = false;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            }

         }

         public void afterTextChanged(Editable s) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            if (!this.isFormatting) {
               String textNow = String.valueOf(s);
               String text = StringsKt.replace$default(String.valueOf(s), "/", "", false, 4, (Object)null);
               FragmentAddCardBottomSheetBinding var6;
               if (((CharSequence)text).length() > 0 && Integer.parseInt(String.valueOf(text.charAt(0))) != 0 && Integer.parseInt(String.valueOf(text.charAt(0))) != 1) {
                  Log.d("Invalid month in validity", String.valueOf(text.charAt(0)));
                  var6 = AddCardBottomSheet.this.binding;
                  if (var6 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var6 = null;
                  }

                  var6.invalidCardValidity.setVisibility(8);
                  AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
               }

               if (text.length() == 1) {
                  Log.d("textNow card validity", text);
                  if (!Intrinsics.areEqual(text, "0") && !Intrinsics.areEqual(text, "1")) {
                     text = '0' + text;
                  }
               }

               String formattedText = AddCardBottomSheet.this.formatMMYY(text);
               if (text.length() == 4) {
                  var6 = AddCardBottomSheet.this.binding;
                  if (var6 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var6 = null;
                  }

                  var6.editTextCardCVV.requestFocus();
               }

               if (!this.userDeletingChars) {
                  this.isFormatting = true;
                  var6 = AddCardBottomSheet.this.binding;
                  if (var6 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var6 = null;
                  }

                  var6.editTextCardValidity.setText((CharSequence)formattedText);
                  var6 = AddCardBottomSheet.this.binding;
                  if (var6 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var6 = null;
                  }

                  var6.editTextCardValidity.setSelection(formattedText.length());
               } else if (String.valueOf(s).length() > 1 && String.valueOf(s).charAt(String.valueOf(s).length() - 1) == '/') {
                  if (s != null) {
                     s.delete(s.toString().length() - 1, s.toString().length());
                  }
               }

               this.isFormatting = false;
               if (!StringsKt.isBlank((CharSequence)textNow)) {
                  if (textNow.length() == 5) {
                     Log.d("card validity is made true", String.valueOf(textNow.length()));
                     var6 = AddCardBottomSheet.this.binding;
                     if (var6 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("binding");
                        var6 = null;
                     }

                     String cardValidity = var6.editTextCardValidity.getText().toString();
                     AddCardBottomSheet var7 = AddCardBottomSheet.this;
                     String var10001 = cardValidity.substring(0, 2);
                     Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
                     String var10002 = cardValidity.substring(3, 5);
                     Intrinsics.checkNotNullExpressionValue(var10002, "substring(...)");
                     if (!var7.isValidExpirationDate(var10001, var10002)) {
                        AddCardBottomSheet.this.isCardValidityValid = false;
                        AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
                        var6 = AddCardBottomSheet.this.binding;
                        if (var6 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var6 = null;
                        }

                        var6.invalidCardValidity.setVisibility(0);
                        var6 = AddCardBottomSheet.this.binding;
                        if (var6 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var6 = null;
                        }

                        var6.textView7.setText((CharSequence)"Invalid card validity");
                     } else {
                        AddCardBottomSheet.this.isCardValidityValid = true;
                        AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
                        var6 = AddCardBottomSheet.this.binding;
                        if (var6 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var6 = null;
                        }

                        var6.invalidCardValidity.setVisibility(8);
                     }
                  } else {
                     AddCardBottomSheet.this.isCardValidityValid = false;
                     AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
                  }
               }

               if (StringsKt.isBlank((CharSequence)textNow)) {
                  AddCardBottomSheet.this.isCardValidityValid = false;
                  AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
               }
            }

         }
      }));
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardCVV.addTextChangedListener((TextWatcher)(new TextWatcher() {
         public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            Log.d("beforeTextChanged", String.valueOf(s));
         }

         public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            String textNow = String.valueOf(s);
            Log.d("onTextChanged", String.valueOf(s));
            FragmentAddCardBottomSheetBinding var6;
            if (!StringsKt.isBlank((CharSequence)textNow)) {
               if (textNow.length() >= 3) {
                  AddCardBottomSheet.this.isCardCVVValid = true;
                  AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
                  var6 = AddCardBottomSheet.this.binding;
                  if (var6 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var6 = null;
                  }

                  var6.invalidCVV.setVisibility(8);
               } else {
                  AddCardBottomSheet.this.isCardCVVValid = false;
                  AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
               }
            } else {
               AddCardBottomSheet.this.isCardCVVValid = false;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            }

            if (textNow.length() == 4) {
               var6 = AddCardBottomSheet.this.binding;
               if (var6 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var6 = null;
               }

               var6.editTextNameOnCard.requestFocus();
            }

         }

         public void afterTextChanged(Editable s) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            String textNow = String.valueOf(s);
            Log.d("afterTextChanged", String.valueOf(s));
            if (StringsKt.isBlank((CharSequence)textNow)) {
               AddCardBottomSheet.this.isCardCVVValid = false;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            } else {
               AddCardBottomSheet.this.isCardCVVValid = true;
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
            }

         }
      }));
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextNameOnCard.addTextChangedListener((TextWatcher)(new TextWatcher() {
         public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            Log.d("beforeTextChanged", String.valueOf(s));
         }

         public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            String textNow = String.valueOf(s);
            if (StringsKt.isBlank((CharSequence)textNow)) {
               Log.d("inside true of text changed", String.valueOf(s));
               AddCardBottomSheet.this.isNameOnCardValid = false;
               FragmentAddCardBottomSheetBinding var6 = AddCardBottomSheet.this.binding;
               if (var6 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var6 = null;
               }

               var6.nameOnCardErrorLayout.setVisibility(8);
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            }

         }

         public void afterTextChanged(Editable s) {
            if (AddCardBottomSheet.this.bottomSheetBehavior == null) {
               Log.d("bottomSheetBehavior is null", "check here");
            }

            BottomSheetBehavior var10000 = AddCardBottomSheet.this.bottomSheetBehavior;
            if (var10000 != null) {
               var10000.setState(3);
            }

            String textNow = String.valueOf(s);
            Log.d("afterTextChanged", String.valueOf(s));
            FragmentAddCardBottomSheetBinding var3;
            if (StringsKt.isBlank((CharSequence)textNow)) {
               AddCardBottomSheet.this.isNameOnCardValid = false;
               var3 = AddCardBottomSheet.this.binding;
               if (var3 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var3 = null;
               }

               var3.nameOnCardErrorLayout.setVisibility(0);
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(false);
            } else {
               AddCardBottomSheet.this.isNameOnCardValid = true;
               var3 = AddCardBottomSheet.this.binding;
               if (var3 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var3 = null;
               }

               var3.nameOnCardErrorLayout.setVisibility(8);
               AddCardBottomSheet.this.proceedButtonIsEnabled.setValue(true);
            }

         }
      }));
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardCVV.setTransformationMethod((TransformationMethod)(new AddCardBottomSheet.AsteriskPasswordTransformationMethod()));
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.proceedButton.setOnClickListener(AddCardBottomSheet::onCreateView$lambda$8);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardNumber.setOnFocusChangeListener(AddCardBottomSheet::onCreateView$lambda$9);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardValidity.setOnFocusChangeListener(AddCardBottomSheet::onCreateView$lambda$10);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextCardCVV.setOnFocusChangeListener(AddCardBottomSheet::onCreateView$lambda$11);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      var11.editTextNameOnCard.setOnFocusChangeListener(AddCardBottomSheet::onCreateView$lambda$12);
      var11 = this.binding;
      if (var11 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var11 = null;
      }

      return (View)var11.getRoot();
   }

   public final boolean isValidExpirationDate(@NotNull String inputExpMonth, @NotNull String inputExpYear) {
      Intrinsics.checkNotNullParameter(inputExpMonth, "inputExpMonth");
      Intrinsics.checkNotNullParameter(inputExpYear, "inputExpYear");
      int currentYear = Calendar.getInstance().get(1);
      int currentMonth = Calendar.getInstance().get(2) + 1;
      Log.d("date details", "Current Month = " + currentMonth + ", Current year =  " + currentYear + ", inputExpMonth = " + inputExpMonth + ", inputExpYear = " + inputExpYear);
      boolean isValidYearValue = Integer.parseInt(inputExpYear) > 0;
      boolean isValidYearLength = inputExpYear.length() == 2;
      Log.d("input expiry", "" + Integer.parseInt(inputExpYear) + ' ' + Integer.parseInt(inputExpMonth));
      int var8 = Integer.parseInt(inputExpMonth);
      boolean isMonthValid = 1 <= var8 ? var8 < 13 : false;
      boolean isFutureYear = Integer.parseInt("20" + inputExpYear) >= currentYear;
      boolean isValidMonthRange = Integer.parseInt(inputExpMonth) >= currentMonth || isFutureYear;
      boolean isSameYear_FutureOrCurrentMonth = Integer.parseInt(inputExpYear) == currentYear && Integer.parseInt(inputExpMonth) >= currentMonth;
      boolean result = isValidMonthRange && isValidYearLength && isValidYearValue && (isFutureYear || isSameYear_FutureOrCurrentMonth) && isMonthValid;
      if (!result) {
         this.proceedButtonIsEnabled.setValue(false);
      }

      Log.d("variables for validity", "" + isValidMonthRange + ' ' + isValidYearValue + isValidYearLength + ' ' + isMonthValid + ' ' + isFutureYear + ' ' + isSameYear_FutureOrCurrentMonth);
      return result;
   }

   public final boolean isValidCVC(int inputCVC) {
      String stringInputCVC = String.valueOf(inputCVC);
      boolean result = stringInputCVC.length() >= 3 && stringInputCVC.length() <= 4;
      if (!result) {
         this.proceedButtonIsEnabled.setValue(false);
      }

      return result;
   }

   private final boolean isValidCardNumberByLuhn(String stringInputCardNumber) {
      int sum = 0;
      boolean isSecondDigit = false;

      for(int i = stringInputCardNumber.length() - 1; -1 < i; --i) {
         int d = stringInputCardNumber.charAt(i) - 48;
         if (isSecondDigit) {
            d *= 2;
         }

         sum += d / 10;
         sum += d % 10;
         isSecondDigit = !isSecondDigit;
      }

      boolean result = sum % 10 == 0;
      if (!result) {
         Log.d("Invalid by luhn", "here");
      }

      if (!result) {
         this.proceedButtonIsEnabled.setValue(false);
      }

      return result;
   }

   private final boolean isValidCardNumberLength(String inputCardNumber) {
      boolean result = inputCardNumber.length() >= 15 && inputCardNumber.length() <= 16;
      Log.d("isValidCardNumberLength", "" + result + ' ' + inputCardNumber.length());
      return result;
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      Fragment var2 = this.getParentFragment();
      MainBottomSheet var10000 = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if ((var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null) != null) {
         var10000.removeOverlayFromCurrentBottomSheet();
      }

      Log.d("dismissViewModel", "Add card dismiss called Works fine");
      .DismissViewModel var3 = this.viewModel;
      if (var3 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("viewModel");
         var3 = null;
      }

      var3.onChildDismissed();
      super.onDismiss(dialog);
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(AddCardBottomSheet::onCreateDialog$lambda$14);
      return dialog;
   }

   private final void removeErrors() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.ll1InvalidCardNumber.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.invalidCardValidity.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.invalidCVV.setVisibility(8);
   }

   private final void giveErrors() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.ll1InvalidCardNumber.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.invalidCardValidity.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.invalidCVV.setVisibility(0);
   }

   private final String formatCardNumber(String cardNumber) {
      StringBuilder formatted = new StringBuilder();
      int i = 0;

      for(int var4 = ((CharSequence)cardNumber).length(); i < var4; ++i) {
         if (i > 0 && i % 4 == 0) {
            formatted.append(" ");
         }

         formatted.append(cardNumber.charAt(i));
      }

      String var10000 = formatted.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   private final String deformatCardNumber(String cardNumber) {
      return StringsKt.replace$default(cardNumber, " ", "", false, 4, (Object)null);
   }

   private final String formatMMYY(String date) {
      StringBuilder formatted = new StringBuilder();
      int i = 0;

      for(int var4 = ((CharSequence)date).length(); i < var4; ++i) {
         if (i > 0 && i % 2 == 0 && i < 4) {
            formatted.append("/");
         }

         if (formatted.length() >= 5) {
            break;
         }

         formatted.append(date.charAt(i));
      }

      String var10000 = formatted.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.token = var10001.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.successScreenFullReferencePath = var10001.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   public final void postRequest(@NotNull Context context) {
      Intrinsics.checkNotNullParameter(context, "context");
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var4 = new JSONObject();
      int var6 = false;
      JSONObject var7 = new JSONObject();
      int var9 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var7.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var7.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var7.put("acceptHeader", "application/json");
      var7.put("userAgentHeader", userAgentHeader);
      var7.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("ipAddress", var10002.getString("ipAddress", "null"));
      var7.put("colorDepth", 24);
      var7.put("javaEnabled", true);
      var7.put("timeZoneOffSet", 330);
      var4.put("browserData", var7);
      JSONObject var8 = new JSONObject();
      int var10 = false;
      var8.put("type", "card/plain");
      JSONObject var23 = new JSONObject();
      int var14 = false;
      var23.put("number", this.cardNumber);
      var23.put("expiry", this.cardExpiryYYYY_MM);
      var23.put("cvc", this.cvv);
      var23.put("holderName", this.cardHolderName);
      var8.put("card", var23);
      var4.put("instrumentDetails", var8);
      StringBuilder var24 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var5 = var24.append(var10001).append(this.token).toString();
      Listener var17 = AddCardBottomSheet::postRequest$lambda$19;
      ErrorListener var18 = AddCardBottomSheet::postRequest$lambda$20;
      JsonObjectRequest var16 = new JsonObjectRequest(var4, var5, var17, var18) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(AddCardBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var19 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var16.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var16);
   }

   private final String removeSpaces(String stringWithSpaces) {
      return StringsKt.replace$default(stringWithSpaces, " ", "", false, 4, (Object)null);
   }

   @Nullable
   public final String extractMessageFromErrorResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");

      try {
         JSONObject jsonObject = new JSONObject(response);
         return jsonObject.getString("message");
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public final void hideLoadingInButton() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      TextView var1 = var10000.textView6;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setTextColor(Color.parseColor(var10001.getString("buttonTextColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var2 = var10000.proceedButtonRelativeLayout;
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var2.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
   }

   public final void showLoadingInButton() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      ProgressBar var3 = var10000.progressBar;
      float[] var2 = new float[]{0.0F, 360.0F};
      ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(var3, "rotation", var2);
      rotateAnimation.setDuration(3000L);
      rotateAnimation.setRepeatCount(-1);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      rotateAnimation.start();
   }

   private final void enableProceedButton() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(ContextCompat.getColor(this.requireContext(), 17170443));
   }

   private final void disableProceedButton() {
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(Color.parseColor("#ADACB0"));
   }

   private final String addDashInsteadOfSlash(String date) {
      try {
         String var5 = date.substring(0, 2);
         Intrinsics.checkNotNullExpressionValue(var5, "substring(...)");
         String mm = var5;
         StringBuilder var6 = (new StringBuilder()).append("20");
         String var10001 = date.substring(3, 5);
         Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
         String yyyy = var6.append(var10001).toString();
         return yyyy + '-' + mm;
      } catch (Exception var4) {
         FragmentAddCardBottomSheetBinding var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.textView7.setText((CharSequence)"Invalid Validity");
         return "";
      }
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body", jsonStr);
   }

   public final void getMessageForFieldErrorItems(@NotNull String errorString) {
      Intrinsics.checkNotNullParameter(errorString, "errorString");
      JSONObject jsonObject = new JSONObject(errorString);
      JSONArray fieldErrorItems = jsonObject.getJSONArray("fieldErrorItems");
      int i = 0;

      for(int var5 = fieldErrorItems.length(); i < var5; ++i) {
         String errorMessage = fieldErrorItems.getJSONObject(i).getString("message");
         Log.d("errorMessage", errorMessage);
         Intrinsics.checkNotNull(errorMessage);
         FragmentAddCardBottomSheetBinding var10000;
         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"Invalid instrumentDetails.card.expiry", true)) {
            var10000 = this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.invalidCardValidity.setVisibility(0);
            var10000 = this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.textView7.setText((CharSequence)"Invalid Validity");
         }

         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"instrumentDetails.card.number is invalid", true)) {
            var10000 = this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.ll1InvalidCardNumber.setVisibility(0);
            var10000 = this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.textView4.setText((CharSequence)"Invalid Card Number");
         }
      }

   }

   public final void getStatusReasonFromResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");
      JSONObject jsonObject = new JSONObject(response);
      Log.d("Reason 123", "statusReasonCheck");
      JSONObject statusObject = jsonObject.getJSONObject("status");
      String statusReason = statusObject.getString("reason");
      Log.d("Reason xyz", statusReason);
      FragmentAddCardBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.invalidCardValidity.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView7.setText((CharSequence)statusReason);
      Intrinsics.checkNotNull(statusReason);
      if (StringsKt.contains((CharSequence)statusReason, (CharSequence)"Invalid Card Expiry", true)) {
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.invalidCardValidity.setVisibility(0);
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.textView7.setText((CharSequence)"Invalid Validity");
      } else if (StringsKt.contains((CharSequence)statusReason, (CharSequence)"Invalid CVV", true)) {
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.invalidCVV.setVisibility(0);
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.textView8.setText((CharSequence)"Invalid CVV");
      }

   }

   private static final void makeCardNetworkIdentificationCall$lambda$0(List $brands, String $cardNumber, AddCardBottomSheet this$0, JSONArray response) {
      Intrinsics.checkNotNullParameter($brands, "$brands");
      Intrinsics.checkNotNullParameter($cardNumber, "$cardNumber");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      int i = 0;

      for(int var5 = response.length(); i < var5; ++i) {
         String currBrand = response.getJSONObject(i).getJSONObject("paymentMethod").getString("brand");
         Log.d("Checking for card network", currBrand);
         Intrinsics.checkNotNull(currBrand);
         $brands.add(currBrand);
      }

      Log.d("size of brands", $brands.size() + $cardNumber);
      this$0.updateCardNetwork($brands);
   }

   private static final void makeCardNetworkIdentificationCall$lambda$1(AddCardBottomSheet this$0, List $brands, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($brands, "$brands");
      Log.e("Error", "Error occurred: " + error.getMessage());
      this$0.updateCardNetwork($brands);
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var4 = var10000;
         String errorResponse = new String(var4, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         Log.d("", "");
      }

   }

   private static final CharSequence onCreateView$lambda$3(String $allowedCharacters, CharSequence source, int var2, int var3, Spanned var4, int var5, int var6) {
      Intrinsics.checkNotNullParameter($allowedCharacters, "$allowedCharacters");
      Intrinsics.checkNotNull(source);
      int $i$f$filter = false;
      CharSequence $this$filterTo$iv$iv = source;
      Appendable destination$iv$iv = (Appendable)(new StringBuilder());
      int $i$f$filterTo = false;
      int index$iv$iv = 0;

      for(int var13 = source.length(); index$iv$iv < var13; ++index$iv$iv) {
         char element$iv$iv = $this$filterTo$iv$iv.charAt(index$iv$iv);
         int var16 = false;
         if (StringsKt.contains$default((CharSequence)$allowedCharacters, element$iv$iv, false, 2, (Object)null)) {
            destination$iv$iv.append(element$iv$iv);
         }
      }

      return (CharSequence)destination$iv$iv;
   }

   private static final void onCreateView$lambda$4(AddCardBottomSheet this$0, Boolean enableProceedButton) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (enableProceedButton) {
         if (this$0.isCardNumberValid && this$0.isCardValidityValid && this$0.isCardCVVValid && this$0.isNameOnCardValid) {
            this$0.enableProceedButton();
            Log.d("card enabled", "" + this$0.isCardNumberValid + this$0.isCardValidityValid + this$0.isCardCVVValid);
         }
      } else {
         Log.d("card enabled false", "" + this$0.isCardNumberValid + this$0.isCardValidityValid + this$0.isCardCVVValid);
         this$0.disableProceedButton();
      }

   }

   private static final void onCreateView$lambda$5(AddCardBottomSheet this$0, Boolean isAmericanExpressCardOrNot) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentAddCardBottomSheetBinding var10000;
      LengthFilter[] var2;
      EditText var3;
      if (isAmericanExpressCardOrNot) {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.editTextCardCVV.setText((CharSequence)"");
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.editTextCardCVV;
         var2 = new LengthFilter[]{new LengthFilter(4)};
         var3.setFilters((InputFilter[])var2);
      } else {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.editTextCardCVV.setText((CharSequence)"");
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.editTextCardCVV;
         var2 = new LengthFilter[]{new LengthFilter(3)};
         var3.setFilters((InputFilter[])var2);
      }

   }

   private static final void onCreateView$lambda$6(BooleanRef $checked, AddCardBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter($checked, "$checked");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentAddCardBottomSheetBinding var10000;
      if (!$checked.element) {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.imageView3.setImageResource(drawable.checkbox);
         $checked.element = true;
      } else {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.imageView3.setImageResource(0);
         $checked.element = false;
      }

   }

   private static final void onCreateView$lambda$7(AddCardBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   private static final void onCreateView$lambda$8(AddCardBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.removeErrors();
      FragmentAddCardBottomSheetBinding var10002 = this$0.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      this$0.cardNumber = this$0.deformatCardNumber(var10002.editTextCardNumber.getText().toString());
      String var10001 = this$0.cardNumber;
      Intrinsics.checkNotNull(var10001);
      Log.d("card number", var10001);
      var10002 = this$0.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      this$0.cardExpiryYYYY_MM = this$0.addDashInsteadOfSlash(var10002.editTextCardValidity.getText().toString());
      CharSequence var2 = (CharSequence)this$0.cardExpiryYYYY_MM;
      if (var2 != null && var2.length() != 0) {
         var10001 = this$0.cardExpiryYYYY_MM;
         Intrinsics.checkNotNull(var10001);
         Log.d("card expiry", var10001);
         FragmentAddCardBottomSheetBinding var5 = this$0.binding;
         if (var5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var5 = null;
         }

         this$0.cvv = var5.editTextCardCVV.getText().toString();
         var10001 = this$0.cvv;
         Intrinsics.checkNotNull(var10001);
         Log.d("card cvv", var10001);
         var5 = this$0.binding;
         if (var5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var5 = null;
         }

         this$0.cardHolderName = var5.editTextNameOnCard.getText().toString();
         var10001 = this$0.cardHolderName;
         Intrinsics.checkNotNull(var10001);
         Log.d("card holder name", var10001);
         boolean anyFieldEmpty = false;
         CharSequence var3 = (CharSequence)this$0.cardNumber;
         FragmentAddCardBottomSheetBinding var10000;
         if (var3 == null || var3.length() == 0) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.ll1InvalidCardNumber.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.textView4.setText((CharSequence)"Enter card number");
            anyFieldEmpty = true;
         }

         var3 = (CharSequence)this$0.cardExpiryYYYY_MM;
         if (var3 == null || var3.length() == 0) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.invalidCardValidity.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.textView7.setText((CharSequence)"Enter card validity");
            anyFieldEmpty = true;
         }

         var3 = (CharSequence)this$0.cardHolderName;
         if (var3 == null || var3.length() == 0) {
            Toast.makeText(this$0.requireContext(), (CharSequence)"Enter name on card", 0).show();
            anyFieldEmpty = true;
         }

         var3 = (CharSequence)this$0.cvv;
         if (var3 == null || var3.length() == 0) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.invalidCVV.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.textView8.setText((CharSequence)"Enter CVV");
            anyFieldEmpty = true;
         }

         if (!anyFieldEmpty) {
            Context var6 = this$0.requireContext();
            Intrinsics.checkNotNullExpressionValue(var6, "requireContext(...)");
            this$0.postRequest(var6);
            this$0.showLoadingInButton();
         }
      }
   }

   private static final void onCreateView$lambda$9(AddCardBottomSheet this$0, View view, boolean hasFocus) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!hasFocus) {
         FragmentAddCardBottomSheetBinding var10001 = this$0.binding;
         if (var10001 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10001 = null;
         }

         String cardNumber = this$0.removeSpaces(var10001.editTextCardNumber.getText().toString());
         FragmentAddCardBottomSheetBinding var10000;
         if (this$0.isValidCardNumberByLuhn(cardNumber) && this$0.isValidCardNumberLength(cardNumber)) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.ll1InvalidCardNumber.setVisibility(8);
         } else {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.ll1InvalidCardNumber.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            CharSequence var4 = (CharSequence)var10000.editTextCardNumber.getText();
            if (var4 == null || var4.length() == 0) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView4.setText((CharSequence)"Enter Card Number");
            } else {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView4.setText((CharSequence)"Invalid card number");
            }
         }
      }

   }

   private static final void onCreateView$lambda$10(AddCardBottomSheet this$0, View view, boolean hasFocus) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!hasFocus) {
         FragmentAddCardBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         String cardValidity = var10000.editTextCardValidity.getText().toString();

         try {
            String var10001 = cardValidity.substring(0, 2);
            Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
            String var10002 = cardValidity.substring(3, 5);
            Intrinsics.checkNotNullExpressionValue(var10002, "substring(...)");
            if (!this$0.isValidExpirationDate(var10001, var10002)) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.invalidCardValidity.setVisibility(0);
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               CharSequence var4 = (CharSequence)var10000.editTextCardValidity.getText();
               if (var4 == null || var4.length() == 0) {
                  var10000 = this$0.binding;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var10000 = null;
                  }

                  var10000.textView7.setText((CharSequence)"Enter Card Validity");
               } else {
                  Log.d("Invalid card validity", "card bottom sheet");
                  var10000 = this$0.binding;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var10000 = null;
                  }

                  var10000.textView7.setText((CharSequence)"Invalid card Validity");
               }
            } else {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.invalidCardValidity.setVisibility(8);
            }
         } catch (Exception var6) {
            Log.d("Invalid card validity", "exception");
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.invalidCardValidity.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            CharSequence var5 = (CharSequence)var10000.editTextCardValidity.getText();
            if (var5 == null || var5.length() == 0) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView7.setText((CharSequence)"Enter Card Validity");
            } else {
               Log.d("Invalid card validity", "card bottom sheet");
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView7.setText((CharSequence)"Invalid card Validity");
            }
         }
      }

   }

   private static final void onCreateView$lambda$11(AddCardBottomSheet this$0, View view, boolean hasFocus) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!hasFocus) {
         FragmentAddCardBottomSheetBinding var10000;
         CharSequence var4;
         try {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            String cardCVV = var10000.editTextCardCVV.getText().toString();
            if (!this$0.isValidCVC(Integer.parseInt(cardCVV))) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.invalidCVV.setVisibility(0);
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var4 = (CharSequence)var10000.editTextCardCVV.getText();
               if (var4 == null || var4.length() == 0) {
                  var10000 = this$0.binding;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var10000 = null;
                  }

                  var10000.textView8.setText((CharSequence)"Enter CVV");
               } else {
                  var10000 = this$0.binding;
                  if (var10000 == null) {
                     Intrinsics.throwUninitializedPropertyAccessException("binding");
                     var10000 = null;
                  }

                  var10000.textView8.setText((CharSequence)"Invalid CVV");
               }
            } else {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.invalidCVV.setVisibility(8);
            }
         } catch (Exception var5) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.invalidCVV.setVisibility(0);
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var4 = (CharSequence)var10000.editTextCardCVV.getText();
            if (var4 == null || var4.length() == 0) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView8.setText((CharSequence)"Enter CVV");
            } else {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.textView8.setText((CharSequence)"Invalid CVV");
            }
         }
      }

   }

   private static final void onCreateView$lambda$12(AddCardBottomSheet this$0, View view, boolean hasFocus) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!hasFocus) {
         FragmentAddCardBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         CharSequence var3 = (CharSequence)var10000.editTextNameOnCard.getText();
         if (var3 == null || var3.length() == 0) {
            this$0.isNameOnCardValid = false;
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.nameOnCardErrorLayout.setVisibility(0);
         } else {
            this$0.isNameOnCardValid = true;
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.nameOnCardErrorLayout.setVisibility(8);
         }
      }

   }

   private static final void onCreateDialog$lambda$14(final AddCardBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      int screenHeight = this$0.requireContext().getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.9D;
      int var10000 = (int)((double)screenHeight * percentageOfScreenHeight);
      BottomSheetBehavior var12 = this$0.bottomSheetBehavior;
      if (var12 != null) {
         var12.setDraggable(false);
      }

      var12 = this$0.bottomSheetBehavior;
      if (var12 != null) {
         var12.setHideable(false);
      }

      var12 = this$0.bottomSheetBehavior;
      if (var12 != null) {
         var12.setState(3);
      }

      Window window = d.getWindow();
      if (window != null) {
         int var11 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      var12 = this$0.bottomSheetBehavior;
      if (var12 != null) {
         var12.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final void postRequest$lambda$19(AddCardBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.hideLoadingInButton();

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObject(response);
         String status = response.getJSONObject("status").getString("status");
         String reason = response.getJSONObject("status").getString("reason");
         this$0.transactionId = response.getString("transactionId").toString();
         String var10001 = this$0.transactionId;
         Intrinsics.checkNotNull(var10001);
         this$0.updateTransactionIDInSharedPreferences(var10001);
         Log.d("status and reason", status + " due to " + reason);
         String url = "";
         Intrinsics.checkNotNull(status);
         if (StringsKt.contains((CharSequence)status, (CharSequence)"Rejected", true)) {
            (new PaymentFailureScreen()).show(this$0.getParentFragmentManager(), "FailureScreen");
         } else {
            String url = response.getJSONArray("actions").getJSONObject(0).getString("url");
            Log.d("url is fetched", url);
            if (StringsKt.contains((CharSequence)status, (CharSequence)"Approved", true)) {
               PaymentSuccessfulWithDetailsBottomSheet bottomSheet = new PaymentSuccessfulWithDetailsBottomSheet();
               bottomSheet.show(this$0.getParentFragmentManager(), "PaymentStatusBottomSheetWithDetails");
               this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
            } else {
               Intent intent = new Intent(this$0.requireContext(), OTPScreenWebView.class);
               intent.putExtra("url", url);
               this$0.startActivity(intent);
            }
         }
      } catch (JSONException var7) {
         Log.d("status check error", var7.toString());
      }

   }

   private static final void postRequest$lambda$20(AddCardBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         FragmentAddCardBottomSheetBinding var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.ll1InvalidCardNumber.setVisibility(0);
         var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.textView4.setText((CharSequence)this$0.extractMessageFromErrorResponse(errorResponse));
         this$0.getMessageForFieldErrorItems(errorResponse);
         this$0.hideLoadingInButton();
         String errorMessage = String.valueOf(this$0.extractMessageFromErrorResponse(errorResponse));
         Log.d("Error message", errorMessage);
         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"Session is no longer accepting the payment as payment is already completed", true)) {
            var4 = this$0.binding;
            if (var4 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var4 = null;
            }

            var4.textView4.setText((CharSequence)"Payment is already done");
         }
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\r\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\tB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0016¨\u0006\n"},
      d2 = {"Lcom/example/tray/AddCardBottomSheet$AsteriskPasswordTransformationMethod;", "Landroid/text/method/PasswordTransformationMethod;", "<init>", "()V", "getTransformation", "", "source", "view", "Landroid/view/View;", "PasswordCharSequence", "Tray_release"}
   )
   public static final class AsteriskPasswordTransformationMethod extends PasswordTransformationMethod {
      @NotNull
      public CharSequence getTransformation(@NotNull CharSequence source, @NotNull View view) {
         Intrinsics.checkNotNullParameter(source, "source");
         Intrinsics.checkNotNullParameter(view, "view");
         return (CharSequence)(new AddCardBottomSheet.AsteriskPasswordTransformationMethod.PasswordCharSequence(source));
      }

      @Metadata(
         mv = {2, 0, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\r\n\u0002\b\u0004\n\u0002\u0010\f\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\b\u0082\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\u0011\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0096\u0002J\u0018\u0010\f\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\bH\u0016R\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\b8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000b¨\u0006\u000f"},
         d2 = {"Lcom/example/tray/AddCardBottomSheet$AsteriskPasswordTransformationMethod$PasswordCharSequence;", "", "source", "<init>", "(Lcom/example/tray/AddCardBottomSheet$AsteriskPasswordTransformationMethod;Ljava/lang/CharSequence;)V", "get", "", "index", "", "length", "getLength", "()I", "subSequence", "startIndex", "endIndex", "Tray_release"}
      )
      private final class PasswordCharSequence implements CharSequence {
         @NotNull
         private final CharSequence source;

         public PasswordCharSequence(@NotNull CharSequence source) {
            Intrinsics.checkNotNullParameter(source, "source");
            super();
            this.source = source;
         }

         public char get(int index) {
            return '*';
         }

         public int getLength() {
            return this.source.length();
         }

         @NotNull
         public CharSequence subSequence(int startIndex, int endIndex) {
            return this.source.subSequence(startIndex, endIndex);
         }
      }
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/AddCardBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
