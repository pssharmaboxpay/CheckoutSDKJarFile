package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentCancelConfirmationBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final CardView noButton;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout2;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final ProgressBar progressBar1;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView10;
   @NonNull
   public final TextView textView11;
   @NonNull
   public final TextView textView6;
   @NonNull
   public final TextView textView66;
   @NonNull
   public final CardView yesButton;

   private FragmentCancelConfirmationBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull ConstraintLayout constraintLayout123, @NonNull FrameLayout frameLayout1, @NonNull CardView noButton, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull RelativeLayout proceedButtonRelativeLayout2, @NonNull ProgressBar progressBar, @NonNull ProgressBar progressBar1, @NonNull TextView textView, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView6, @NonNull TextView textView66, @NonNull CardView yesButton) {
      this.rootView = rootView;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
      this.noButton = noButton;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.proceedButtonRelativeLayout2 = proceedButtonRelativeLayout2;
      this.progressBar = progressBar;
      this.progressBar1 = progressBar1;
      this.textView = textView;
      this.textView10 = textView10;
      this.textView11 = textView11;
      this.textView6 = textView6;
      this.textView66 = textView66;
      this.yesButton = yesButton;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentCancelConfirmationBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentCancelConfirmationBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_cancel_confirmation_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentCancelConfirmationBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.constraintLayout123;
      ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
      if (constraintLayout123 != null) {
         id = id.frameLayout1;
         FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
         if (frameLayout1 != null) {
            id = id.noButton;
            CardView noButton = (CardView)ViewBindings.findChildViewById(rootView, id);
            if (noButton != null) {
               id = id.proceedButtonRelativeLayout;
               RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
               if (proceedButtonRelativeLayout != null) {
                  id = id.proceedButtonRelativeLayout2;
                  RelativeLayout proceedButtonRelativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                  if (proceedButtonRelativeLayout2 != null) {
                     id = id.progressBar;
                     ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                     if (progressBar != null) {
                        id = id.progressBar1;
                        ProgressBar progressBar1 = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                        if (progressBar1 != null) {
                           id = id.textView;
                           TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                           if (textView != null) {
                              id = id.textView10;
                              TextView textView10 = (TextView)ViewBindings.findChildViewById(rootView, id);
                              if (textView10 != null) {
                                 id = id.textView11;
                                 TextView textView11 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                 if (textView11 != null) {
                                    id = id.textView6;
                                    TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                    if (textView6 != null) {
                                       id = id.textView66;
                                       TextView textView66 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                       if (textView66 != null) {
                                          id = id.yesButton;
                                          CardView yesButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                          if (yesButton != null) {
                                             return new FragmentCancelConfirmationBottomSheetBinding((CoordinatorLayout)rootView, constraintLayout123, frameLayout1, noButton, proceedButtonRelativeLayout, proceedButtonRelativeLayout2, progressBar, progressBar1, textView, textView10, textView11, textView6, textView66, yesButton);
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
