package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import com.example.tray.R.layout;

public final class ActivityTestingPurposeBinding implements ViewBinding {
   @NonNull
   private final ConstraintLayout rootView;

   private ActivityTestingPurposeBinding(@NonNull ConstraintLayout rootView) {
      this.rootView = rootView;
   }

   @NonNull
   public ConstraintLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static ActivityTestingPurposeBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static ActivityTestingPurposeBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.activity_testing_purpose, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static ActivityTestingPurposeBinding bind(@NonNull View rootView) {
      if (rootView == null) {
         throw new NullPointerException("rootView");
      } else {
         return new ActivityTestingPurposeBinding((ConstraintLayout)rootView);
      }
   }
}
