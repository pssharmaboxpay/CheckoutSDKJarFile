package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentNetBankingBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LinearLayout backButton;
   @NonNull
   public final RecyclerView banksRecyclerView;
   @NonNull
   public final LottieAnimationView boxPayLogoLottieAnimation;
   @NonNull
   public final CardView cardView;
   @NonNull
   public final TextView checkingTextView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final ConstraintLayout errorField;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final ImageView imageView;
   @NonNull
   public final ImageView imageView5;
   @NonNull
   public final LinearLayout linearLayout2;
   @NonNull
   public final RelativeLayout loadingRelativeLayout;
   @NonNull
   public final NestedScrollView nestedScrollView;
   @NonNull
   public final TextView noResultsFoundTextView;
   @NonNull
   public final ConstraintLayout popularBanksConstraintLayout1;
   @NonNull
   public final ConstraintLayout popularBanksConstraintLayout2;
   @NonNull
   public final ConstraintLayout popularBanksConstraintLayout3;
   @NonNull
   public final ConstraintLayout popularBanksConstraintLayout4;
   @NonNull
   public final ImageView popularBanksImageView1;
   @NonNull
   public final ImageView popularBanksImageView2;
   @NonNull
   public final ImageView popularBanksImageView3;
   @NonNull
   public final ImageView popularBanksImageView4;
   @NonNull
   public final TextView popularBanksNameTextView1;
   @NonNull
   public final TextView popularBanksNameTextView2;
   @NonNull
   public final TextView popularBanksNameTextView3;
   @NonNull
   public final TextView popularBanksNameTextView4;
   @NonNull
   public final RelativeLayout popularBanksRelativeLayout1;
   @NonNull
   public final RelativeLayout popularBanksRelativeLayout2;
   @NonNull
   public final RelativeLayout popularBanksRelativeLayout3;
   @NonNull
   public final RelativeLayout popularBanksRelativeLayout4;
   @NonNull
   public final CardView proceedButton;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final SearchView searchView;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView19;
   @NonNull
   public final TextView textView24;
   @NonNull
   public final TextView textView4;
   @NonNull
   public final TextView textView6;

   private FragmentNetBankingBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull LinearLayout backButton, @NonNull RecyclerView banksRecyclerView, @NonNull LottieAnimationView boxPayLogoLottieAnimation, @NonNull CardView cardView, @NonNull TextView checkingTextView, @NonNull ConstraintLayout constraintLayout123, @NonNull ConstraintLayout errorField, @NonNull FrameLayout frameLayout1, @NonNull ImageView imageView, @NonNull ImageView imageView5, @NonNull LinearLayout linearLayout2, @NonNull RelativeLayout loadingRelativeLayout, @NonNull NestedScrollView nestedScrollView, @NonNull TextView noResultsFoundTextView, @NonNull ConstraintLayout popularBanksConstraintLayout1, @NonNull ConstraintLayout popularBanksConstraintLayout2, @NonNull ConstraintLayout popularBanksConstraintLayout3, @NonNull ConstraintLayout popularBanksConstraintLayout4, @NonNull ImageView popularBanksImageView1, @NonNull ImageView popularBanksImageView2, @NonNull ImageView popularBanksImageView3, @NonNull ImageView popularBanksImageView4, @NonNull TextView popularBanksNameTextView1, @NonNull TextView popularBanksNameTextView2, @NonNull TextView popularBanksNameTextView3, @NonNull TextView popularBanksNameTextView4, @NonNull RelativeLayout popularBanksRelativeLayout1, @NonNull RelativeLayout popularBanksRelativeLayout2, @NonNull RelativeLayout popularBanksRelativeLayout3, @NonNull RelativeLayout popularBanksRelativeLayout4, @NonNull CardView proceedButton, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull SearchView searchView, @NonNull TextView textView, @NonNull TextView textView19, @NonNull TextView textView24, @NonNull TextView textView4, @NonNull TextView textView6) {
      this.rootView = rootView;
      this.backButton = backButton;
      this.banksRecyclerView = banksRecyclerView;
      this.boxPayLogoLottieAnimation = boxPayLogoLottieAnimation;
      this.cardView = cardView;
      this.checkingTextView = checkingTextView;
      this.constraintLayout123 = constraintLayout123;
      this.errorField = errorField;
      this.frameLayout1 = frameLayout1;
      this.imageView = imageView;
      this.imageView5 = imageView5;
      this.linearLayout2 = linearLayout2;
      this.loadingRelativeLayout = loadingRelativeLayout;
      this.nestedScrollView = nestedScrollView;
      this.noResultsFoundTextView = noResultsFoundTextView;
      this.popularBanksConstraintLayout1 = popularBanksConstraintLayout1;
      this.popularBanksConstraintLayout2 = popularBanksConstraintLayout2;
      this.popularBanksConstraintLayout3 = popularBanksConstraintLayout3;
      this.popularBanksConstraintLayout4 = popularBanksConstraintLayout4;
      this.popularBanksImageView1 = popularBanksImageView1;
      this.popularBanksImageView2 = popularBanksImageView2;
      this.popularBanksImageView3 = popularBanksImageView3;
      this.popularBanksImageView4 = popularBanksImageView4;
      this.popularBanksNameTextView1 = popularBanksNameTextView1;
      this.popularBanksNameTextView2 = popularBanksNameTextView2;
      this.popularBanksNameTextView3 = popularBanksNameTextView3;
      this.popularBanksNameTextView4 = popularBanksNameTextView4;
      this.popularBanksRelativeLayout1 = popularBanksRelativeLayout1;
      this.popularBanksRelativeLayout2 = popularBanksRelativeLayout2;
      this.popularBanksRelativeLayout3 = popularBanksRelativeLayout3;
      this.popularBanksRelativeLayout4 = popularBanksRelativeLayout4;
      this.proceedButton = proceedButton;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.searchView = searchView;
      this.textView = textView;
      this.textView19 = textView19;
      this.textView24 = textView24;
      this.textView4 = textView4;
      this.textView6 = textView6;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentNetBankingBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentNetBankingBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_net_banking_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentNetBankingBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.backButton;
      LinearLayout backButton = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
      if (backButton != null) {
         id = id.banksRecyclerView;
         RecyclerView banksRecyclerView = (RecyclerView)ViewBindings.findChildViewById(rootView, id);
         if (banksRecyclerView != null) {
            id = id.boxPayLogoLottieAnimation;
            LottieAnimationView boxPayLogoLottieAnimation = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
            if (boxPayLogoLottieAnimation != null) {
               id = id.cardView;
               CardView cardView = (CardView)ViewBindings.findChildViewById(rootView, id);
               if (cardView != null) {
                  id = id.checkingTextView;
                  TextView checkingTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                  if (checkingTextView != null) {
                     id = id.constraintLayout123;
                     ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                     if (constraintLayout123 != null) {
                        id = id.errorField;
                        ConstraintLayout errorField = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                        if (errorField != null) {
                           id = id.frameLayout1;
                           FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                           if (frameLayout1 != null) {
                              id = id.imageView;
                              ImageView imageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                              if (imageView != null) {
                                 id = id.imageView5;
                                 ImageView imageView5 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                 if (imageView5 != null) {
                                    id = id.linearLayout2;
                                    LinearLayout linearLayout2 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                    if (linearLayout2 != null) {
                                       id = id.loading_relative_layout;
                                       RelativeLayout loadingRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                       if (loadingRelativeLayout != null) {
                                          id = id.nestedScrollView;
                                          NestedScrollView nestedScrollView = (NestedScrollView)ViewBindings.findChildViewById(rootView, id);
                                          if (nestedScrollView != null) {
                                             id = id.noResultsFoundTextView;
                                             TextView noResultsFoundTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                             if (noResultsFoundTextView != null) {
                                                id = id.popularBanksConstraintLayout1;
                                                ConstraintLayout popularBanksConstraintLayout1 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                if (popularBanksConstraintLayout1 != null) {
                                                   id = id.popularBanksConstraintLayout2;
                                                   ConstraintLayout popularBanksConstraintLayout2 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                   if (popularBanksConstraintLayout2 != null) {
                                                      id = id.popularBanksConstraintLayout3;
                                                      ConstraintLayout popularBanksConstraintLayout3 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                      if (popularBanksConstraintLayout3 != null) {
                                                         id = id.popularBanksConstraintLayout4;
                                                         ConstraintLayout popularBanksConstraintLayout4 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                         if (popularBanksConstraintLayout4 != null) {
                                                            id = id.popularBanksImageView1;
                                                            ImageView popularBanksImageView1 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                            if (popularBanksImageView1 != null) {
                                                               id = id.popularBanksImageView2;
                                                               ImageView popularBanksImageView2 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                               if (popularBanksImageView2 != null) {
                                                                  id = id.popularBanksImageView3;
                                                                  ImageView popularBanksImageView3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                  if (popularBanksImageView3 != null) {
                                                                     id = id.popularBanksImageView4;
                                                                     ImageView popularBanksImageView4 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                     if (popularBanksImageView4 != null) {
                                                                        id = id.popularBanksNameTextView1;
                                                                        TextView popularBanksNameTextView1 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                        if (popularBanksNameTextView1 != null) {
                                                                           id = id.popularBanksNameTextView2;
                                                                           TextView popularBanksNameTextView2 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                           if (popularBanksNameTextView2 != null) {
                                                                              id = id.popularBanksNameTextView3;
                                                                              TextView popularBanksNameTextView3 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                              if (popularBanksNameTextView3 != null) {
                                                                                 id = id.popularBanksNameTextView4;
                                                                                 TextView popularBanksNameTextView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                 if (popularBanksNameTextView4 != null) {
                                                                                    id = id.popularBanksRelativeLayout1;
                                                                                    RelativeLayout popularBanksRelativeLayout1 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                    if (popularBanksRelativeLayout1 != null) {
                                                                                       id = id.popularBanksRelativeLayout2;
                                                                                       RelativeLayout popularBanksRelativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                       if (popularBanksRelativeLayout2 != null) {
                                                                                          id = id.popularBanksRelativeLayout3;
                                                                                          RelativeLayout popularBanksRelativeLayout3 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                          if (popularBanksRelativeLayout3 != null) {
                                                                                             id = id.popularBanksRelativeLayout4;
                                                                                             RelativeLayout popularBanksRelativeLayout4 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                             if (popularBanksRelativeLayout4 != null) {
                                                                                                id = id.proceedButton;
                                                                                                CardView proceedButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                                                                if (proceedButton != null) {
                                                                                                   id = id.proceedButtonRelativeLayout;
                                                                                                   RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                   if (proceedButtonRelativeLayout != null) {
                                                                                                      id = id.progressBar;
                                                                                                      ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                                                                                                      if (progressBar != null) {
                                                                                                         id = id.searchView;
                                                                                                         SearchView searchView = (SearchView)ViewBindings.findChildViewById(rootView, id);
                                                                                                         if (searchView != null) {
                                                                                                            id = id.textView;
                                                                                                            TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                            if (textView != null) {
                                                                                                               id = id.textView19;
                                                                                                               TextView textView19 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                               if (textView19 != null) {
                                                                                                                  id = id.textView24;
                                                                                                                  TextView textView24 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                  if (textView24 != null) {
                                                                                                                     id = id.textView4;
                                                                                                                     TextView textView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                     if (textView4 != null) {
                                                                                                                        id = id.textView6;
                                                                                                                        TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                        if (textView6 != null) {
                                                                                                                           return new FragmentNetBankingBottomSheetBinding((CoordinatorLayout)rootView, backButton, banksRecyclerView, boxPayLogoLottieAnimation, cardView, checkingTextView, constraintLayout123, errorField, frameLayout1, imageView, imageView5, linearLayout2, loadingRelativeLayout, nestedScrollView, noResultsFoundTextView, popularBanksConstraintLayout1, popularBanksConstraintLayout2, popularBanksConstraintLayout3, popularBanksConstraintLayout4, popularBanksImageView1, popularBanksImageView2, popularBanksImageView3, popularBanksImageView4, popularBanksNameTextView1, popularBanksNameTextView2, popularBanksNameTextView3, popularBanksNameTextView4, popularBanksRelativeLayout1, popularBanksRelativeLayout2, popularBanksRelativeLayout3, popularBanksRelativeLayout4, proceedButton, proceedButtonRelativeLayout, progressBar, searchView, textView, textView19, textView24, textView4, textView6);
                                                                                                                        }
                                                                                                                     }
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
