package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.example.tray.R.layout;

public final class CustomRadioButtonLayoutBinding implements ViewBinding {
   @NonNull
   private final RadioButton rootView;
   @NonNull
   public final RadioButton customRadioButton;

   private CustomRadioButtonLayoutBinding(@NonNull RadioButton rootView, @NonNull RadioButton customRadioButton) {
      this.rootView = rootView;
      this.customRadioButton = customRadioButton;
   }

   @NonNull
   public RadioButton getRoot() {
      return this.rootView;
   }

   @NonNull
   public static CustomRadioButtonLayoutBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static CustomRadioButtonLayoutBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.custom_radio_button_layout, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static CustomRadioButtonLayoutBinding bind(@NonNull View rootView) {
      if (rootView == null) {
         throw new NullPointerException("rootView");
      } else {
         RadioButton customRadioButton = (RadioButton)rootView;
         return new CustomRadioButtonLayoutBinding((RadioButton)rootView, customRadioButton);
      }
   }
}
