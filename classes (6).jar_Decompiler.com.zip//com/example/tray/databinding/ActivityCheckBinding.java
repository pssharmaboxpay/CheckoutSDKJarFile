package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class ActivityCheckBinding implements ViewBinding {
   @NonNull
   private final ConstraintLayout rootView;
   @NonNull
   public final CardView openButton;
   @NonNull
   public final TextView pleaseWaitTextView;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final TextView textView6;

   private ActivityCheckBinding(@NonNull ConstraintLayout rootView, @NonNull CardView openButton, @NonNull TextView pleaseWaitTextView, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull TextView textView6) {
      this.rootView = rootView;
      this.openButton = openButton;
      this.pleaseWaitTextView = pleaseWaitTextView;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.textView6 = textView6;
   }

   @NonNull
   public ConstraintLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static ActivityCheckBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static ActivityCheckBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.activity_check, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static ActivityCheckBinding bind(@NonNull View rootView) {
      int id = id.openButton;
      CardView openButton = (CardView)ViewBindings.findChildViewById(rootView, id);
      if (openButton != null) {
         id = id.pleaseWaitTextView;
         TextView pleaseWaitTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
         if (pleaseWaitTextView != null) {
            id = id.proceedButtonRelativeLayout;
            RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
            if (proceedButtonRelativeLayout != null) {
               id = id.progressBar;
               ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
               if (progressBar != null) {
                  id = id.textView6;
                  TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                  if (textView6 != null) {
                     return new ActivityCheckBinding((ConstraintLayout)rootView, openButton, pleaseWaitTextView, proceedButtonRelativeLayout, progressBar, textView6);
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
