package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.example.tray.R.layout;

public final class ActivityTrayBinding implements ViewBinding {
   @NonNull
   private final LinearLayout rootView;
   @NonNull
   public final LinearLayout clayout;

   private ActivityTrayBinding(@NonNull LinearLayout rootView, @NonNull LinearLayout clayout) {
      this.rootView = rootView;
      this.clayout = clayout;
   }

   @NonNull
   public LinearLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static ActivityTrayBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static ActivityTrayBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.activity_tray, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static ActivityTrayBinding bind(@NonNull View rootView) {
      if (rootView == null) {
         throw new NullPointerException("rootView");
      } else {
         LinearLayout clayout = (LinearLayout)rootView;
         return new ActivityTrayBinding((LinearLayout)rootView, clayout);
      }
   }
}
