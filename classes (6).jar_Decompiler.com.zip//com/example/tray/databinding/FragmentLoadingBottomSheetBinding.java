package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewbinding.ViewBinding;
import com.example.tray.R.layout;

public final class FragmentLoadingBottomSheetBinding implements ViewBinding {
   @NonNull
   private final FrameLayout rootView;

   private FragmentLoadingBottomSheetBinding(@NonNull FrameLayout rootView) {
      this.rootView = rootView;
   }

   @NonNull
   public FrameLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentLoadingBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentLoadingBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_loading_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentLoadingBottomSheetBinding bind(@NonNull View rootView) {
      if (rootView == null) {
         throw new NullPointerException("rootView");
      } else {
         return new FragmentLoadingBottomSheetBinding((FrameLayout)rootView);
      }
   }
}
