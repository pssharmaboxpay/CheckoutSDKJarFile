package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentBottomSheetLoadingSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LottieAnimationView boxpayLogoLottie;
   @NonNull
   public final RelativeLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;

   private FragmentBottomSheetLoadingSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull LottieAnimationView boxpayLogoLottie, @NonNull RelativeLayout constraintLayout123, @NonNull FrameLayout frameLayout1) {
      this.rootView = rootView;
      this.boxpayLogoLottie = boxpayLogoLottie;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentBottomSheetLoadingSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentBottomSheetLoadingSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_bottom_sheet_loading_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentBottomSheetLoadingSheetBinding bind(@NonNull View rootView) {
      int id = id.boxpayLogoLottie;
      LottieAnimationView boxpayLogoLottie = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
      if (boxpayLogoLottie != null) {
         id = id.constraintLayout123;
         RelativeLayout constraintLayout123 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
         if (constraintLayout123 != null) {
            id = id.frameLayout1;
            FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
            if (frameLayout1 != null) {
               return new FragmentBottomSheetLoadingSheetBinding((CoordinatorLayout)rootView, boxpayLogoLottie, constraintLayout123, frameLayout1);
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
