package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentPaymentStatusBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final LottieAnimationView lottieAnimationView;
   @NonNull
   public final RelativeLayout lottieAnimationViewConstraint;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView11;
   @NonNull
   public final TextView textView34;

   private FragmentPaymentStatusBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull ConstraintLayout constraintLayout123, @NonNull FrameLayout frameLayout1, @NonNull LottieAnimationView lottieAnimationView, @NonNull RelativeLayout lottieAnimationViewConstraint, @NonNull TextView textView, @NonNull TextView textView11, @NonNull TextView textView34) {
      this.rootView = rootView;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
      this.lottieAnimationView = lottieAnimationView;
      this.lottieAnimationViewConstraint = lottieAnimationViewConstraint;
      this.textView = textView;
      this.textView11 = textView11;
      this.textView34 = textView34;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentPaymentStatusBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentPaymentStatusBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_payment_status_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentPaymentStatusBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.constraintLayout123;
      ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
      if (constraintLayout123 != null) {
         id = id.frameLayout1;
         FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
         if (frameLayout1 != null) {
            id = id.lottieAnimationView;
            LottieAnimationView lottieAnimationView = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
            if (lottieAnimationView != null) {
               id = id.lottieAnimationViewConstraint;
               RelativeLayout lottieAnimationViewConstraint = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
               if (lottieAnimationViewConstraint != null) {
                  id = id.textView;
                  TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                  if (textView != null) {
                     id = id.textView11;
                     TextView textView11 = (TextView)ViewBindings.findChildViewById(rootView, id);
                     if (textView11 != null) {
                        id = id.textView34;
                        TextView textView34 = (TextView)ViewBindings.findChildViewById(rootView, id);
                        if (textView34 != null) {
                           return new FragmentPaymentStatusBottomSheetBinding((CoordinatorLayout)rootView, constraintLayout123, frameLayout1, lottieAnimationView, lottieAnimationViewConstraint, textView, textView11, textView34);
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
