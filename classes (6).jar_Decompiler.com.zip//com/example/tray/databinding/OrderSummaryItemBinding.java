package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class OrderSummaryItemBinding implements ViewBinding {
   @NonNull
   private final ConstraintLayout rootView;
   @NonNull
   public final View blackLine;
   @NonNull
   public final CardView cardView2;
   @NonNull
   public final ImageView itemImage;
   @NonNull
   public final TextView itemName;
   @NonNull
   public final TextView itemPrice;
   @NonNull
   public final TextView textView14;

   private OrderSummaryItemBinding(@NonNull ConstraintLayout rootView, @NonNull View blackLine, @NonNull CardView cardView2, @NonNull ImageView itemImage, @NonNull TextView itemName, @NonNull TextView itemPrice, @NonNull TextView textView14) {
      this.rootView = rootView;
      this.blackLine = blackLine;
      this.cardView2 = cardView2;
      this.itemImage = itemImage;
      this.itemName = itemName;
      this.itemPrice = itemPrice;
      this.textView14 = textView14;
   }

   @NonNull
   public ConstraintLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static OrderSummaryItemBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static OrderSummaryItemBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.order_summary_item, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static OrderSummaryItemBinding bind(@NonNull View rootView) {
      int id = id.blackLine;
      View blackLine = ViewBindings.findChildViewById(rootView, id);
      if (blackLine != null) {
         id = id.cardView2;
         CardView cardView2 = (CardView)ViewBindings.findChildViewById(rootView, id);
         if (cardView2 != null) {
            id = id.itemImage;
            ImageView itemImage = (ImageView)ViewBindings.findChildViewById(rootView, id);
            if (itemImage != null) {
               id = id.itemName;
               TextView itemName = (TextView)ViewBindings.findChildViewById(rootView, id);
               if (itemName != null) {
                  id = id.itemPrice;
                  TextView itemPrice = (TextView)ViewBindings.findChildViewById(rootView, id);
                  if (itemPrice != null) {
                     id = id.textView14;
                     TextView textView14 = (TextView)ViewBindings.findChildViewById(rootView, id);
                     if (textView14 != null) {
                        return new OrderSummaryItemBinding((ConstraintLayout)rootView, blackLine, cardView2, itemImage, itemName, itemPrice, textView14);
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
