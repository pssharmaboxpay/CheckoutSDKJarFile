package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentPaymentProcessingBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LottieAnimationView boxPayLogoLottieAnimation;
   @NonNull
   public final TextView cancelPaymentTextView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final TextView textView10;
   @NonNull
   public final TextView textView11;
   @NonNull
   public final TextView textView16;

   private FragmentPaymentProcessingBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull LottieAnimationView boxPayLogoLottieAnimation, @NonNull TextView cancelPaymentTextView, @NonNull ConstraintLayout constraintLayout123, @NonNull FrameLayout frameLayout1, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView16) {
      this.rootView = rootView;
      this.boxPayLogoLottieAnimation = boxPayLogoLottieAnimation;
      this.cancelPaymentTextView = cancelPaymentTextView;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
      this.textView10 = textView10;
      this.textView11 = textView11;
      this.textView16 = textView16;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentPaymentProcessingBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentPaymentProcessingBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_payment_processing_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentPaymentProcessingBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.boxPayLogoLottieAnimation;
      LottieAnimationView boxPayLogoLottieAnimation = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
      if (boxPayLogoLottieAnimation != null) {
         id = id.cancelPaymentTextView;
         TextView cancelPaymentTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
         if (cancelPaymentTextView != null) {
            id = id.constraintLayout123;
            ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
            if (constraintLayout123 != null) {
               id = id.frameLayout1;
               FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
               if (frameLayout1 != null) {
                  id = id.textView10;
                  TextView textView10 = (TextView)ViewBindings.findChildViewById(rootView, id);
                  if (textView10 != null) {
                     id = id.textView11;
                     TextView textView11 = (TextView)ViewBindings.findChildViewById(rootView, id);
                     if (textView11 != null) {
                        id = id.textView16;
                        TextView textView16 = (TextView)ViewBindings.findChildViewById(rootView, id);
                        if (textView16 != null) {
                           return new FragmentPaymentProcessingBottomSheetBinding((CoordinatorLayout)rootView, boxPayLogoLottieAnimation, cancelPaymentTextView, constraintLayout123, frameLayout1, textView10, textView11, textView16);
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
