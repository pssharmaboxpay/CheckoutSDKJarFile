package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentMainBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final TextView ItemsPrice;
   @NonNull
   public final LinearLayout PopularUPILinearLayout1;
   @NonNull
   public final LinearLayout PopularUPILinearLayout2;
   @NonNull
   public final LinearLayout PopularUPILinearLayout3;
   @NonNull
   public final LinearLayout PopularUPILinearLayout4;
   @NonNull
   public final ConstraintLayout UPIQRConstraint;
   @NonNull
   public final ConstraintLayout addNewUPIIDConstraint;
   @NonNull
   public final ImageView arrowIcon;
   @NonNull
   public final LinearLayout backButton;
   @NonNull
   public final View blackLine;
   @NonNull
   public final LottieAnimationView boxpayLogoLottie;
   @NonNull
   public final ConstraintLayout cardConstraint;
   @NonNull
   public final CardView cardView3;
   @NonNull
   public final CardView cardView4;
   @NonNull
   public final CardView cardView5;
   @NonNull
   public final CardView cardView6;
   @NonNull
   public final CardView cardView7;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final CoordinatorLayout coordinatorMainBottomSheet;
   @NonNull
   public final View dashedLine;
   @NonNull
   public final View dashedLine1;
   @NonNull
   public final View dashedLine3;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final ImageView imageView;
   @NonNull
   public final ImageView imageView10;
   @NonNull
   public final ImageView imageView11;
   @NonNull
   public final ImageView imageView12;
   @NonNull
   public final ImageView imageView13;
   @NonNull
   public final ImageView imageView15;
   @NonNull
   public final ImageView imageView16;
   @NonNull
   public final ImageView imageView17;
   @NonNull
   public final ImageView imageView21;
   @NonNull
   public final ImageView imageView23;
   @NonNull
   public final ImageView imageView25;
   @NonNull
   public final ImageView imageView27;
   @NonNull
   public final ImageView imageView28;
   @NonNull
   public final ImageView imageView37;
   @NonNull
   public final ImageView imageView38;
   @NonNull
   public final ImageView imageView39;
   @NonNull
   public final ImageView imageView4;
   @NonNull
   public final ImageView imageView8;
   @NonNull
   public final ImageView itemImage;
   @NonNull
   public final RecyclerView itemsInOrderRecyclerView;
   @NonNull
   public final LinearLayout linearLayout;
   @NonNull
   public final LinearLayout linearLayoutMain;
   @NonNull
   public final RelativeLayout loadingRelativeLayout;
   @NonNull
   public final ConstraintLayout netBankingConstraint;
   @NonNull
   public final TextView numberOfItems;
   @NonNull
   public final ConstraintLayout orderSummaryConstraintLayout;
   @NonNull
   public final FrameLayout overlayContainer;
   @NonNull
   public final ConstraintLayout payUsingAnyUPIConstraint;
   @NonNull
   public final TextView popularAppsTextView;
   @NonNull
   public final ConstraintLayout popularUPIAppsConstraint;
   @NonNull
   public final ImageView popularUPIImageView1;
   @NonNull
   public final ImageView popularUPIImageView2;
   @NonNull
   public final ImageView popularUPIImageView3;
   @NonNull
   public final ImageView popularUPIImageView4;
   @NonNull
   public final TextView popularUPITextView1;
   @NonNull
   public final TextView popularUPITextView2;
   @NonNull
   public final TextView popularUPITextView3;
   @NonNull
   public final TextView popularUPITextView4;
   @NonNull
   public final LinearLayout priceBreakUpDetailsLinearLayout;
   @NonNull
   public final ImageView qrCodeImageView;
   @NonNull
   public final ConstraintLayout qrCodeOpenConstraint;
   @NonNull
   public final TextView qrCodeTimer;
   @NonNull
   public final AppCompatButton refreshButton;
   @NonNull
   public final RelativeLayout shippingChargesRelativeLayout;
   @NonNull
   public final TextView shippingChargesTextView;
   @NonNull
   public final RelativeLayout subTotalRelativeLayout;
   @NonNull
   public final TextView subtotalTextView;
   @NonNull
   public final TextView taxTextView;
   @NonNull
   public final RelativeLayout taxesRelativeLayout;
   @NonNull
   public final TextView textView111;
   @NonNull
   public final TextView textView12;
   @NonNull
   public final TextView textView18;
   @NonNull
   public final TextView textView19;
   @NonNull
   public final TextView textView20;
   @NonNull
   public final TextView textView21;
   @NonNull
   public final TextView textView22;
   @NonNull
   public final TextView textView23;
   @NonNull
   public final TextView textView25;
   @NonNull
   public final TextView textView26;
   @NonNull
   public final TextView textView28;
   @NonNull
   public final TextView textView29;
   @NonNull
   public final TextView textView30;
   @NonNull
   public final TextView textView31;
   @NonNull
   public final TextView textView36;
   @NonNull
   public final TextView textView37;
   @NonNull
   public final TextView textView44;
   @NonNull
   public final TextView textView46;
   @NonNull
   public final TextView textView49;
   @NonNull
   public final TextView textView5;
   @NonNull
   public final TextView textView9;
   @NonNull
   public final ConstraintLayout topConstraint;
   @NonNull
   public final RelativeLayout totalValueRelativeLayout;
   @NonNull
   public final TextView unopenedTotalValue;
   @NonNull
   public final ConstraintLayout upiConstraint;
   @NonNull
   public final LinearLayout upiLinearLayout;
   @NonNull
   public final LinearLayout upiOptionsLinearLayout;
   @NonNull
   public final ConstraintLayout walletConstraint;

   private FragmentMainBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull TextView ItemsPrice, @NonNull LinearLayout PopularUPILinearLayout1, @NonNull LinearLayout PopularUPILinearLayout2, @NonNull LinearLayout PopularUPILinearLayout3, @NonNull LinearLayout PopularUPILinearLayout4, @NonNull ConstraintLayout UPIQRConstraint, @NonNull ConstraintLayout addNewUPIIDConstraint, @NonNull ImageView arrowIcon, @NonNull LinearLayout backButton, @NonNull View blackLine, @NonNull LottieAnimationView boxpayLogoLottie, @NonNull ConstraintLayout cardConstraint, @NonNull CardView cardView3, @NonNull CardView cardView4, @NonNull CardView cardView5, @NonNull CardView cardView6, @NonNull CardView cardView7, @NonNull ConstraintLayout constraintLayout123, @NonNull CoordinatorLayout coordinatorMainBottomSheet, @NonNull View dashedLine, @NonNull View dashedLine1, @NonNull View dashedLine3, @NonNull FrameLayout frameLayout1, @NonNull ImageView imageView, @NonNull ImageView imageView10, @NonNull ImageView imageView11, @NonNull ImageView imageView12, @NonNull ImageView imageView13, @NonNull ImageView imageView15, @NonNull ImageView imageView16, @NonNull ImageView imageView17, @NonNull ImageView imageView21, @NonNull ImageView imageView23, @NonNull ImageView imageView25, @NonNull ImageView imageView27, @NonNull ImageView imageView28, @NonNull ImageView imageView37, @NonNull ImageView imageView38, @NonNull ImageView imageView39, @NonNull ImageView imageView4, @NonNull ImageView imageView8, @NonNull ImageView itemImage, @NonNull RecyclerView itemsInOrderRecyclerView, @NonNull LinearLayout linearLayout, @NonNull LinearLayout linearLayoutMain, @NonNull RelativeLayout loadingRelativeLayout, @NonNull ConstraintLayout netBankingConstraint, @NonNull TextView numberOfItems, @NonNull ConstraintLayout orderSummaryConstraintLayout, @NonNull FrameLayout overlayContainer, @NonNull ConstraintLayout payUsingAnyUPIConstraint, @NonNull TextView popularAppsTextView, @NonNull ConstraintLayout popularUPIAppsConstraint, @NonNull ImageView popularUPIImageView1, @NonNull ImageView popularUPIImageView2, @NonNull ImageView popularUPIImageView3, @NonNull ImageView popularUPIImageView4, @NonNull TextView popularUPITextView1, @NonNull TextView popularUPITextView2, @NonNull TextView popularUPITextView3, @NonNull TextView popularUPITextView4, @NonNull LinearLayout priceBreakUpDetailsLinearLayout, @NonNull ImageView qrCodeImageView, @NonNull ConstraintLayout qrCodeOpenConstraint, @NonNull TextView qrCodeTimer, @NonNull AppCompatButton refreshButton, @NonNull RelativeLayout shippingChargesRelativeLayout, @NonNull TextView shippingChargesTextView, @NonNull RelativeLayout subTotalRelativeLayout, @NonNull TextView subtotalTextView, @NonNull TextView taxTextView, @NonNull RelativeLayout taxesRelativeLayout, @NonNull TextView textView111, @NonNull TextView textView12, @NonNull TextView textView18, @NonNull TextView textView19, @NonNull TextView textView20, @NonNull TextView textView21, @NonNull TextView textView22, @NonNull TextView textView23, @NonNull TextView textView25, @NonNull TextView textView26, @NonNull TextView textView28, @NonNull TextView textView29, @NonNull TextView textView30, @NonNull TextView textView31, @NonNull TextView textView36, @NonNull TextView textView37, @NonNull TextView textView44, @NonNull TextView textView46, @NonNull TextView textView49, @NonNull TextView textView5, @NonNull TextView textView9, @NonNull ConstraintLayout topConstraint, @NonNull RelativeLayout totalValueRelativeLayout, @NonNull TextView unopenedTotalValue, @NonNull ConstraintLayout upiConstraint, @NonNull LinearLayout upiLinearLayout, @NonNull LinearLayout upiOptionsLinearLayout, @NonNull ConstraintLayout walletConstraint) {
      this.rootView = rootView;
      this.ItemsPrice = ItemsPrice;
      this.PopularUPILinearLayout1 = PopularUPILinearLayout1;
      this.PopularUPILinearLayout2 = PopularUPILinearLayout2;
      this.PopularUPILinearLayout3 = PopularUPILinearLayout3;
      this.PopularUPILinearLayout4 = PopularUPILinearLayout4;
      this.UPIQRConstraint = UPIQRConstraint;
      this.addNewUPIIDConstraint = addNewUPIIDConstraint;
      this.arrowIcon = arrowIcon;
      this.backButton = backButton;
      this.blackLine = blackLine;
      this.boxpayLogoLottie = boxpayLogoLottie;
      this.cardConstraint = cardConstraint;
      this.cardView3 = cardView3;
      this.cardView4 = cardView4;
      this.cardView5 = cardView5;
      this.cardView6 = cardView6;
      this.cardView7 = cardView7;
      this.constraintLayout123 = constraintLayout123;
      this.coordinatorMainBottomSheet = coordinatorMainBottomSheet;
      this.dashedLine = dashedLine;
      this.dashedLine1 = dashedLine1;
      this.dashedLine3 = dashedLine3;
      this.frameLayout1 = frameLayout1;
      this.imageView = imageView;
      this.imageView10 = imageView10;
      this.imageView11 = imageView11;
      this.imageView12 = imageView12;
      this.imageView13 = imageView13;
      this.imageView15 = imageView15;
      this.imageView16 = imageView16;
      this.imageView17 = imageView17;
      this.imageView21 = imageView21;
      this.imageView23 = imageView23;
      this.imageView25 = imageView25;
      this.imageView27 = imageView27;
      this.imageView28 = imageView28;
      this.imageView37 = imageView37;
      this.imageView38 = imageView38;
      this.imageView39 = imageView39;
      this.imageView4 = imageView4;
      this.imageView8 = imageView8;
      this.itemImage = itemImage;
      this.itemsInOrderRecyclerView = itemsInOrderRecyclerView;
      this.linearLayout = linearLayout;
      this.linearLayoutMain = linearLayoutMain;
      this.loadingRelativeLayout = loadingRelativeLayout;
      this.netBankingConstraint = netBankingConstraint;
      this.numberOfItems = numberOfItems;
      this.orderSummaryConstraintLayout = orderSummaryConstraintLayout;
      this.overlayContainer = overlayContainer;
      this.payUsingAnyUPIConstraint = payUsingAnyUPIConstraint;
      this.popularAppsTextView = popularAppsTextView;
      this.popularUPIAppsConstraint = popularUPIAppsConstraint;
      this.popularUPIImageView1 = popularUPIImageView1;
      this.popularUPIImageView2 = popularUPIImageView2;
      this.popularUPIImageView3 = popularUPIImageView3;
      this.popularUPIImageView4 = popularUPIImageView4;
      this.popularUPITextView1 = popularUPITextView1;
      this.popularUPITextView2 = popularUPITextView2;
      this.popularUPITextView3 = popularUPITextView3;
      this.popularUPITextView4 = popularUPITextView4;
      this.priceBreakUpDetailsLinearLayout = priceBreakUpDetailsLinearLayout;
      this.qrCodeImageView = qrCodeImageView;
      this.qrCodeOpenConstraint = qrCodeOpenConstraint;
      this.qrCodeTimer = qrCodeTimer;
      this.refreshButton = refreshButton;
      this.shippingChargesRelativeLayout = shippingChargesRelativeLayout;
      this.shippingChargesTextView = shippingChargesTextView;
      this.subTotalRelativeLayout = subTotalRelativeLayout;
      this.subtotalTextView = subtotalTextView;
      this.taxTextView = taxTextView;
      this.taxesRelativeLayout = taxesRelativeLayout;
      this.textView111 = textView111;
      this.textView12 = textView12;
      this.textView18 = textView18;
      this.textView19 = textView19;
      this.textView20 = textView20;
      this.textView21 = textView21;
      this.textView22 = textView22;
      this.textView23 = textView23;
      this.textView25 = textView25;
      this.textView26 = textView26;
      this.textView28 = textView28;
      this.textView29 = textView29;
      this.textView30 = textView30;
      this.textView31 = textView31;
      this.textView36 = textView36;
      this.textView37 = textView37;
      this.textView44 = textView44;
      this.textView46 = textView46;
      this.textView49 = textView49;
      this.textView5 = textView5;
      this.textView9 = textView9;
      this.topConstraint = topConstraint;
      this.totalValueRelativeLayout = totalValueRelativeLayout;
      this.unopenedTotalValue = unopenedTotalValue;
      this.upiConstraint = upiConstraint;
      this.upiLinearLayout = upiLinearLayout;
      this.upiOptionsLinearLayout = upiOptionsLinearLayout;
      this.walletConstraint = walletConstraint;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentMainBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentMainBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_main_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentMainBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.ItemsPrice;
      TextView ItemsPrice = (TextView)ViewBindings.findChildViewById(rootView, id);
      if (ItemsPrice != null) {
         id = id.PopularUPILinearLayout1;
         LinearLayout PopularUPILinearLayout1 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
         if (PopularUPILinearLayout1 != null) {
            id = id.PopularUPILinearLayout2;
            LinearLayout PopularUPILinearLayout2 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
            if (PopularUPILinearLayout2 != null) {
               id = id.PopularUPILinearLayout3;
               LinearLayout PopularUPILinearLayout3 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
               if (PopularUPILinearLayout3 != null) {
                  id = id.PopularUPILinearLayout4;
                  LinearLayout PopularUPILinearLayout4 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                  if (PopularUPILinearLayout4 != null) {
                     id = id.UPIQRConstraint;
                     ConstraintLayout UPIQRConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                     if (UPIQRConstraint != null) {
                        id = id.addNewUPIIDConstraint;
                        ConstraintLayout addNewUPIIDConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                        if (addNewUPIIDConstraint != null) {
                           id = id.arrowIcon;
                           ImageView arrowIcon = (ImageView)ViewBindings.findChildViewById(rootView, id);
                           if (arrowIcon != null) {
                              id = id.backButton;
                              LinearLayout backButton = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                              if (backButton != null) {
                                 id = id.blackLine;
                                 View blackLine = ViewBindings.findChildViewById(rootView, id);
                                 if (blackLine != null) {
                                    id = id.boxpayLogoLottie;
                                    LottieAnimationView boxpayLogoLottie = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
                                    if (boxpayLogoLottie != null) {
                                       id = id.cardConstraint;
                                       ConstraintLayout cardConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                       if (cardConstraint != null) {
                                          id = id.cardView3;
                                          CardView cardView3 = (CardView)ViewBindings.findChildViewById(rootView, id);
                                          if (cardView3 != null) {
                                             id = id.cardView4;
                                             CardView cardView4 = (CardView)ViewBindings.findChildViewById(rootView, id);
                                             if (cardView4 != null) {
                                                id = id.cardView5;
                                                CardView cardView5 = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                if (cardView5 != null) {
                                                   id = id.cardView6;
                                                   CardView cardView6 = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                   if (cardView6 != null) {
                                                      id = id.cardView7;
                                                      CardView cardView7 = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                      if (cardView7 != null) {
                                                         id = id.constraintLayout123;
                                                         ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                         if (constraintLayout123 != null) {
                                                            CoordinatorLayout coordinatorMainBottomSheet = (CoordinatorLayout)rootView;
                                                            id = id.dashedLine;
                                                            View dashedLine = ViewBindings.findChildViewById(rootView, id);
                                                            if (dashedLine != null) {
                                                               id = id.dashedLine1;
                                                               View dashedLine1 = ViewBindings.findChildViewById(rootView, id);
                                                               if (dashedLine1 != null) {
                                                                  id = id.dashedLine3;
                                                                  View dashedLine3 = ViewBindings.findChildViewById(rootView, id);
                                                                  if (dashedLine3 != null) {
                                                                     id = id.frameLayout1;
                                                                     FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                                                                     if (frameLayout1 != null) {
                                                                        id = id.imageView;
                                                                        ImageView imageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                        if (imageView != null) {
                                                                           id = id.imageView10;
                                                                           ImageView imageView10 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                           if (imageView10 != null) {
                                                                              id = id.imageView11;
                                                                              ImageView imageView11 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                              if (imageView11 != null) {
                                                                                 id = id.imageView12;
                                                                                 ImageView imageView12 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                 if (imageView12 != null) {
                                                                                    id = id.imageView13;
                                                                                    ImageView imageView13 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                    if (imageView13 != null) {
                                                                                       id = id.imageView15;
                                                                                       ImageView imageView15 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                       if (imageView15 != null) {
                                                                                          id = id.imageView16;
                                                                                          ImageView imageView16 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                          if (imageView16 != null) {
                                                                                             id = id.imageView17;
                                                                                             ImageView imageView17 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                             if (imageView17 != null) {
                                                                                                id = id.imageView21;
                                                                                                ImageView imageView21 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                if (imageView21 != null) {
                                                                                                   id = id.imageView23;
                                                                                                   ImageView imageView23 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                   if (imageView23 != null) {
                                                                                                      id = id.imageView25;
                                                                                                      ImageView imageView25 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                      if (imageView25 != null) {
                                                                                                         id = id.imageView27;
                                                                                                         ImageView imageView27 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                         if (imageView27 != null) {
                                                                                                            id = id.imageView28;
                                                                                                            ImageView imageView28 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                            if (imageView28 != null) {
                                                                                                               id = id.imageView37;
                                                                                                               ImageView imageView37 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                               if (imageView37 != null) {
                                                                                                                  id = id.imageView38;
                                                                                                                  ImageView imageView38 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                  if (imageView38 != null) {
                                                                                                                     id = id.imageView39;
                                                                                                                     ImageView imageView39 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                     if (imageView39 != null) {
                                                                                                                        id = id.imageView4;
                                                                                                                        ImageView imageView4 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                        if (imageView4 != null) {
                                                                                                                           id = id.imageView8;
                                                                                                                           ImageView imageView8 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                           if (imageView8 != null) {
                                                                                                                              id = id.itemImage;
                                                                                                                              ImageView itemImage = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                              if (itemImage != null) {
                                                                                                                                 id = id.itemsInOrderRecyclerView;
                                                                                                                                 RecyclerView itemsInOrderRecyclerView = (RecyclerView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                 if (itemsInOrderRecyclerView != null) {
                                                                                                                                    id = id.linearLayout;
                                                                                                                                    LinearLayout linearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                    if (linearLayout != null) {
                                                                                                                                       id = id.linearLayoutMain;
                                                                                                                                       LinearLayout linearLayoutMain = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                       if (linearLayoutMain != null) {
                                                                                                                                          id = id.loadingRelativeLayout;
                                                                                                                                          RelativeLayout loadingRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                          if (loadingRelativeLayout != null) {
                                                                                                                                             id = id.netBankingConstraint;
                                                                                                                                             ConstraintLayout netBankingConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                             if (netBankingConstraint != null) {
                                                                                                                                                id = id.numberOfItems;
                                                                                                                                                TextView numberOfItems = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                if (numberOfItems != null) {
                                                                                                                                                   id = id.orderSummaryConstraintLayout;
                                                                                                                                                   ConstraintLayout orderSummaryConstraintLayout = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                   if (orderSummaryConstraintLayout != null) {
                                                                                                                                                      id = id.overlayContainer;
                                                                                                                                                      FrameLayout overlayContainer = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                      if (overlayContainer != null) {
                                                                                                                                                         id = id.payUsingAnyUPIConstraint;
                                                                                                                                                         ConstraintLayout payUsingAnyUPIConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                         if (payUsingAnyUPIConstraint != null) {
                                                                                                                                                            id = id.popularAppsTextView;
                                                                                                                                                            TextView popularAppsTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                            if (popularAppsTextView != null) {
                                                                                                                                                               id = id.popularUPIAppsConstraint;
                                                                                                                                                               ConstraintLayout popularUPIAppsConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                               if (popularUPIAppsConstraint != null) {
                                                                                                                                                                  id = id.popularUPIImageView1;
                                                                                                                                                                  ImageView popularUPIImageView1 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                  if (popularUPIImageView1 != null) {
                                                                                                                                                                     id = id.popularUPIImageView2;
                                                                                                                                                                     ImageView popularUPIImageView2 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                     if (popularUPIImageView2 != null) {
                                                                                                                                                                        id = id.popularUPIImageView3;
                                                                                                                                                                        ImageView popularUPIImageView3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                        if (popularUPIImageView3 != null) {
                                                                                                                                                                           id = id.popularUPIImageView4;
                                                                                                                                                                           ImageView popularUPIImageView4 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                           if (popularUPIImageView4 != null) {
                                                                                                                                                                              id = id.popularUPITextView1;
                                                                                                                                                                              TextView popularUPITextView1 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                              if (popularUPITextView1 != null) {
                                                                                                                                                                                 id = id.popularUPITextView2;
                                                                                                                                                                                 TextView popularUPITextView2 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                 if (popularUPITextView2 != null) {
                                                                                                                                                                                    id = id.popularUPITextView3;
                                                                                                                                                                                    TextView popularUPITextView3 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                    if (popularUPITextView3 != null) {
                                                                                                                                                                                       id = id.popularUPITextView4;
                                                                                                                                                                                       TextView popularUPITextView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                       if (popularUPITextView4 != null) {
                                                                                                                                                                                          id = id.priceBreakUpDetailsLinearLayout;
                                                                                                                                                                                          LinearLayout priceBreakUpDetailsLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                          if (priceBreakUpDetailsLinearLayout != null) {
                                                                                                                                                                                             id = id.qrCodeImageView;
                                                                                                                                                                                             ImageView qrCodeImageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                             if (qrCodeImageView != null) {
                                                                                                                                                                                                id = id.qrCodeOpenConstraint;
                                                                                                                                                                                                ConstraintLayout qrCodeOpenConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                if (qrCodeOpenConstraint != null) {
                                                                                                                                                                                                   id = id.qrCodeTimer;
                                                                                                                                                                                                   TextView qrCodeTimer = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                   if (qrCodeTimer != null) {
                                                                                                                                                                                                      id = id.refreshButton;
                                                                                                                                                                                                      AppCompatButton refreshButton = (AppCompatButton)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                      if (refreshButton != null) {
                                                                                                                                                                                                         id = id.shippingChargesRelativeLayout;
                                                                                                                                                                                                         RelativeLayout shippingChargesRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                         if (shippingChargesRelativeLayout != null) {
                                                                                                                                                                                                            id = id.shippingChargesTextView;
                                                                                                                                                                                                            TextView shippingChargesTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                            if (shippingChargesTextView != null) {
                                                                                                                                                                                                               id = id.subTotalRelativeLayout;
                                                                                                                                                                                                               RelativeLayout subTotalRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                               if (subTotalRelativeLayout != null) {
                                                                                                                                                                                                                  id = id.subtotalTextView;
                                                                                                                                                                                                                  TextView subtotalTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                  if (subtotalTextView != null) {
                                                                                                                                                                                                                     id = id.taxTextView;
                                                                                                                                                                                                                     TextView taxTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                     if (taxTextView != null) {
                                                                                                                                                                                                                        id = id.taxesRelativeLayout;
                                                                                                                                                                                                                        RelativeLayout taxesRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                        if (taxesRelativeLayout != null) {
                                                                                                                                                                                                                           id = id.textView111;
                                                                                                                                                                                                                           TextView textView111 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                           if (textView111 != null) {
                                                                                                                                                                                                                              id = id.textView12;
                                                                                                                                                                                                                              TextView textView12 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                              if (textView12 != null) {
                                                                                                                                                                                                                                 id = id.textView18;
                                                                                                                                                                                                                                 TextView textView18 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                 if (textView18 != null) {
                                                                                                                                                                                                                                    id = id.textView19;
                                                                                                                                                                                                                                    TextView textView19 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                    if (textView19 != null) {
                                                                                                                                                                                                                                       id = id.textView20;
                                                                                                                                                                                                                                       TextView textView20 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                       if (textView20 != null) {
                                                                                                                                                                                                                                          id = id.textView21;
                                                                                                                                                                                                                                          TextView textView21 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                          if (textView21 != null) {
                                                                                                                                                                                                                                             id = id.textView22;
                                                                                                                                                                                                                                             TextView textView22 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                             if (textView22 != null) {
                                                                                                                                                                                                                                                id = id.textView23;
                                                                                                                                                                                                                                                TextView textView23 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                if (textView23 != null) {
                                                                                                                                                                                                                                                   id = id.textView25;
                                                                                                                                                                                                                                                   TextView textView25 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                   if (textView25 != null) {
                                                                                                                                                                                                                                                      id = id.textView26;
                                                                                                                                                                                                                                                      TextView textView26 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                      if (textView26 != null) {
                                                                                                                                                                                                                                                         id = id.textView28;
                                                                                                                                                                                                                                                         TextView textView28 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                         if (textView28 != null) {
                                                                                                                                                                                                                                                            id = id.textView29;
                                                                                                                                                                                                                                                            TextView textView29 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                            if (textView29 != null) {
                                                                                                                                                                                                                                                               id = id.textView30;
                                                                                                                                                                                                                                                               TextView textView30 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                               if (textView30 != null) {
                                                                                                                                                                                                                                                                  id = id.textView31;
                                                                                                                                                                                                                                                                  TextView textView31 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                  if (textView31 != null) {
                                                                                                                                                                                                                                                                     id = id.textView36;
                                                                                                                                                                                                                                                                     TextView textView36 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                     if (textView36 != null) {
                                                                                                                                                                                                                                                                        id = id.textView37;
                                                                                                                                                                                                                                                                        TextView textView37 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                        if (textView37 != null) {
                                                                                                                                                                                                                                                                           id = id.textView44;
                                                                                                                                                                                                                                                                           TextView textView44 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                           if (textView44 != null) {
                                                                                                                                                                                                                                                                              id = id.textView46;
                                                                                                                                                                                                                                                                              TextView textView46 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                              if (textView46 != null) {
                                                                                                                                                                                                                                                                                 id = id.textView49;
                                                                                                                                                                                                                                                                                 TextView textView49 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                 if (textView49 != null) {
                                                                                                                                                                                                                                                                                    id = id.textView5;
                                                                                                                                                                                                                                                                                    TextView textView5 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                    if (textView5 != null) {
                                                                                                                                                                                                                                                                                       id = id.textView9;
                                                                                                                                                                                                                                                                                       TextView textView9 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                       if (textView9 != null) {
                                                                                                                                                                                                                                                                                          id = id.topConstraint;
                                                                                                                                                                                                                                                                                          ConstraintLayout topConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                          if (topConstraint != null) {
                                                                                                                                                                                                                                                                                             id = id.totalValueRelativeLayout;
                                                                                                                                                                                                                                                                                             RelativeLayout totalValueRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                             if (totalValueRelativeLayout != null) {
                                                                                                                                                                                                                                                                                                id = id.unopenedTotalValue;
                                                                                                                                                                                                                                                                                                TextView unopenedTotalValue = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                                if (unopenedTotalValue != null) {
                                                                                                                                                                                                                                                                                                   id = id.upiConstraint;
                                                                                                                                                                                                                                                                                                   ConstraintLayout upiConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                                   if (upiConstraint != null) {
                                                                                                                                                                                                                                                                                                      id = id.upiLinearLayout;
                                                                                                                                                                                                                                                                                                      LinearLayout upiLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                                      if (upiLinearLayout != null) {
                                                                                                                                                                                                                                                                                                         id = id.upiOptionsLinearLayout;
                                                                                                                                                                                                                                                                                                         LinearLayout upiOptionsLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                                         if (upiOptionsLinearLayout != null) {
                                                                                                                                                                                                                                                                                                            id = id.walletConstraint;
                                                                                                                                                                                                                                                                                                            ConstraintLayout walletConstraint = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                                                                                                                                                                                            if (walletConstraint != null) {
                                                                                                                                                                                                                                                                                                               return new FragmentMainBottomSheetBinding((CoordinatorLayout)rootView, ItemsPrice, PopularUPILinearLayout1, PopularUPILinearLayout2, PopularUPILinearLayout3, PopularUPILinearLayout4, UPIQRConstraint, addNewUPIIDConstraint, arrowIcon, backButton, blackLine, boxpayLogoLottie, cardConstraint, cardView3, cardView4, cardView5, cardView6, cardView7, constraintLayout123, coordinatorMainBottomSheet, dashedLine, dashedLine1, dashedLine3, frameLayout1, imageView, imageView10, imageView11, imageView12, imageView13, imageView15, imageView16, imageView17, imageView21, imageView23, imageView25, imageView27, imageView28, imageView37, imageView38, imageView39, imageView4, imageView8, itemImage, itemsInOrderRecyclerView, linearLayout, linearLayoutMain, loadingRelativeLayout, netBankingConstraint, numberOfItems, orderSummaryConstraintLayout, overlayContainer, payUsingAnyUPIConstraint, popularAppsTextView, popularUPIAppsConstraint, popularUPIImageView1, popularUPIImageView2, popularUPIImageView3, popularUPIImageView4, popularUPITextView1, popularUPITextView2, popularUPITextView3, popularUPITextView4, priceBreakUpDetailsLinearLayout, qrCodeImageView, qrCodeOpenConstraint, qrCodeTimer, refreshButton, shippingChargesRelativeLayout, shippingChargesTextView, subTotalRelativeLayout, subtotalTextView, taxTextView, taxesRelativeLayout, textView111, textView12, textView18, textView19, textView20, textView21, textView22, textView23, textView25, textView26, textView28, textView29, textView30, textView31, textView36, textView37, textView44, textView46, textView49, textView5, textView9, topConstraint, totalValueRelativeLayout, unopenedTotalValue, upiConstraint, upiLinearLayout, upiOptionsLinearLayout, walletConstraint);
                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                  }
                                                                                                                                                                                                               }
                                                                                                                                                                                                            }
                                                                                                                                                                                                         }
                                                                                                                                                                                                      }
                                                                                                                                                                                                   }
                                                                                                                                                                                                }
                                                                                                                                                                                             }
                                                                                                                                                                                          }
                                                                                                                                                                                       }
                                                                                                                                                                                    }
                                                                                                                                                                                 }
                                                                                                                                                                              }
                                                                                                                                                                           }
                                                                                                                                                                        }
                                                                                                                                                                     }
                                                                                                                                                                  }
                                                                                                                                                               }
                                                                                                                                                            }
                                                                                                                                                         }
                                                                                                                                                      }
                                                                                                                                                   }
                                                                                                                                                }
                                                                                                                                             }
                                                                                                                                          }
                                                                                                                                       }
                                                                                                                                    }
                                                                                                                                 }
                                                                                                                              }
                                                                                                                           }
                                                                                                                        }
                                                                                                                     }
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
