package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.airbnb.lottie.LottieAnimationView;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentWalletBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LinearLayout backButton;
   @NonNull
   public final LottieAnimationView boxPayLogoLottieAnimation;
   @NonNull
   public final CardView cardView;
   @NonNull
   public final TextView checkingTextView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final ConstraintLayout errorField;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final ImageView imageView;
   @NonNull
   public final ImageView imageView5;
   @NonNull
   public final LinearLayout linearLayout2;
   @NonNull
   public final RelativeLayout loadingRelativeLayout;
   @NonNull
   public final NestedScrollView nestedScrollView;
   @NonNull
   public final TextView noResultsFoundTextView;
   @NonNull
   public final RelativeLayout popularItemRelativeLayout1;
   @NonNull
   public final RelativeLayout popularItemRelativeLayout2;
   @NonNull
   public final RelativeLayout popularItemRelativeLayout3;
   @NonNull
   public final RelativeLayout popularItemRelativeLayout4;
   @NonNull
   public final ConstraintLayout popularWalletConstraintLayout1;
   @NonNull
   public final ConstraintLayout popularWalletConstraintLayout2;
   @NonNull
   public final ConstraintLayout popularWalletConstraintLayout3;
   @NonNull
   public final ConstraintLayout popularWalletConstraintLayout4;
   @NonNull
   public final ImageView popularWalletImageView1;
   @NonNull
   public final ImageView popularWalletImageView2;
   @NonNull
   public final ImageView popularWalletImageView3;
   @NonNull
   public final ImageView popularWalletImageView4;
   @NonNull
   public final TextView popularWalletsNameTextView1;
   @NonNull
   public final TextView popularWalletsNameTextView2;
   @NonNull
   public final TextView popularWalletsNameTextView3;
   @NonNull
   public final TextView popularWalletsNameTextView4;
   @NonNull
   public final CardView proceedButton;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final RelativeLayout relativeLayout;
   @NonNull
   public final SearchView searchView;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView19;
   @NonNull
   public final TextView textView24;
   @NonNull
   public final TextView textView4;
   @NonNull
   public final TextView textView6;
   @NonNull
   public final RecyclerView walletsRecyclerView;

   private FragmentWalletBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull LinearLayout backButton, @NonNull LottieAnimationView boxPayLogoLottieAnimation, @NonNull CardView cardView, @NonNull TextView checkingTextView, @NonNull ConstraintLayout constraintLayout123, @NonNull ConstraintLayout errorField, @NonNull FrameLayout frameLayout1, @NonNull ImageView imageView, @NonNull ImageView imageView5, @NonNull LinearLayout linearLayout2, @NonNull RelativeLayout loadingRelativeLayout, @NonNull NestedScrollView nestedScrollView, @NonNull TextView noResultsFoundTextView, @NonNull RelativeLayout popularItemRelativeLayout1, @NonNull RelativeLayout popularItemRelativeLayout2, @NonNull RelativeLayout popularItemRelativeLayout3, @NonNull RelativeLayout popularItemRelativeLayout4, @NonNull ConstraintLayout popularWalletConstraintLayout1, @NonNull ConstraintLayout popularWalletConstraintLayout2, @NonNull ConstraintLayout popularWalletConstraintLayout3, @NonNull ConstraintLayout popularWalletConstraintLayout4, @NonNull ImageView popularWalletImageView1, @NonNull ImageView popularWalletImageView2, @NonNull ImageView popularWalletImageView3, @NonNull ImageView popularWalletImageView4, @NonNull TextView popularWalletsNameTextView1, @NonNull TextView popularWalletsNameTextView2, @NonNull TextView popularWalletsNameTextView3, @NonNull TextView popularWalletsNameTextView4, @NonNull CardView proceedButton, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull RelativeLayout relativeLayout, @NonNull SearchView searchView, @NonNull TextView textView, @NonNull TextView textView19, @NonNull TextView textView24, @NonNull TextView textView4, @NonNull TextView textView6, @NonNull RecyclerView walletsRecyclerView) {
      this.rootView = rootView;
      this.backButton = backButton;
      this.boxPayLogoLottieAnimation = boxPayLogoLottieAnimation;
      this.cardView = cardView;
      this.checkingTextView = checkingTextView;
      this.constraintLayout123 = constraintLayout123;
      this.errorField = errorField;
      this.frameLayout1 = frameLayout1;
      this.imageView = imageView;
      this.imageView5 = imageView5;
      this.linearLayout2 = linearLayout2;
      this.loadingRelativeLayout = loadingRelativeLayout;
      this.nestedScrollView = nestedScrollView;
      this.noResultsFoundTextView = noResultsFoundTextView;
      this.popularItemRelativeLayout1 = popularItemRelativeLayout1;
      this.popularItemRelativeLayout2 = popularItemRelativeLayout2;
      this.popularItemRelativeLayout3 = popularItemRelativeLayout3;
      this.popularItemRelativeLayout4 = popularItemRelativeLayout4;
      this.popularWalletConstraintLayout1 = popularWalletConstraintLayout1;
      this.popularWalletConstraintLayout2 = popularWalletConstraintLayout2;
      this.popularWalletConstraintLayout3 = popularWalletConstraintLayout3;
      this.popularWalletConstraintLayout4 = popularWalletConstraintLayout4;
      this.popularWalletImageView1 = popularWalletImageView1;
      this.popularWalletImageView2 = popularWalletImageView2;
      this.popularWalletImageView3 = popularWalletImageView3;
      this.popularWalletImageView4 = popularWalletImageView4;
      this.popularWalletsNameTextView1 = popularWalletsNameTextView1;
      this.popularWalletsNameTextView2 = popularWalletsNameTextView2;
      this.popularWalletsNameTextView3 = popularWalletsNameTextView3;
      this.popularWalletsNameTextView4 = popularWalletsNameTextView4;
      this.proceedButton = proceedButton;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.relativeLayout = relativeLayout;
      this.searchView = searchView;
      this.textView = textView;
      this.textView19 = textView19;
      this.textView24 = textView24;
      this.textView4 = textView4;
      this.textView6 = textView6;
      this.walletsRecyclerView = walletsRecyclerView;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentWalletBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentWalletBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_wallet_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentWalletBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.backButton;
      LinearLayout backButton = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
      if (backButton != null) {
         id = id.boxPayLogoLottieAnimation;
         LottieAnimationView boxPayLogoLottieAnimation = (LottieAnimationView)ViewBindings.findChildViewById(rootView, id);
         if (boxPayLogoLottieAnimation != null) {
            id = id.cardView;
            CardView cardView = (CardView)ViewBindings.findChildViewById(rootView, id);
            if (cardView != null) {
               id = id.checkingTextView;
               TextView checkingTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
               if (checkingTextView != null) {
                  id = id.constraintLayout123;
                  ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                  if (constraintLayout123 != null) {
                     id = id.errorField;
                     ConstraintLayout errorField = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                     if (errorField != null) {
                        id = id.frameLayout1;
                        FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                        if (frameLayout1 != null) {
                           id = id.imageView;
                           ImageView imageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                           if (imageView != null) {
                              id = id.imageView5;
                              ImageView imageView5 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                              if (imageView5 != null) {
                                 id = id.linearLayout2;
                                 LinearLayout linearLayout2 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                 if (linearLayout2 != null) {
                                    id = id.loading_relative_layout;
                                    RelativeLayout loadingRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                    if (loadingRelativeLayout != null) {
                                       id = id.nestedScrollView;
                                       NestedScrollView nestedScrollView = (NestedScrollView)ViewBindings.findChildViewById(rootView, id);
                                       if (nestedScrollView != null) {
                                          id = id.noResultsFoundTextView;
                                          TextView noResultsFoundTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                          if (noResultsFoundTextView != null) {
                                             id = id.popularItemRelativeLayout1;
                                             RelativeLayout popularItemRelativeLayout1 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                             if (popularItemRelativeLayout1 != null) {
                                                id = id.popularItemRelativeLayout2;
                                                RelativeLayout popularItemRelativeLayout2 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                if (popularItemRelativeLayout2 != null) {
                                                   id = id.popularItemRelativeLayout3;
                                                   RelativeLayout popularItemRelativeLayout3 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                   if (popularItemRelativeLayout3 != null) {
                                                      id = id.popularItemRelativeLayout4;
                                                      RelativeLayout popularItemRelativeLayout4 = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                      if (popularItemRelativeLayout4 != null) {
                                                         id = id.popularWalletConstraintLayout1;
                                                         ConstraintLayout popularWalletConstraintLayout1 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                         if (popularWalletConstraintLayout1 != null) {
                                                            id = id.popularWalletConstraintLayout2;
                                                            ConstraintLayout popularWalletConstraintLayout2 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                            if (popularWalletConstraintLayout2 != null) {
                                                               id = id.popularWalletConstraintLayout3;
                                                               ConstraintLayout popularWalletConstraintLayout3 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                               if (popularWalletConstraintLayout3 != null) {
                                                                  id = id.popularWalletConstraintLayout4;
                                                                  ConstraintLayout popularWalletConstraintLayout4 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                  if (popularWalletConstraintLayout4 != null) {
                                                                     id = id.popularWalletImageView1;
                                                                     ImageView popularWalletImageView1 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                     if (popularWalletImageView1 != null) {
                                                                        id = id.popularWalletImageView2;
                                                                        ImageView popularWalletImageView2 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                        if (popularWalletImageView2 != null) {
                                                                           id = id.popularWalletImageView3;
                                                                           ImageView popularWalletImageView3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                           if (popularWalletImageView3 != null) {
                                                                              id = id.popularWalletImageView4;
                                                                              ImageView popularWalletImageView4 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                              if (popularWalletImageView4 != null) {
                                                                                 id = id.popularWalletsNameTextView1;
                                                                                 TextView popularWalletsNameTextView1 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                 if (popularWalletsNameTextView1 != null) {
                                                                                    id = id.popularWalletsNameTextView2;
                                                                                    TextView popularWalletsNameTextView2 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                    if (popularWalletsNameTextView2 != null) {
                                                                                       id = id.popularWalletsNameTextView3;
                                                                                       TextView popularWalletsNameTextView3 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                       if (popularWalletsNameTextView3 != null) {
                                                                                          id = id.popularWalletsNameTextView4;
                                                                                          TextView popularWalletsNameTextView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                          if (popularWalletsNameTextView4 != null) {
                                                                                             id = id.proceedButton;
                                                                                             CardView proceedButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                                                             if (proceedButton != null) {
                                                                                                id = id.proceedButtonRelativeLayout;
                                                                                                RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                if (proceedButtonRelativeLayout != null) {
                                                                                                   id = id.progressBar;
                                                                                                   ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                                                                                                   if (progressBar != null) {
                                                                                                      id = id.relativeLayout;
                                                                                                      RelativeLayout relativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                      if (relativeLayout != null) {
                                                                                                         id = id.searchView;
                                                                                                         SearchView searchView = (SearchView)ViewBindings.findChildViewById(rootView, id);
                                                                                                         if (searchView != null) {
                                                                                                            id = id.textView;
                                                                                                            TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                            if (textView != null) {
                                                                                                               id = id.textView19;
                                                                                                               TextView textView19 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                               if (textView19 != null) {
                                                                                                                  id = id.textView24;
                                                                                                                  TextView textView24 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                  if (textView24 != null) {
                                                                                                                     id = id.textView4;
                                                                                                                     TextView textView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                     if (textView4 != null) {
                                                                                                                        id = id.textView6;
                                                                                                                        TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                        if (textView6 != null) {
                                                                                                                           id = id.walletsRecyclerView;
                                                                                                                           RecyclerView walletsRecyclerView = (RecyclerView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                           if (walletsRecyclerView != null) {
                                                                                                                              return new FragmentWalletBottomSheetBinding((CoordinatorLayout)rootView, backButton, boxPayLogoLottieAnimation, cardView, checkingTextView, constraintLayout123, errorField, frameLayout1, imageView, imageView5, linearLayout2, loadingRelativeLayout, nestedScrollView, noResultsFoundTextView, popularItemRelativeLayout1, popularItemRelativeLayout2, popularItemRelativeLayout3, popularItemRelativeLayout4, popularWalletConstraintLayout1, popularWalletConstraintLayout2, popularWalletConstraintLayout3, popularWalletConstraintLayout4, popularWalletImageView1, popularWalletImageView2, popularWalletImageView3, popularWalletImageView4, popularWalletsNameTextView1, popularWalletsNameTextView2, popularWalletsNameTextView3, popularWalletsNameTextView4, proceedButton, proceedButtonRelativeLayout, progressBar, relativeLayout, searchView, textView, textView19, textView24, textView4, textView6, walletsRecyclerView);
                                                                                                                           }
                                                                                                                        }
                                                                                                                     }
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
