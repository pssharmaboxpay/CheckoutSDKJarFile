package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class ActivityOtpscreenWebViewBinding implements ViewBinding {
   @NonNull
   private final ConstraintLayout rootView;
   @NonNull
   public final WebView webViewForOtpValidation;

   private ActivityOtpscreenWebViewBinding(@NonNull ConstraintLayout rootView, @NonNull WebView webViewForOtpValidation) {
      this.rootView = rootView;
      this.webViewForOtpValidation = webViewForOtpValidation;
   }

   @NonNull
   public ConstraintLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static ActivityOtpscreenWebViewBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static ActivityOtpscreenWebViewBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.activity_otpscreen_web_view, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static ActivityOtpscreenWebViewBinding bind(@NonNull View rootView) {
      int id = id.webViewForOtpValidation;
      WebView webViewForOtpValidation = (WebView)ViewBindings.findChildViewById(rootView, id);
      if (webViewForOtpValidation == null) {
         String missingId = rootView.getResources().getResourceName(id);
         throw new NullPointerException("Missing required view with ID: ".concat(missingId));
      } else {
         return new ActivityOtpscreenWebViewBinding((ConstraintLayout)rootView, webViewForOtpValidation);
      }
   }
}
