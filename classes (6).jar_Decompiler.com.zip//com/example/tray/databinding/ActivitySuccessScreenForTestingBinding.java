package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class ActivitySuccessScreenForTestingBinding implements ViewBinding {
   @NonNull
   private final ConstraintLayout rootView;
   @NonNull
   public final TextView tooltipText;

   private ActivitySuccessScreenForTestingBinding(@NonNull ConstraintLayout rootView, @NonNull TextView tooltipText) {
      this.rootView = rootView;
      this.tooltipText = tooltipText;
   }

   @NonNull
   public ConstraintLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static ActivitySuccessScreenForTestingBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static ActivitySuccessScreenForTestingBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.activity_success_screen_for_testing, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static ActivitySuccessScreenForTestingBinding bind(@NonNull View rootView) {
      int id = id.tooltip_text;
      TextView tooltipText = (TextView)ViewBindings.findChildViewById(rootView, id);
      if (tooltipText == null) {
         String missingId = rootView.getResources().getResourceName(id);
         throw new NullPointerException("Missing required view with ID: ".concat(missingId));
      } else {
         return new ActivitySuccessScreenForTestingBinding((ConstraintLayout)rootView, tooltipText);
      }
   }
}
