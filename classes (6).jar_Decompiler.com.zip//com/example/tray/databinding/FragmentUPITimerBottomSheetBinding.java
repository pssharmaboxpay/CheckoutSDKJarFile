package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

public final class FragmentUPITimerBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final CardView UPIIDCardView;
   @NonNull
   public final TextView UPIIDTextView;
   @NonNull
   public final TextView cancelPaymentTextView;
   @NonNull
   public final CircularProgressBar circularProgressBar;
   @NonNull
   public final ConstraintLayout constraintLayout;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final TextView progressTextView;
   @NonNull
   public final CardView retryButton;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView10;
   @NonNull
   public final TextView textView11;
   @NonNull
   public final TextView textView16;
   @NonNull
   public final TextView textView6;
   @NonNull
   public final ImageView upiTimerUPIIcon;

   private FragmentUPITimerBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull CardView UPIIDCardView, @NonNull TextView UPIIDTextView, @NonNull TextView cancelPaymentTextView, @NonNull CircularProgressBar circularProgressBar, @NonNull ConstraintLayout constraintLayout, @NonNull ConstraintLayout constraintLayout123, @NonNull FrameLayout frameLayout1, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull TextView progressTextView, @NonNull CardView retryButton, @NonNull TextView textView, @NonNull TextView textView10, @NonNull TextView textView11, @NonNull TextView textView16, @NonNull TextView textView6, @NonNull ImageView upiTimerUPIIcon) {
      this.rootView = rootView;
      this.UPIIDCardView = UPIIDCardView;
      this.UPIIDTextView = UPIIDTextView;
      this.cancelPaymentTextView = cancelPaymentTextView;
      this.circularProgressBar = circularProgressBar;
      this.constraintLayout = constraintLayout;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.progressTextView = progressTextView;
      this.retryButton = retryButton;
      this.textView = textView;
      this.textView10 = textView10;
      this.textView11 = textView11;
      this.textView16 = textView16;
      this.textView6 = textView6;
      this.upiTimerUPIIcon = upiTimerUPIIcon;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentUPITimerBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentUPITimerBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_u_p_i_timer_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentUPITimerBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.UPIID_CardView;
      CardView UPIIDCardView = (CardView)ViewBindings.findChildViewById(rootView, id);
      if (UPIIDCardView != null) {
         id = id.UPIIDTextView;
         TextView UPIIDTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
         if (UPIIDTextView != null) {
            id = id.cancelPaymentTextView;
            TextView cancelPaymentTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
            if (cancelPaymentTextView != null) {
               id = id.circularProgressBar;
               CircularProgressBar circularProgressBar = (CircularProgressBar)ViewBindings.findChildViewById(rootView, id);
               if (circularProgressBar != null) {
                  id = id.constraintLayout;
                  ConstraintLayout constraintLayout = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                  if (constraintLayout != null) {
                     id = id.constraintLayout123;
                     ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                     if (constraintLayout123 != null) {
                        id = id.frameLayout1;
                        FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                        if (frameLayout1 != null) {
                           id = id.proceedButtonRelativeLayout;
                           RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                           if (proceedButtonRelativeLayout != null) {
                              id = id.progressBar;
                              ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                              if (progressBar != null) {
                                 id = id.progressTextView;
                                 TextView progressTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                 if (progressTextView != null) {
                                    id = id.retryButton;
                                    CardView retryButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                    if (retryButton != null) {
                                       id = id.textView;
                                       TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                       if (textView != null) {
                                          id = id.textView10;
                                          TextView textView10 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                          if (textView10 != null) {
                                             id = id.textView11;
                                             TextView textView11 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                             if (textView11 != null) {
                                                id = id.textView16;
                                                TextView textView16 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                if (textView16 != null) {
                                                   id = id.textView6;
                                                   TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                   if (textView6 != null) {
                                                      id = id.upiTimerUPIIcon;
                                                      ImageView upiTimerUPIIcon = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                      if (upiTimerUPIIcon != null) {
                                                         return new FragmentUPITimerBottomSheetBinding((CoordinatorLayout)rootView, UPIIDCardView, UPIIDTextView, cancelPaymentTextView, circularProgressBar, constraintLayout, constraintLayout123, frameLayout1, proceedButtonRelativeLayout, progressBar, progressTextView, retryButton, textView, textView10, textView11, textView16, textView6, upiTimerUPIIcon);
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
