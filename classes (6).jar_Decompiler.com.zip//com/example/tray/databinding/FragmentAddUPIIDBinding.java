package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentAddUPIIDBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LinearLayout backButton;
   @NonNull
   public final CardView cardView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final EditText editText;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final ImageView imageView;
   @NonNull
   public final ImageView imageView3;
   @NonNull
   public final ImageView imageView5;
   @NonNull
   public final ConstraintLayout ll1InvalidUPI;
   @NonNull
   public final CardView proceedButton;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView2;
   @NonNull
   public final TextView textView3;
   @NonNull
   public final TextView textView4;
   @NonNull
   public final TextView textView6;
   @NonNull
   public final TextView textheadEnterUPI;

   private FragmentAddUPIIDBinding(@NonNull CoordinatorLayout rootView, @NonNull LinearLayout backButton, @NonNull CardView cardView, @NonNull ConstraintLayout constraintLayout123, @NonNull EditText editText, @NonNull FrameLayout frameLayout1, @NonNull ImageView imageView, @NonNull ImageView imageView3, @NonNull ImageView imageView5, @NonNull ConstraintLayout ll1InvalidUPI, @NonNull CardView proceedButton, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull TextView textView, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView6, @NonNull TextView textheadEnterUPI) {
      this.rootView = rootView;
      this.backButton = backButton;
      this.cardView = cardView;
      this.constraintLayout123 = constraintLayout123;
      this.editText = editText;
      this.frameLayout1 = frameLayout1;
      this.imageView = imageView;
      this.imageView3 = imageView3;
      this.imageView5 = imageView5;
      this.ll1InvalidUPI = ll1InvalidUPI;
      this.proceedButton = proceedButton;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.textView = textView;
      this.textView2 = textView2;
      this.textView3 = textView3;
      this.textView4 = textView4;
      this.textView6 = textView6;
      this.textheadEnterUPI = textheadEnterUPI;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentAddUPIIDBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentAddUPIIDBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_add_u_p_i_i_d, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentAddUPIIDBinding bind(@NonNull View rootView) {
      int id = id.backButton;
      LinearLayout backButton = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
      if (backButton != null) {
         id = id.cardView;
         CardView cardView = (CardView)ViewBindings.findChildViewById(rootView, id);
         if (cardView != null) {
            id = id.constraintLayout123;
            ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
            if (constraintLayout123 != null) {
               id = id.editText;
               EditText editText = (EditText)ViewBindings.findChildViewById(rootView, id);
               if (editText != null) {
                  id = id.frameLayout1;
                  FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                  if (frameLayout1 != null) {
                     id = id.imageView;
                     ImageView imageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                     if (imageView != null) {
                        id = id.imageView3;
                        ImageView imageView3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                        if (imageView3 != null) {
                           id = id.imageView5;
                           ImageView imageView5 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                           if (imageView5 != null) {
                              id = id.ll1InvalidUPI;
                              ConstraintLayout ll1InvalidUPI = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                              if (ll1InvalidUPI != null) {
                                 id = id.proceedButton;
                                 CardView proceedButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                 if (proceedButton != null) {
                                    id = id.proceedButtonRelativeLayout;
                                    RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                    if (proceedButtonRelativeLayout != null) {
                                       id = id.progressBar;
                                       ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                                       if (progressBar != null) {
                                          id = id.textView;
                                          TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                          if (textView != null) {
                                             id = id.textView2;
                                             TextView textView2 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                             if (textView2 != null) {
                                                id = id.textView3;
                                                TextView textView3 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                if (textView3 != null) {
                                                   id = id.textView4;
                                                   TextView textView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                   if (textView4 != null) {
                                                      id = id.textView6;
                                                      TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                      if (textView6 != null) {
                                                         id = id.texthead_Enter_UPI;
                                                         TextView textheadEnterUPI = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                         if (textheadEnterUPI != null) {
                                                            return new FragmentAddUPIIDBinding((CoordinatorLayout)rootView, backButton, cardView, constraintLayout123, editText, frameLayout1, imageView, imageView3, imageView5, ll1InvalidUPI, proceedButton, proceedButtonRelativeLayout, progressBar, textView, textView2, textView3, textView4, textView6, textheadEnterUPI);
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
