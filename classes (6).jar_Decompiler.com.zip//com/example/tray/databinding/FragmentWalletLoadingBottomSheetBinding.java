package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentWalletLoadingBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final FrameLayout frameLayout1;

   private FragmentWalletLoadingBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull ConstraintLayout constraintLayout123, @NonNull FrameLayout frameLayout1) {
      this.rootView = rootView;
      this.constraintLayout123 = constraintLayout123;
      this.frameLayout1 = frameLayout1;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentWalletLoadingBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentWalletLoadingBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_wallet_loading_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentWalletLoadingBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.constraintLayout123;
      ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
      if (constraintLayout123 != null) {
         id = id.frameLayout1;
         FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
         if (frameLayout1 != null) {
            return new FragmentWalletLoadingBottomSheetBinding((CoordinatorLayout)rootView, constraintLayout123, frameLayout1);
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
