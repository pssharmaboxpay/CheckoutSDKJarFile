package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class NetbankingBanksItemBinding implements ViewBinding {
   @NonNull
   private final CardView rootView;
   @NonNull
   public final ImageView bankLogo;
   @NonNull
   public final TextView bankNameTextView;
   @NonNull
   public final ImageView radioButton;

   private NetbankingBanksItemBinding(@NonNull CardView rootView, @NonNull ImageView bankLogo, @NonNull TextView bankNameTextView, @NonNull ImageView radioButton) {
      this.rootView = rootView;
      this.bankLogo = bankLogo;
      this.bankNameTextView = bankNameTextView;
      this.radioButton = radioButton;
   }

   @NonNull
   public CardView getRoot() {
      return this.rootView;
   }

   @NonNull
   public static NetbankingBanksItemBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static NetbankingBanksItemBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.netbanking_banks_item, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static NetbankingBanksItemBinding bind(@NonNull View rootView) {
      int id = id.bankLogo;
      ImageView bankLogo = (ImageView)ViewBindings.findChildViewById(rootView, id);
      if (bankLogo != null) {
         id = id.bankNameTextView;
         TextView bankNameTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
         if (bankNameTextView != null) {
            id = id.radioButton;
            ImageView radioButton = (ImageView)ViewBindings.findChildViewById(rootView, id);
            if (radioButton != null) {
               return new NetbankingBanksItemBinding((CardView)rootView, bankLogo, bankNameTextView, radioButton);
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
