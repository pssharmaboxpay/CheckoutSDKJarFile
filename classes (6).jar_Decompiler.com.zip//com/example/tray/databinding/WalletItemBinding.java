package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class WalletItemBinding implements ViewBinding {
   @NonNull
   private final CardView rootView;
   @NonNull
   public final View lineView;
   @NonNull
   public final ImageView radioButton;
   @NonNull
   public final ImageView walletLogo;
   @NonNull
   public final TextView walletNameTextView;

   private WalletItemBinding(@NonNull CardView rootView, @NonNull View lineView, @NonNull ImageView radioButton, @NonNull ImageView walletLogo, @NonNull TextView walletNameTextView) {
      this.rootView = rootView;
      this.lineView = lineView;
      this.radioButton = radioButton;
      this.walletLogo = walletLogo;
      this.walletNameTextView = walletNameTextView;
   }

   @NonNull
   public CardView getRoot() {
      return this.rootView;
   }

   @NonNull
   public static WalletItemBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static WalletItemBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.wallet_item, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static WalletItemBinding bind(@NonNull View rootView) {
      int id = id.lineView;
      View lineView = ViewBindings.findChildViewById(rootView, id);
      if (lineView != null) {
         id = id.radioButton;
         ImageView radioButton = (ImageView)ViewBindings.findChildViewById(rootView, id);
         if (radioButton != null) {
            id = id.walletLogo;
            ImageView walletLogo = (ImageView)ViewBindings.findChildViewById(rootView, id);
            if (walletLogo != null) {
               id = id.walletNameTextView;
               TextView walletNameTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
               if (walletNameTextView != null) {
                  return new WalletItemBinding((CardView)rootView, lineView, radioButton, walletLogo, walletNameTextView);
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
