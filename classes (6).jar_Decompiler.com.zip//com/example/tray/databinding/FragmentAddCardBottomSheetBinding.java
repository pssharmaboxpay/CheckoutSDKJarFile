package com.example.tray.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.example.tray.R.id;
import com.example.tray.R.layout;

public final class FragmentAddCardBottomSheetBinding implements ViewBinding {
   @NonNull
   private final CoordinatorLayout rootView;
   @NonNull
   public final LinearLayout backButton;
   @NonNull
   public final TextView cardCVVTextView;
   @NonNull
   public final ImageView cardNetwork1;
   @NonNull
   public final ImageView cardNetwork2;
   @NonNull
   public final ImageView cardNetwork3;
   @NonNull
   public final LinearLayout cardNetworkDrawableLinearLayout;
   @NonNull
   public final LinearLayout cardNumberLinearLayout;
   @NonNull
   public final TextView cardValidityTextView;
   @NonNull
   public final CardView cardView;
   @NonNull
   public final ConstraintLayout constraintLayout123;
   @NonNull
   public final LinearLayout defaultCardNetworkLinearLayout;
   @NonNull
   public final EditText editTextCardCVV;
   @NonNull
   public final EditText editTextCardNumber;
   @NonNull
   public final EditText editTextCardValidity;
   @NonNull
   public final EditText editTextNameOnCard;
   @NonNull
   public final LinearLayout fetchedCardNetwork;
   @NonNull
   public final FrameLayout frameLayout1;
   @NonNull
   public final ImageView imageView;
   @NonNull
   public final ImageView imageView10;
   @NonNull
   public final ImageView imageView3;
   @NonNull
   public final ImageView imageView5;
   @NonNull
   public final ImageView imageView6;
   @NonNull
   public final ImageView imageView7;
   @NonNull
   public final ConstraintLayout invalidCVV;
   @NonNull
   public final ConstraintLayout invalidCardValidity;
   @NonNull
   public final LinearLayout linearLayout3;
   @NonNull
   public final ConstraintLayout ll1InvalidCardNumber;
   @NonNull
   public final TextView nameOnCard;
   @NonNull
   public final LinearLayout nameOnCardErrorLayout;
   @NonNull
   public final CardView proceedButton;
   @NonNull
   public final RelativeLayout proceedButtonRelativeLayout;
   @NonNull
   public final ProgressBar progressBar;
   @NonNull
   public final LinearLayout saveCardLinearLayout;
   @NonNull
   public final TextView textView;
   @NonNull
   public final TextView textView17;
   @NonNull
   public final TextView textView2;
   @NonNull
   public final TextView textView3;
   @NonNull
   public final TextView textView4;
   @NonNull
   public final TextView textView6;
   @NonNull
   public final TextView textView7;
   @NonNull
   public final TextView textView8;
   @NonNull
   public final TextView textheadEnterUPI;

   private FragmentAddCardBottomSheetBinding(@NonNull CoordinatorLayout rootView, @NonNull LinearLayout backButton, @NonNull TextView cardCVVTextView, @NonNull ImageView cardNetwork1, @NonNull ImageView cardNetwork2, @NonNull ImageView cardNetwork3, @NonNull LinearLayout cardNetworkDrawableLinearLayout, @NonNull LinearLayout cardNumberLinearLayout, @NonNull TextView cardValidityTextView, @NonNull CardView cardView, @NonNull ConstraintLayout constraintLayout123, @NonNull LinearLayout defaultCardNetworkLinearLayout, @NonNull EditText editTextCardCVV, @NonNull EditText editTextCardNumber, @NonNull EditText editTextCardValidity, @NonNull EditText editTextNameOnCard, @NonNull LinearLayout fetchedCardNetwork, @NonNull FrameLayout frameLayout1, @NonNull ImageView imageView, @NonNull ImageView imageView10, @NonNull ImageView imageView3, @NonNull ImageView imageView5, @NonNull ImageView imageView6, @NonNull ImageView imageView7, @NonNull ConstraintLayout invalidCVV, @NonNull ConstraintLayout invalidCardValidity, @NonNull LinearLayout linearLayout3, @NonNull ConstraintLayout ll1InvalidCardNumber, @NonNull TextView nameOnCard, @NonNull LinearLayout nameOnCardErrorLayout, @NonNull CardView proceedButton, @NonNull RelativeLayout proceedButtonRelativeLayout, @NonNull ProgressBar progressBar, @NonNull LinearLayout saveCardLinearLayout, @NonNull TextView textView, @NonNull TextView textView17, @NonNull TextView textView2, @NonNull TextView textView3, @NonNull TextView textView4, @NonNull TextView textView6, @NonNull TextView textView7, @NonNull TextView textView8, @NonNull TextView textheadEnterUPI) {
      this.rootView = rootView;
      this.backButton = backButton;
      this.cardCVVTextView = cardCVVTextView;
      this.cardNetwork1 = cardNetwork1;
      this.cardNetwork2 = cardNetwork2;
      this.cardNetwork3 = cardNetwork3;
      this.cardNetworkDrawableLinearLayout = cardNetworkDrawableLinearLayout;
      this.cardNumberLinearLayout = cardNumberLinearLayout;
      this.cardValidityTextView = cardValidityTextView;
      this.cardView = cardView;
      this.constraintLayout123 = constraintLayout123;
      this.defaultCardNetworkLinearLayout = defaultCardNetworkLinearLayout;
      this.editTextCardCVV = editTextCardCVV;
      this.editTextCardNumber = editTextCardNumber;
      this.editTextCardValidity = editTextCardValidity;
      this.editTextNameOnCard = editTextNameOnCard;
      this.fetchedCardNetwork = fetchedCardNetwork;
      this.frameLayout1 = frameLayout1;
      this.imageView = imageView;
      this.imageView10 = imageView10;
      this.imageView3 = imageView3;
      this.imageView5 = imageView5;
      this.imageView6 = imageView6;
      this.imageView7 = imageView7;
      this.invalidCVV = invalidCVV;
      this.invalidCardValidity = invalidCardValidity;
      this.linearLayout3 = linearLayout3;
      this.ll1InvalidCardNumber = ll1InvalidCardNumber;
      this.nameOnCard = nameOnCard;
      this.nameOnCardErrorLayout = nameOnCardErrorLayout;
      this.proceedButton = proceedButton;
      this.proceedButtonRelativeLayout = proceedButtonRelativeLayout;
      this.progressBar = progressBar;
      this.saveCardLinearLayout = saveCardLinearLayout;
      this.textView = textView;
      this.textView17 = textView17;
      this.textView2 = textView2;
      this.textView3 = textView3;
      this.textView4 = textView4;
      this.textView6 = textView6;
      this.textView7 = textView7;
      this.textView8 = textView8;
      this.textheadEnterUPI = textheadEnterUPI;
   }

   @NonNull
   public CoordinatorLayout getRoot() {
      return this.rootView;
   }

   @NonNull
   public static FragmentAddCardBottomSheetBinding inflate(@NonNull LayoutInflater inflater) {
      return inflate(inflater, (ViewGroup)null, false);
   }

   @NonNull
   public static FragmentAddCardBottomSheetBinding inflate(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent, boolean attachToParent) {
      View root = inflater.inflate(layout.fragment_add_card_bottom_sheet, parent, false);
      if (attachToParent) {
         parent.addView(root);
      }

      return bind(root);
   }

   @NonNull
   public static FragmentAddCardBottomSheetBinding bind(@NonNull View rootView) {
      int id = id.backButton;
      LinearLayout backButton = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
      if (backButton != null) {
         id = id.cardCVVTextView;
         TextView cardCVVTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
         if (cardCVVTextView != null) {
            id = id.cardNetwork1;
            ImageView cardNetwork1 = (ImageView)ViewBindings.findChildViewById(rootView, id);
            if (cardNetwork1 != null) {
               id = id.cardNetwork2;
               ImageView cardNetwork2 = (ImageView)ViewBindings.findChildViewById(rootView, id);
               if (cardNetwork2 != null) {
                  id = id.cardNetwork3;
                  ImageView cardNetwork3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                  if (cardNetwork3 != null) {
                     id = id.cardNetworkDrawableLinearLayout;
                     LinearLayout cardNetworkDrawableLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                     if (cardNetworkDrawableLinearLayout != null) {
                        id = id.cardNumberLinearLayout;
                        LinearLayout cardNumberLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                        if (cardNumberLinearLayout != null) {
                           id = id.cardValidityTextView;
                           TextView cardValidityTextView = (TextView)ViewBindings.findChildViewById(rootView, id);
                           if (cardValidityTextView != null) {
                              id = id.cardView;
                              CardView cardView = (CardView)ViewBindings.findChildViewById(rootView, id);
                              if (cardView != null) {
                                 id = id.constraintLayout123;
                                 ConstraintLayout constraintLayout123 = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                 if (constraintLayout123 != null) {
                                    id = id.defaultCardNetworkLinearLayout;
                                    LinearLayout defaultCardNetworkLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                    if (defaultCardNetworkLinearLayout != null) {
                                       id = id.editTextCardCVV;
                                       EditText editTextCardCVV = (EditText)ViewBindings.findChildViewById(rootView, id);
                                       if (editTextCardCVV != null) {
                                          id = id.edit_text_card_number;
                                          EditText editTextCardNumber = (EditText)ViewBindings.findChildViewById(rootView, id);
                                          if (editTextCardNumber != null) {
                                             id = id.editTextCardValidity;
                                             EditText editTextCardValidity = (EditText)ViewBindings.findChildViewById(rootView, id);
                                             if (editTextCardValidity != null) {
                                                id = id.editTextNameOnCard;
                                                EditText editTextNameOnCard = (EditText)ViewBindings.findChildViewById(rootView, id);
                                                if (editTextNameOnCard != null) {
                                                   id = id.fetchedCardNetwork;
                                                   LinearLayout fetchedCardNetwork = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                   if (fetchedCardNetwork != null) {
                                                      id = id.frameLayout1;
                                                      FrameLayout frameLayout1 = (FrameLayout)ViewBindings.findChildViewById(rootView, id);
                                                      if (frameLayout1 != null) {
                                                         id = id.imageView;
                                                         ImageView imageView = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                         if (imageView != null) {
                                                            id = id.imageView10;
                                                            ImageView imageView10 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                            if (imageView10 != null) {
                                                               id = id.imageView3;
                                                               ImageView imageView3 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                               if (imageView3 != null) {
                                                                  id = id.imageView5;
                                                                  ImageView imageView5 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                  if (imageView5 != null) {
                                                                     id = id.imageView6;
                                                                     ImageView imageView6 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                     if (imageView6 != null) {
                                                                        id = id.imageView7;
                                                                        ImageView imageView7 = (ImageView)ViewBindings.findChildViewById(rootView, id);
                                                                        if (imageView7 != null) {
                                                                           id = id.invalidCVV;
                                                                           ConstraintLayout invalidCVV = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                           if (invalidCVV != null) {
                                                                              id = id.invalidCardValidity;
                                                                              ConstraintLayout invalidCardValidity = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                              if (invalidCardValidity != null) {
                                                                                 id = id.linearLayout3;
                                                                                 LinearLayout linearLayout3 = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                 if (linearLayout3 != null) {
                                                                                    id = id.ll1InvalidCardNumber;
                                                                                    ConstraintLayout ll1InvalidCardNumber = (ConstraintLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                    if (ll1InvalidCardNumber != null) {
                                                                                       id = id.nameOnCard;
                                                                                       TextView nameOnCard = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                       if (nameOnCard != null) {
                                                                                          id = id.nameOnCardErrorLayout;
                                                                                          LinearLayout nameOnCardErrorLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                          if (nameOnCardErrorLayout != null) {
                                                                                             id = id.proceedButton;
                                                                                             CardView proceedButton = (CardView)ViewBindings.findChildViewById(rootView, id);
                                                                                             if (proceedButton != null) {
                                                                                                id = id.proceedButtonRelativeLayout;
                                                                                                RelativeLayout proceedButtonRelativeLayout = (RelativeLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                if (proceedButtonRelativeLayout != null) {
                                                                                                   id = id.progressBar;
                                                                                                   ProgressBar progressBar = (ProgressBar)ViewBindings.findChildViewById(rootView, id);
                                                                                                   if (progressBar != null) {
                                                                                                      id = id.saveCardLinearLayout;
                                                                                                      LinearLayout saveCardLinearLayout = (LinearLayout)ViewBindings.findChildViewById(rootView, id);
                                                                                                      if (saveCardLinearLayout != null) {
                                                                                                         id = id.textView;
                                                                                                         TextView textView = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                         if (textView != null) {
                                                                                                            id = id.textView17;
                                                                                                            TextView textView17 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                            if (textView17 != null) {
                                                                                                               id = id.textView2;
                                                                                                               TextView textView2 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                               if (textView2 != null) {
                                                                                                                  id = id.textView3;
                                                                                                                  TextView textView3 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                  if (textView3 != null) {
                                                                                                                     id = id.textView4;
                                                                                                                     TextView textView4 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                     if (textView4 != null) {
                                                                                                                        id = id.textView6;
                                                                                                                        TextView textView6 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                        if (textView6 != null) {
                                                                                                                           id = id.textView7;
                                                                                                                           TextView textView7 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                           if (textView7 != null) {
                                                                                                                              id = id.textView8;
                                                                                                                              TextView textView8 = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                              if (textView8 != null) {
                                                                                                                                 id = id.texthead_Enter_UPI;
                                                                                                                                 TextView textheadEnterUPI = (TextView)ViewBindings.findChildViewById(rootView, id);
                                                                                                                                 if (textheadEnterUPI != null) {
                                                                                                                                    return new FragmentAddCardBottomSheetBinding((CoordinatorLayout)rootView, backButton, cardCVVTextView, cardNetwork1, cardNetwork2, cardNetwork3, cardNetworkDrawableLinearLayout, cardNumberLinearLayout, cardValidityTextView, cardView, constraintLayout123, defaultCardNetworkLinearLayout, editTextCardCVV, editTextCardNumber, editTextCardValidity, editTextNameOnCard, fetchedCardNetwork, frameLayout1, imageView, imageView10, imageView3, imageView5, imageView6, imageView7, invalidCVV, invalidCardValidity, linearLayout3, ll1InvalidCardNumber, nameOnCard, nameOnCardErrorLayout, proceedButton, proceedButtonRelativeLayout, progressBar, saveCardLinearLayout, textView, textView17, textView2, textView3, textView4, textView6, textView7, textView8, textheadEnterUPI);
                                                                                                                                 }
                                                                                                                              }
                                                                                                                           }
                                                                                                                        }
                                                                                                                     }
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }
                                                                        }
                                                                     }
                                                                  }
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      String missingId = rootView.getResources().getResourceName(id);
      throw new NullPointerException("Missing required view with ID: ".concat(missingId));
   }
}
