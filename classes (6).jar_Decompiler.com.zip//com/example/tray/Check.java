package com.example.tray;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.databinding.ActivityCheckBinding;
import com.example.tray.paymentResult.PaymentResultObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0014J\u0006\u0010\u0016\u001a\u00020\u0013J\u0006\u0010\u0017\u001a\u00020\u0013J\b\u0010\u0018\u001a\u00020\u0013H\u0002J\b\u0010\u0019\u001a\u00020\u0013H\u0002J\u000e\u0010\u001a\u001a\u00020\u00132\u0006\u0010\u001b\u001a\u00020\u001cJ\u0010\u0010\u001d\u001a\u00020\u00132\u0006\u0010\u001e\u001a\u00020\u001fH\u0002J\u000e\u0010 \u001a\u00020\u00132\u0006\u0010!\u001a\u00020\"R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\t\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u001b\u0010\f\u001a\u00020\r8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u000e\u0010\u000f¨\u0006#"},
   d2 = {"Lcom/example/tray/Check;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "tokenLiveData", "Landroidx/lifecycle/MutableLiveData;", "", "getTokenLiveData", "()Landroidx/lifecycle/MutableLiveData;", "successScreenFullReferencePath", "tokenFetchedAndOpen", "", "binding", "Lcom/example/tray/databinding/ActivityCheckBinding;", "getBinding", "()Lcom/example/tray/databinding/ActivityCheckBinding;", "binding$delegate", "Lkotlin/Lazy;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "removeLoadingAndEnabledProceedButton", "showLoadingInButton", "handleResponseWithToken", "showBottomSheetWithOverlay", "onPaymentResultCallback", "result", "Lcom/example/tray/paymentResult/PaymentResultObject;", "makePaymentRequest", "context", "Landroid/content/Context;", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "Tray_release"}
)
public final class Check extends AppCompatActivity {
   @NotNull
   private final MutableLiveData<String> tokenLiveData = new MutableLiveData();
   @Nullable
   private String successScreenFullReferencePath;
   private boolean tokenFetchedAndOpen;
   @NotNull
   private final Lazy binding$delegate = LazyKt.lazy(Check::binding_delegate$lambda$0);

   @NotNull
   public final MutableLiveData<String> getTokenLiveData() {
      return this.tokenLiveData;
   }

   private final ActivityCheckBinding getBinding() {
      Lazy var1 = this.binding$delegate;
      Object var10000 = var1.getValue();
      Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
      return (ActivityCheckBinding)var10000;
   }

   protected void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.setContentView((View)this.getBinding().getRoot());
      this.makePaymentRequest((Context)this);
      this.getBinding().textView6.setText((CharSequence)"Generating Token Please wait...");
      this.successScreenFullReferencePath = "com.example.AndroidCheckOutSDK.SuccessScreen";
      this.tokenLiveData.observe((LifecycleOwner)this, Check::onCreate$lambda$1);
      BooleanRef actionInProgress = new BooleanRef();
      this.getBinding().openButton.setOnClickListener(Check::onCreate$lambda$2);
   }

   public final void removeLoadingAndEnabledProceedButton() {
      this.getBinding().openButton.setEnabled(true);
      this.getBinding().progressBar.setVisibility(8);
      Log.d("text will be updated here", "here");
      this.getBinding().textView6.setText((CharSequence)"Open Bottom Sheet");
      this.getBinding().textView6.setVisibility(0);
      this.getBinding().openButton.setVisibility(0);
      this.getBinding().pleaseWaitTextView.setVisibility(8);
   }

   public final void showLoadingInButton() {
      this.getBinding().textView6.setVisibility(4);
      this.getBinding().progressBar.setVisibility(0);
      float[] var2 = new float[]{0.0F, 360.0F};
      ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(this.getBinding().progressBar, "rotation", var2);
      rotateAnimation.setDuration(3000L);
      rotateAnimation.setRepeatCount(-1);
      this.getBinding().openButton.setEnabled(false);
      rotateAnimation.start();
   }

   private final void handleResponseWithToken() {
      if (!this.tokenFetchedAndOpen) {
         Log.d("Token", "Token has been updated. Using token: " + (String)this.tokenLiveData.getValue());
         this.showBottomSheetWithOverlay();
         this.tokenFetchedAndOpen = true;
      }
   }

   private final void showBottomSheetWithOverlay() {
      BoxPayCheckout boxPayCheckout = new BoxPayCheckout((Context)this, String.valueOf(this.tokenLiveData.getValue()), (Function1)(new Function1<PaymentResultObject, Unit>(this) {
         public final void invoke(PaymentResultObject p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            ((Check)this.receiver).onPaymentResultCallback(p0);
         }
      }), false);
      boxPayCheckout.display();
   }

   public final void onPaymentResultCallback(@NotNull PaymentResultObject result) {
      Intrinsics.checkNotNullParameter(result, "result");
      Intent intent;
      if (Intrinsics.areEqual(result.getStatus(), "Success")) {
         Log.d("onPaymentResultCallback", "Success");
         intent = new Intent((Context)this, SuccessScreenForTesting.class);
         this.startActivity(intent);
      } else {
         Log.d("onPaymentResultCallback", "Failure");
         intent = new Intent((Context)this, FailureScreenForTesting.class);
         this.startActivity(intent);
      }

   }

   private final void makePaymentRequest(Context context) {
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue queue = var10000;
      String url = "https://test-apis.boxpay.tech/v0/merchants/k12aNmllPW/sessions";
      JSONObject jsonData = new JSONObject("{\n      \"context\": {\n        \"countryCode\": \"IN\",\n        \"legalEntity\": {\"code\": \"boxpay\"},\n        \"orderId\": \"test12\"\n      },\n      \"paymentType\": \"S\",\n      \"money\": {\"amount\": \"1\", \"currencyCode\": \"INR\"},\n      \"descriptor\": {\"line1\": \"Some descriptor\"},\n      \"shopper\": {\n        \"firstName\": \"test\",\n        \"lastName\": \"last\",\n        \"email\": \"test123@gmail.com\",\n        \"uniqueReference\": \"x123y\",\n        \"phoneNumber\": \"911234567890\",\n        \"deliveryAddress\": {\n          \"address1\": \"first line\",\n          \"address2\": \"second line\",\n          \"city\": \"Mumbai\",\n          \"state\": \"Maharashtra\",\n          \"countryCode\": \"IN\",\n          \"postalCode\": \"123456\"\n        }\n      },\n      \"order\": {\n        \"originalAmount\": 423.73,\n        \"shippingAmount\": 50,\n        \"voucherCode\": \"VOUCHER\",\n        \"taxAmount\": 76.27,\n        \"totalAmountWithoutTax\": 423.73,\n        \"items\": [\n          {\n            \"id\": \"test\",\n            \"itemName\": \"Sample Item\",\n            \"description\": \"testProduct\",\n            \"quantity\": 1,\n            \"manufacturer\": null,\n            \"brand\": null,\n            \"color\": null,\n            \"productUrl\": null,\n            \"imageUrl\":\n                \"https://www.kasandbox.org/programming-images/avatars/old-spice-man.png\",\n            \"categories\": null,\n            \"amountWithoutTax\": 423.73,\n            \"taxAmount\": 76.27,\n            \"taxPercentage\": null,\n            \"discountedAmount\": null,\n            \"amountWithoutTaxLocale\": \"10\",\n            \"amountWithoutTaxLocaleFull\": \"10\"\n          }\n        ]\n      },\n      \"statusNotifyUrl\": \"https://www.boxpay.tech\",\n      \"frontendReturnUrl\": \"https://www.boxpay.tech\",\n      \"frontendBackUrl\": \"https://www.boxpay.tech\"\n    }");
      Listener var6 = Check::makePaymentRequest$lambda$3;
      ErrorListener var7 = Check::makePaymentRequest$lambda$4;
      <undefinedtype> request = new JsonObjectRequest(url, jsonData, var6, var7) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("Content-Type", "application/json");
            ((Map)headers).put("Authorization", "Bearer 72t54rOBQKzlEPddLizUJcZnJJGkm6Ysjy61u8eCtuYywGUhQW3MUivPwW0wmnky3gBQViQo9n6apZcUlXz4h9");
            return (Map)headers;
         }
      };
      queue.add((Request)request);
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Check", jsonStr);
   }

   private static final ActivityCheckBinding binding_delegate$lambda$0(Check this$0) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      return ActivityCheckBinding.inflate(this$0.getLayoutInflater());
   }

   private static final void onCreate$lambda$1(Check this$0, String tokenInObserve) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (tokenInObserve != null) {
         this$0.handleResponseWithToken();
         this$0.getBinding().textView6.setText((CharSequence)"Opening");
         this$0.getBinding().openButton.setEnabled(false);
      } else {
         Log.d("token is empty", "waiting");
      }

   }

   private static final void onCreate$lambda$2(BooleanRef $actionInProgress, Check this$0, View it) {
      Intrinsics.checkNotNullParameter($actionInProgress, "$actionInProgress");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!$actionInProgress.element) {
         $actionInProgress.element = true;
         this$0.getBinding().openButton.setEnabled(false);
         this$0.getBinding().openButton.setVisibility(8);
         this$0.getBinding().pleaseWaitTextView.setVisibility(0);
         CharSequence var3 = (CharSequence)this$0.tokenLiveData.getValue();
         if (var3 != null && var3.length() != 0) {
            this$0.showBottomSheetWithOverlay();
            $actionInProgress.element = false;
            this$0.getBinding().openButton.setEnabled(true);
         }

      }
   }

   private static final void makePaymentRequest$lambda$3(Check this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(response);
      this$0.logJsonObject(response);
      String tokenFetched = response.getString("token");
      Log.d("token fetched", tokenFetched);
      this$0.tokenLiveData.setValue(tokenFetched);
   }

   private static final void makePaymentRequest$lambda$4(VolleyError error) {
      Log.e("Error", "Error occurred: " + error);
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         Log.d("", "");
      }

   }
}
