package com.example.tray;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SearchView.OnQueryTextListener;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import coil.Coil;
import coil.ImageLoader;
import coil.decode.Decoder;
import coil.decode.SvgDecoder;
import coil.fetch.SourceResult;
import coil.request.ImageRequest;
import coil.request.Options;
import coil.request.ImageRequest.Builder;
import coil.transform.CircleCropTransformation;
import coil.transform.Transformation;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.R.color;
import com.example.tray.R.drawable;
import com.example.tray.adapters.NetbankingBanksAdapter;
import com.example.tray.databinding.FragmentNetBankingBottomSheetBinding;
import com.example.tray.dataclasses.NetbankingDataClass;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.skydoves.balloon.Balloon;
import com.skydoves.balloon.BalloonAnimation;
import com.skydoves.balloon.BalloonCenterAlign;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¶\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0000\u0018\u0000 g2\u00020\u0001:\u0001gB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010-\u001a\u00020.2\b\u0010/\u001a\u0004\u0018\u000100H\u0016J\u0012\u00101\u001a\u0002022\b\u0010/\u001a\u0004\u0018\u000100H\u0016J\u0010\u00103\u001a\u00020.2\u0006\u00104\u001a\u000205H\u0016J\b\u00106\u001a\u00020.H\u0002J\b\u00107\u001a\u00020.H\u0002J\b\u00108\u001a\u00020.H\u0002J\b\u00109\u001a\u00020.H\u0002J\u0010\u0010:\u001a\u00020.2\u0006\u0010;\u001a\u00020\u0012H\u0002J&\u0010<\u001a\u0004\u0018\u00010=2\u0006\u0010>\u001a\u00020?2\b\u0010@\u001a\u0004\u0018\u00010A2\b\u0010/\u001a\u0004\u0018\u000100H\u0016J\b\u0010B\u001a\u00020.H\u0002J\u0012\u0010C\u001a\u00020.2\b\u0010D\u001a\u0004\u0018\u00010\u0012H\u0002J\u0006\u0010E\u001a\u00020.J\u0010\u0010F\u001a\u00020.2\u0006\u00104\u001a\u000205H\u0016J\u0006\u0010G\u001a\u00020.J\u0006\u0010H\u001a\u00020.J\u0006\u0010I\u001a\u00020.J\b\u0010J\u001a\u00020.H\u0002J\u0010\u0010K\u001a\u00020L2\u0006\u0010M\u001a\u00020\u0017H\u0002J\u0018\u0010N\u001a\u00020.2\u0006\u0010O\u001a\u00020L2\u0006\u0010P\u001a\u00020\u0012H\u0002J\u0010\u0010Q\u001a\u00020R2\u0006\u0010M\u001a\u00020\u0017H\u0002J\b\u0010S\u001a\u00020.H\u0002J\u0018\u0010T\u001a\u00020'2\u0006\u0010U\u001a\u00020\u00172\u0006\u0010V\u001a\u00020\u0017H\u0002J\u0010\u0010W\u001a\u00020X2\u0006\u0010M\u001a\u00020\u0017H\u0002J\u0018\u0010Y\u001a\u00020.2\u0006\u0010Z\u001a\u00020[2\u0006\u0010\\\u001a\u00020\u0012H\u0002J\u000e\u0010]\u001a\u00020.2\u0006\u0010^\u001a\u00020_J\b\u0010`\u001a\u00020.H\u0002J\b\u0010a\u001a\u00020.H\u0002J\u0006\u0010b\u001a\u00020.J\u0006\u0010c\u001a\u00020.J\u0010\u0010d\u001a\u0004\u0018\u00010\u00122\u0006\u0010e\u001a\u00020\u0012J\b\u0010f\u001a\u00020.H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u000b\u001a\u0012\u0012\u0004\u0012\u00020\r0\u000ej\b\u0012\u0004\u0012\u00020\r`\fX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000fR \u0010\u0010\u001a\u0012\u0012\u0004\u0012\u00020\r0\u000ej\b\u0012\u0004\u0012\u00020\r`\fX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000fR\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0018R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u000e\u0010\u001f\u001a\u00020\u0012X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010 \u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R\u000e\u0010%\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020'X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020)X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020+X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006h"},
   d2 = {"Lcom/example/tray/NetBankingBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentNetBankingBottomSheetBinding;", "allBanksAdapter", "Lcom/example/tray/adapters/NetbankingBanksAdapter;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "banksDetailsOriginal", "Lkotlin/collections/ArrayList;", "Lcom/example/tray/dataclasses/NetbankingDataClass;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "banksDetailsFiltered", "token", "", "proceedButtonIsEnabled", "Landroidx/lifecycle/MutableLiveData;", "", "checkedPosition", "", "Ljava/lang/Integer;", "successScreenFullReferencePath", "liveDataPopularBankSelectedOrNot", "getLiveDataPopularBankSelectedOrNot", "()Landroidx/lifecycle/MutableLiveData;", "setLiveDataPopularBankSelectedOrNot", "(Landroidx/lifecycle/MutableLiveData;)V", "Base_Session_API_URL", "popularBanksSelected", "getPopularBanksSelected", "()Z", "setPopularBanksSelected", "(Z)V", "popularBanksSelectedIndex", "colorAnimation", "Landroid/animation/ValueAnimator;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "transactionId", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "onCancel", "dialog", "Landroid/content/DialogInterface;", "fetchBanksDetails", "unselectItemsInPopularLayout", "applyLoadingScreenState", "removeLoadingScreenState", "updateTransactionIDInSharedPreferences", "transactionIdArg", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "dismissAndMakeButtonsOfMainBottomSheetEnabled", "filterBanks", "query", "failurePaymentFunction", "onDismiss", "showAllBanks", "makeRecyclerViewJustBelowEditText", "removeRecyclerViewFromBelowEditText", "fetchAndUpdateApiInPopularBanks", "getConstraintLayoutByNum", "Landroidx/constraintlayout/widget/ConstraintLayout;", "num", "showToolTipPopularBanks", "constraintLayout", "bankName", "getPopularTextViewByNum", "Landroid/widget/TextView;", "startBackgroundAnimation", "createColorAnimation", "startColor", "endColor", "fetchRelativeLayout", "Landroid/widget/RelativeLayout;", "postRequest", "context", "Landroid/content/Context;", "bankInstrumentTypeValue", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "enableProceedButton", "disableProceedButton", "hideLoadingInButton", "showLoadingInButton", "extractMessageFromErrorResponse", "response", "fetchTransactionDetailsFromSharedPreferences", "Companion", "Tray_release"}
)
@SourceDebugExtension({"SMAP\nNetBankingBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NetBankingBottomSheet.kt\ncom/example/tray/NetBankingBottomSheet\n+ 2 Extensions.kt\ncoil/-SingletonExtensions\n+ 3 Balloon.kt\ncom/skydoves/balloon/BalloonKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,830:1\n54#2,3:831\n24#2:834\n59#2,6:835\n133#3:841\n13346#4,2:842\n*S KotlinDebug\n*F\n+ 1 NetBankingBottomSheet.kt\ncom/example/tray/NetBankingBottomSheet\n*L\n491#1:831,3\n491#1:834\n491#1:835,6\n559#1:841\n612#1:842,2\n*E\n"})
public final class NetBankingBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final NetBankingBottomSheet.Companion Companion = new NetBankingBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentNetBankingBottomSheetBinding binding;
   private NetbankingBanksAdapter allBanksAdapter;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @NotNull
   private ArrayList<NetbankingDataClass> banksDetailsOriginal = new ArrayList();
   @NotNull
   private ArrayList<NetbankingDataClass> banksDetailsFiltered = new ArrayList();
   @Nullable
   private String token;
   @NotNull
   private MutableLiveData<Boolean> proceedButtonIsEnabled = new MutableLiveData();
   @Nullable
   private Integer checkedPosition;
   @Nullable
   private String successScreenFullReferencePath;
   @NotNull
   private MutableLiveData<Boolean> liveDataPopularBankSelectedOrNot;
   private String Base_Session_API_URL;
   private boolean popularBanksSelected;
   private int popularBanksSelectedIndex;
   private ValueAnimator colorAnimation;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   @Nullable
   private String transactionId;

   public NetBankingBottomSheet() {
      MutableLiveData var1 = new MutableLiveData();
      int var3 = false;
      var1.setValue(false);
      this.liveDataPopularBankSelectedOrNot = var1;
      this.popularBanksSelectedIndex = -1;
   }

   @NotNull
   public final MutableLiveData<Boolean> getLiveDataPopularBankSelectedOrNot() {
      return this.liveDataPopularBankSelectedOrNot;
   }

   public final void setLiveDataPopularBankSelectedOrNot(@NotNull MutableLiveData<Boolean> var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.liveDataPopularBankSelectedOrNot = var1;
   }

   public final boolean getPopularBanksSelected() {
      return this.popularBanksSelected;
   }

   public final void setPopularBanksSelected(boolean var1) {
      this.popularBanksSelected = var1;
   }

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(NetBankingBottomSheet::onCreateDialog$lambda$2);
      return dialog;
   }

   public void onCancel(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onCancel(dialog);
      this.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   private final void fetchBanksDetails() {
      StringBuilder var10000 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String url = var10000.append(var10001).append(this.token).toString();
      RequestQueue var4 = Volley.newRequestQueue(this.requireContext());
      Intrinsics.checkNotNullExpressionValue(var4, "newRequestQueue(...)");
      RequestQueue queue = var4;
      JsonObjectRequest jsonObjectAll = new JsonObjectRequest(0, url, (JSONObject)null, NetBankingBottomSheet::fetchBanksDetails$lambda$3, NetBankingBottomSheet::fetchBanksDetails$lambda$4);
      queue.add((Request)jsonObjectAll);
   }

   private final void unselectItemsInPopularLayout() {
      if (this.popularBanksSelectedIndex != -1) {
         this.fetchRelativeLayout(this.popularBanksSelectedIndex).setBackgroundResource(drawable.popular_item_unselected_bg);
      }

      this.popularBanksSelected = false;
   }

   private final void applyLoadingScreenState() {
   }

   private final void removeLoadingScreenState() {
      Log.d("removeLoadingScreenState", "called");
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.banksRecyclerView.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularBanksRelativeLayout1.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularBanksRelativeLayout2.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularBanksRelativeLayout3.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularBanksRelativeLayout4.setBackgroundResource(drawable.popular_item_unselected_bg);
      ValueAnimator var1 = this.colorAnimation;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var1 = null;
      }

      var1.cancel();
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentNetBankingBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.requireActivity().setRequestedOrientation(1);
      }

      int screenHeight = this.requireContext().getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.45D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      LayoutParams var18 = var10000.nestedScrollView.getLayoutParams();
      Intrinsics.checkNotNull(var18, "null cannot be cast to non-null type androidx.constraintlayout.widget.ConstraintLayout.LayoutParams");
      androidx.constraintlayout.widget.ConstraintLayout.LayoutParams layoutParams = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams)var18;
      layoutParams.height = desiredHeight;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.nestedScrollView.setLayoutParams((LayoutParams)layoutParams);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var18 = var10000.loadingRelativeLayout.getLayoutParams();
      Intrinsics.checkNotNull(var18, "null cannot be cast to non-null type androidx.constraintlayout.widget.ConstraintLayout.LayoutParams");
      androidx.constraintlayout.widget.ConstraintLayout.LayoutParams layoutParamsLoading = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams)var18;
      layoutParamsLoading.height = desiredHeight;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setLayoutParams((LayoutParams)layoutParamsLoading);
      SharedPreferences var21 = this.sharedPreferences;
      if (var21 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var21 = null;
      }

      String environmentFetched = var21.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Netbanking Bottom Sheet");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchTransactionDetailsFromSharedPreferences();
      this.banksDetailsOriginal = new ArrayList();
      NetbankingBanksAdapter var19 = new NetbankingBanksAdapter;
      ArrayList var10003 = this.banksDetailsFiltered;
      FragmentNetBankingBottomSheetBinding var10004 = this.binding;
      if (var10004 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10004 = null;
      }

      RecyclerView var14 = var10004.banksRecyclerView;
      Intrinsics.checkNotNullExpressionValue(var14, "banksRecyclerView");
      MutableLiveData var10005 = this.liveDataPopularBankSelectedOrNot;
      Context var10006 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10006, "requireContext(...)");
      FragmentNetBankingBottomSheetBinding var10007 = this.binding;
      if (var10007 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10007 = null;
      }

      SearchView var16 = var10007.searchView;
      Intrinsics.checkNotNullExpressionValue(var16, "searchView");
      var19.<init>(var10003, var14, var10005, var10006, var16);
      this.allBanksAdapter = var19;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.banksRecyclerView.setLayoutManager((LayoutManager)(new LinearLayoutManager(this.requireContext())));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RecyclerView var15 = var10000.banksRecyclerView;
      var19 = this.allBanksAdapter;
      if (var19 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
         var19 = null;
      }

      var15.setAdapter((Adapter)var19);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.boxPayLogoLottieAnimation.playAnimation();
      this.startBackgroundAnimation();
      this.fetchBanksDetails();
      if (this.successScreenFullReferencePath != null) {
         String var20 = this.successScreenFullReferencePath;
         Intrinsics.checkNotNull(var20);
         Log.d("NetBankingBottomSheetReference", var20);
      }

      BooleanRef enabled = new BooleanRef();
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.checkingTextView.setOnClickListener(NetBankingBottomSheet::onCreateView$lambda$5);
      .FailureScreenSharedViewModel failureScreenSharedViewModelCallback = new .FailureScreenSharedViewModel((Function0)(new Function0<Unit>(this) {
         public final void invoke() {
            ((NetBankingBottomSheet)this.receiver).failurePaymentFunction();
         }
      }));
      FailureScreenCallBackSingletonClass.Companion.getInstance().setCallBackFunctions(failureScreenSharedViewModelCallback);
      this.proceedButtonIsEnabled.observe((LifecycleOwner)this, NetBankingBottomSheet::onCreateView$lambda$6);
      this.liveDataPopularBankSelectedOrNot.observe((LifecycleOwner)this, NetBankingBottomSheet::onCreateView$lambda$7);
      NetbankingBanksAdapter var17 = this.allBanksAdapter;
      if (var17 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
         var17 = null;
      }

      var17.getCheckPositionLiveData().observe((LifecycleOwner)this, NetBankingBottomSheet::onCreateView$lambda$8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.searchView.setOnQueryTextListener((OnQueryTextListener)(new OnQueryTextListener() {
         public boolean onQueryTextSubmit(String query) {
            Intrinsics.checkNotNullParameter(query, "query");
            if (((CharSequence)query).length() == 0) {
               NetBankingBottomSheet.this.removeRecyclerViewFromBelowEditText();
            } else {
               NetBankingBottomSheet.this.makeRecyclerViewJustBelowEditText();
            }

            NetBankingBottomSheet.this.filterBanks(query);
            NetBankingBottomSheet.this.disableProceedButton();
            return true;
         }

         public boolean onQueryTextChange(String newText) {
            Intrinsics.checkNotNullParameter(newText, "newText");
            if (((CharSequence)newText).length() == 0) {
               NetBankingBottomSheet.this.removeRecyclerViewFromBelowEditText();
            } else {
               NetBankingBottomSheet.this.makeRecyclerViewJustBelowEditText();
            }

            NetBankingBottomSheet.this.filterBanks(newText);
            NetBankingBottomSheet.this.disableProceedButton();
            return true;
         }
      }));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.backButton.setOnClickListener(NetBankingBottomSheet::onCreateView$lambda$9);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setOnClickListener(NetBankingBottomSheet::onCreateView$lambda$10);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      return (View)var10000.getRoot();
   }

   private final void dismissAndMakeButtonsOfMainBottomSheetEnabled() {
      Fragment var2 = this.getParentFragmentManager().findFragmentByTag("MainBottomSheet");
      MainBottomSheet mainBottomSheetFragment = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if (mainBottomSheetFragment != null) {
         mainBottomSheetFragment.enabledButtonsForAllPaymentMethods();
      }

      this.dismiss();
   }

   private final void filterBanks(String query) {
      this.banksDetailsFiltered.clear();
      Iterator var10000 = this.banksDetailsOriginal.iterator();
      Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
      Iterator var2 = var10000;

      while(true) {
         while(var2.hasNext()) {
            Object var4 = var2.next();
            Intrinsics.checkNotNullExpressionValue(var4, "next(...)");
            NetbankingDataClass bank = (NetbankingDataClass)var4;
            if (!StringsKt.isBlank((CharSequence)String.valueOf(query)) && !StringsKt.isBlank((CharSequence)String.valueOf(query))) {
               if (StringsKt.contains((CharSequence)bank.getBankName(), (CharSequence)String.valueOf(query), true)) {
                  this.banksDetailsFiltered.add(new NetbankingDataClass(bank.getBankName(), bank.getBankImage(), bank.getBankBrand(), bank.getBankInstrumentTypeValue()));
               }
            } else {
               this.showAllBanks();
            }
         }

         FragmentNetBankingBottomSheetBinding var5;
         if (this.banksDetailsFiltered.size() == 0) {
            var5 = this.binding;
            if (var5 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var5 = null;
            }

            var5.noResultsFoundTextView.setVisibility(0);
         } else {
            var5 = this.binding;
            if (var5 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var5 = null;
            }

            var5.noResultsFoundTextView.setVisibility(8);
         }

         NetbankingBanksAdapter var6 = this.allBanksAdapter;
         if (var6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
            var6 = null;
         }

         var6.deselectSelectedItem();
         var6 = this.allBanksAdapter;
         if (var6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
            var6 = null;
         }

         var6.notifyDataSetChanged();
         return;
      }
   }

   public final void failurePaymentFunction() {
      Log.d("Failure Screen View Model", "failurePaymentFunction");
      BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getMain()), (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;

         public final Object invokeSuspend(Object $result) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               Continuation var10001 = (Continuation)this;
               this.label = 1;
               if (DelayKt.delay(1000L, var10001) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            PaymentFailureScreen bottomSheet = new PaymentFailureScreen();
            bottomSheet.show(NetBankingBottomSheet.this.getParentFragmentManager(), "PaymentFailureScreen");
            return Unit.INSTANCE;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            return (Continuation)(new <anonymous constructor>($completion));
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      Fragment var2 = this.getParentFragment();
      MainBottomSheet var10000 = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if ((var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null) != null) {
         var10000.removeOverlayFromCurrentBottomSheet();
      }

      ValueAnimator var3 = this.colorAnimation;
      if (var3 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var3 = null;
      }

      var3.cancel();
      super.onDismiss(dialog);
   }

   public final void showAllBanks() {
      this.banksDetailsFiltered.clear();
      Iterator var10000 = this.banksDetailsOriginal.iterator();
      Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
      Iterator var1 = var10000;

      while(var1.hasNext()) {
         Object var3 = var1.next();
         Intrinsics.checkNotNullExpressionValue(var3, "next(...)");
         NetbankingDataClass bank = (NetbankingDataClass)var3;
         this.banksDetailsFiltered.add(bank);
      }

      NetbankingBanksAdapter var4 = this.allBanksAdapter;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
         var4 = null;
      }

      var4.deselectSelectedItem();
      var4 = this.allBanksAdapter;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
         var4 = null;
      }

      var4.notifyDataSetChanged();
   }

   public final void makeRecyclerViewJustBelowEditText() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView19.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView24.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.linearLayout2.setVisibility(8);
   }

   public final void removeRecyclerViewFromBelowEditText() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView19.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView24.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.linearLayout2.setVisibility(0);
   }

   private final void fetchAndUpdateApiInPopularBanks() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      FragmentNetBankingBottomSheetBinding var1 = var10000;
      FragmentNetBankingBottomSheetBinding $this$fetchAndUpdateApiInPopularBanks_u24lambda_u2415 = var1;
      int var3 = false;

      for(int index = 0; index < 4; ++index) {
         ConstraintLayout constraintLayout = this.getConstraintLayoutByNum(index);
         if (index < this.banksDetailsOriginal.size()) {
            Object var20 = this.banksDetailsOriginal.get(index);
            Intrinsics.checkNotNullExpressionValue(var20, "get(...)");
            NetbankingDataClass bankDetail = (NetbankingDataClass)var20;
            RelativeLayout relativeLayout = this.fetchRelativeLayout(index);
            ImageView var21;
            switch(index) {
            case 0:
               var21 = $this$fetchAndUpdateApiInPopularBanks_u24lambda_u2415.popularBanksImageView1;
               break;
            case 1:
               var21 = $this$fetchAndUpdateApiInPopularBanks_u24lambda_u2415.popularBanksImageView2;
               break;
            case 2:
               var21 = $this$fetchAndUpdateApiInPopularBanks_u24lambda_u2415.popularBanksImageView3;
               break;
            case 3:
               var21 = $this$fetchAndUpdateApiInPopularBanks_u24lambda_u2415.popularBanksImageView4;
               break;
            default:
               var21 = null;
            }

            ImageView imageView = var21;
            if (imageView != null) {
               Object data$iv = bankDetail.getBankImage();
               Context $this$imageLoader$iv$iv = imageView.getContext();
               int $i$f$getImageLoader = false;
               ImageLoader imageLoader$iv = Coil.imageLoader($this$imageLoader$iv$iv);
               int $i$f$load = false;
               Builder var19 = (new Builder(imageView.getContext())).data(data$iv).target(imageView);
               int var16 = false;
               var19.decoderFactory(NetBankingBottomSheet::fetchAndUpdateApiInPopularBanks$lambda$15$lambda$12$lambda$11);
               Transformation[] var17 = new Transformation[]{new CircleCropTransformation()};
               var19.transformations(var17);
               var19.size(80, 80);
               ImageRequest request$iv = var19.build();
               imageLoader$iv.enqueue(request$iv);
            }

            this.getPopularTextViewByNum(index + 1).setText((CharSequence)((NetbankingDataClass)this.banksDetailsOriginal.get(index)).getBankName());
            constraintLayout.setOnClickListener(NetBankingBottomSheet::fetchAndUpdateApiInPopularBanks$lambda$15$lambda$13);
            constraintLayout.setOnLongClickListener(NetBankingBottomSheet::fetchAndUpdateApiInPopularBanks$lambda$15$lambda$14);
         } else {
            constraintLayout.setVisibility(8);
         }
      }

   }

   private final ConstraintLayout getConstraintLayoutByNum(int num) {
      FragmentNetBankingBottomSheetBinding var10000;
      ConstraintLayout var3;
      switch(num) {
      case 0:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksConstraintLayout1;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksConstraintLayout1");
         break;
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksConstraintLayout2;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksConstraintLayout2");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksConstraintLayout3;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksConstraintLayout3");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksConstraintLayout4;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksConstraintLayout4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number Relative layout");
      }

      ConstraintLayout constraintLayout = var3;
      return constraintLayout;
   }

   private final void showToolTipPopularBanks(ConstraintLayout constraintLayout, String bankName) {
      Context var10000 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10000, "requireContext(...)");
      Context context$iv = var10000;
      int $i$f$createBalloon = false;
      com.skydoves.balloon.Balloon.Builder var6 = new com.skydoves.balloon.Balloon.Builder(context$iv);
      int var8 = false;
      var6.setArrowSize(10);
      var6.setWidthRatio(0.3F);
      var6.setHeight(65);
      var6.setArrowPosition(0.5F);
      var6.setCornerRadius(4.0F);
      var6.setAlpha(0.9F);
      var6.setText((CharSequence)bankName);
      var6.setTextColorResource(color.colorEnd);
      var6.setBackgroundColorResource(color.tooltip_bg);
      var6.setBalloonAnimation(BalloonAnimation.FADE);
      var6.setLifecycleOwner(var6.getLifecycleOwner());
      Balloon balloon = var6.build();
      Log.d("long click detected", "popular Net banking");
      balloon.showAtCenter((View)constraintLayout, 0, 0, BalloonCenterAlign.TOP);
      balloon.dismissWithDelay(2000L);
   }

   private final TextView getPopularTextViewByNum(int num) {
      FragmentNetBankingBottomSheetBinding var10000;
      TextView var2;
      switch(num) {
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularBanksNameTextView1;
         Intrinsics.checkNotNullExpressionValue(var2, "popularBanksNameTextView1");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularBanksNameTextView2;
         Intrinsics.checkNotNullExpressionValue(var2, "popularBanksNameTextView2");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularBanksNameTextView3;
         Intrinsics.checkNotNullExpressionValue(var2, "popularBanksNameTextView3");
         break;
      case 4:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularBanksNameTextView4;
         Intrinsics.checkNotNullExpressionValue(var2, "popularBanksNameTextView4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number: " + num + "  TextView1234");
      }

      return var2;
   }

   private final void startBackgroundAnimation() {
      int colorStart = this.getResources().getColor(color.colorStart);
      int colorEnd = this.getResources().getColor(color.colorEnd);
      this.colorAnimation = this.createColorAnimation(colorStart, colorEnd);
      ValueAnimator var10000 = this.colorAnimation;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var10000 = null;
      }

      var10000.start();
   }

   private final ValueAnimator createColorAnimation(int startColor, int endColor) {
      int var4 = 0;

      RelativeLayout[] var5;
      for(var5 = new RelativeLayout[4]; var4 < 4; ++var4) {
         var5[var4] = null;
      }

      FragmentNetBankingBottomSheetBinding var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[0] = var10002.popularBanksRelativeLayout1;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[1] = var10002.popularBanksRelativeLayout2;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[2] = var10002.popularBanksRelativeLayout3;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[3] = var10002.popularBanksRelativeLayout4;
      TypeEvaluator var10000 = (TypeEvaluator)(new ArgbEvaluator());
      Object[] var8 = new Object[]{startColor, endColor};
      ValueAnimator var9 = ValueAnimator.ofObject(var10000, var8);
      int var7 = false;
      var9.setDuration(500L);
      var9.setInterpolator((TimeInterpolator)(new AccelerateDecelerateInterpolator()));
      var9.setRepeatCount(-1);
      var9.setRepeatMode(2);
      var9.addUpdateListener(NetBankingBottomSheet::createColorAnimation$lambda$19$lambda$18);
      Intrinsics.checkNotNullExpressionValue(var9, "apply(...)");
      return var9;
   }

   private final RelativeLayout fetchRelativeLayout(int num) {
      Log.d("Number Called", String.valueOf(num));
      FragmentNetBankingBottomSheetBinding var10000;
      RelativeLayout var3;
      switch(num) {
      case 0:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksRelativeLayout1;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksRelativeLayout1");
         break;
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksRelativeLayout2;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksRelativeLayout2");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksRelativeLayout3;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksRelativeLayout3");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularBanksRelativeLayout4;
         Intrinsics.checkNotNullExpressionValue(var3, "popularBanksRelativeLayout4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number Relative layout");
      }

      RelativeLayout relativeLayout = var3;
      return relativeLayout;
   }

   private final void postRequest(Context context, String bankInstrumentTypeValue) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var5 = new JSONObject();
      int var7 = false;
      JSONObject var8 = new JSONObject();
      int var10 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("user Agent for device", userAgentHeader);
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var8.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var8.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var8.put("acceptHeader", "application/json");
      var8.put("userAgentHeader", userAgentHeader);
      var8.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("ipAddress", var10002.getString("ipAddress", "null"));
      var8.put("colorDepth", 24);
      var8.put("javaEnabled", true);
      var8.put("timeZoneOffSet", 330);
      var5.put("browserData", var8);
      JSONObject var9 = new JSONObject();
      int var11 = false;
      var9.put("type", bankInstrumentTypeValue);
      var5.put("instrumentDetails", var9);
      Log.d("request Body", "Netbanking");
      this.logJsonObject(var5);
      StringBuilder var22 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var6 = var22.append(var10001).append(this.token).toString();
      Listener var16 = NetBankingBottomSheet::postRequest$lambda$23;
      ErrorListener var17 = NetBankingBottomSheet::postRequest$lambda$24;
      JsonObjectRequest var15 = new JsonObjectRequest(var5, var6, var16, var17) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(NetBankingBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var18 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var15.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var15);
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Netbanking", jsonStr);
   }

   private final void enableProceedButton() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      TextView var2 = var10000.textView6;
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var2.setTextColor(Color.parseColor(var10001.getString("buttonTextColor", "#000000")));
   }

   private final void disableProceedButton() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(Color.parseColor("#ADACB0"));
   }

   public final void hideLoadingInButton() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(ContextCompat.getColor(this.requireContext(), 17170443));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
   }

   public final void showLoadingInButton() {
      FragmentNetBankingBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      ProgressBar var3 = var10000.progressBar;
      float[] var2 = new float[]{0.0F, 360.0F};
      ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(var3, "rotation", var2);
      rotateAnimation.setDuration(3000L);
      rotateAnimation.setRepeatCount(-1);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      rotateAnimation.start();
   }

   @Nullable
   public final String extractMessageFromErrorResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");

      try {
         JSONObject jsonObject = new JSONObject(response);
         return jsonObject.getString("message");
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.token = var10001.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.successScreenFullReferencePath = var10001.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   private static final void onCreateDialog$lambda$2(final NetBankingBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      int screenHeight = this$0.requireContext().getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.9D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      if (this$0.bottomSheetBehavior == null) {
         Log.d("MainBottomSheet  bottomSheet is null", "Main Bottom Sheet");
      }

      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      Window window = d.getWindow();
      if (window != null) {
         int var11 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final void fetchBanksDetails$lambda$3(NetBankingBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         JSONArray paymentMethodsArray = response.getJSONObject("configs").getJSONArray("paymentMethods");
         int i = 0;

         for(int var4 = paymentMethodsArray.length(); i < var4; ++i) {
            JSONObject paymentMethod = paymentMethodsArray.getJSONObject(i);
            if (Intrinsics.areEqual(paymentMethod.getString("type"), "NetBanking")) {
               String bankName = paymentMethod.getString("title");
               String bankImage = paymentMethod.getString("logoUrl");
               Intrinsics.checkNotNull(bankImage);
               if (StringsKt.startsWith$default(bankImage, "/assets", false, 2, (Object)null)) {
                  bankImage = "https://checkout.boxpay.in" + paymentMethod.getString("logoUrl");
               }

               Log.d("Logo url : ", bankImage);
               String bankBrand = paymentMethod.getString("brand");
               String bankInstrumentTypeValue = paymentMethod.getString("instrumentTypeValue");
               ArrayList var10000 = this$0.banksDetailsOriginal;
               Intrinsics.checkNotNull(bankName);
               Intrinsics.checkNotNull(bankImage);
               Intrinsics.checkNotNull(bankBrand);
               Intrinsics.checkNotNull(bankInstrumentTypeValue);
               var10000.add(new NetbankingDataClass(bankName, bankImage, bankBrand, bankInstrumentTypeValue));
            }
         }

         this$0.showAllBanks();
         this$0.removeLoadingScreenState();
         this$0.fetchAndUpdateApiInPopularBanks();
      } catch (Exception var11) {
         Log.d("Error Occured", var11.toString());
         var11.printStackTrace();
      }

   }

   private static final void fetchBanksDetails$lambda$4(NetBankingBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("error here", "RESPONSE IS " + error);
      Toast.makeText(this$0.requireContext(), (CharSequence)"Fail to get response", 0).show();
   }

   private static final void onCreateView$lambda$5(BooleanRef $enabled, NetBankingBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter($enabled, "$enabled");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!$enabled.element) {
         this$0.enableProceedButton();
      } else {
         this$0.disableProceedButton();
      }

      $enabled.element = !$enabled.element;
   }

   private static final void onCreateView$lambda$6(NetBankingBottomSheet this$0, Boolean enableProceedButton) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (enableProceedButton) {
         this$0.enableProceedButton();
      } else {
         this$0.disableProceedButton();
      }

   }

   private static final void onCreateView$lambda$7(NetBankingBottomSheet this$0, Boolean it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (it) {
         NetbankingBanksAdapter var10000 = this$0.allBanksAdapter;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allBanksAdapter");
            var10000 = null;
         }

         var10000.deselectSelectedItem();
      } else {
         this$0.unselectItemsInPopularLayout();
      }

   }

   private static final void onCreateView$lambda$8(NetBankingBottomSheet this$0, Integer checkPositionObserved) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (checkPositionObserved == null) {
         this$0.disableProceedButton();
      } else {
         this$0.enableProceedButton();
         this$0.checkedPosition = checkPositionObserved;
      }

   }

   private static final void onCreateView$lambda$9(NetBankingBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   private static final void onCreateView$lambda$10(NetBankingBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.showLoadingInButton();
      String bankInstrumentTypeValue = "";
      Object var10000 = this$0.liveDataPopularBankSelectedOrNot.getValue();
      Intrinsics.checkNotNull(var10000);
      if ((Boolean)var10000) {
         bankInstrumentTypeValue = ((NetbankingDataClass)this$0.banksDetailsOriginal.get(this$0.popularBanksSelectedIndex)).getBankInstrumentTypeValue();
      } else {
         ArrayList var3 = this$0.banksDetailsFiltered;
         Integer var10001 = this$0.checkedPosition;
         Intrinsics.checkNotNull(var10001);
         bankInstrumentTypeValue = ((NetbankingDataClass)var3.get(var10001)).getBankInstrumentTypeValue();
      }

      Log.d("Selected bank is : ", bankInstrumentTypeValue);
      FragmentNetBankingBottomSheetBinding var4 = this$0.binding;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var4 = null;
      }

      var4.errorField.setVisibility(8);
      Context var5 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var5, "requireContext(...)");
      this$0.postRequest(var5, bankInstrumentTypeValue);
   }

   private static final Decoder fetchAndUpdateApiInPopularBanks$lambda$15$lambda$12$lambda$11(SourceResult result, Options options, ImageLoader var2) {
      Intrinsics.checkNotNullParameter(result, "result");
      Intrinsics.checkNotNullParameter(options, "options");
      Intrinsics.checkNotNullParameter(var2, "<unused var>");
      return (Decoder)(new SvgDecoder(result.getSource(), options, false, 4, (DefaultConstructorMarker)null));
   }

   private static final void fetchAndUpdateApiInPopularBanks$lambda$15$lambda$13(NetBankingBottomSheet this$0, int $index, RelativeLayout $relativeLayout, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($relativeLayout, "$relativeLayout");
      Object var10000 = this$0.requireContext().getSystemService("input_method");
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
      InputMethodManager inputMethodManager = (InputMethodManager)var10000;
      FragmentNetBankingBottomSheetBinding var10001 = this$0.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      inputMethodManager.hideSoftInputFromWindow(var10001.searchView.getWindowToken(), 0);
      this$0.liveDataPopularBankSelectedOrNot.setValue(true);
      if (this$0.popularBanksSelected && this$0.popularBanksSelectedIndex == $index) {
         $relativeLayout.setBackgroundResource(drawable.popular_item_unselected_bg);
         this$0.popularBanksSelected = false;
         this$0.proceedButtonIsEnabled.setValue(false);
      } else {
         if (this$0.popularBanksSelectedIndex != -1) {
            this$0.fetchRelativeLayout(this$0.popularBanksSelectedIndex).setBackgroundResource(drawable.popular_item_unselected_bg);
         }

         $relativeLayout.setBackgroundResource(drawable.selected_popular_item_bg);
         this$0.popularBanksSelected = true;
         this$0.proceedButtonIsEnabled.setValue(true);
         this$0.popularBanksSelectedIndex = $index;
      }

   }

   private static final boolean fetchAndUpdateApiInPopularBanks$lambda$15$lambda$14(NetBankingBottomSheet this$0, ConstraintLayout $constraintLayout, int $index, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($constraintLayout, "$constraintLayout");
      this$0.showToolTipPopularBanks($constraintLayout, ((NetbankingDataClass)this$0.banksDetailsOriginal.get($index)).getBankName());
      return true;
   }

   private static final void createColorAnimation$lambda$19$lambda$18(RelativeLayout[] $layouts, ValueAnimator animator) {
      Intrinsics.checkNotNullParameter($layouts, "$layouts");
      Intrinsics.checkNotNullParameter(animator, "animator");
      Object[] $this$forEach$iv = $layouts;
      int $i$f$forEach = false;
      int var4 = 0;

      for(int var5 = $layouts.length; var4 < var5; ++var4) {
         Object element$iv = $this$forEach$iv[var4];
         int var8 = false;
         if (element$iv != null) {
            Object var10001 = animator.getAnimatedValue();
            Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type kotlin.Int");
            element$iv.setBackgroundColor((Integer)var10001);
         }
      }

   }

   private static final void postRequest$lambda$23(NetBankingBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.hideLoadingInButton();

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObject(response);
         this$0.transactionId = response.getString("transactionId").toString();
         String var10001 = this$0.transactionId;
         Intrinsics.checkNotNull(var10001);
         this$0.updateTransactionIDInSharedPreferences(var10001);
         JSONArray actionsArray = response.getJSONArray("actions");
         String status = response.getJSONObject("status").getString("status");
         String url = "";
         int i = 0;

         for(int var6 = actionsArray.length(); i < var6; ++i) {
            JSONObject actionObject = actionsArray.getJSONObject(i);
            url = actionObject.getString("url");
            Log.d("url and status", url + '\n' + status);
         }

         if (status.equals("Approved")) {
            PaymentSuccessfulWithDetailsBottomSheet bottomSheet = new PaymentSuccessfulWithDetailsBottomSheet();
            bottomSheet.show(this$0.getParentFragmentManager(), "PaymentSuccessfulWithDetailsBottomSheet");
            this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
         } else {
            Intent intent = new Intent(this$0.requireContext(), OTPScreenWebView.class);
            intent.putExtra("url", url);
            this$0.startActivity(intent);
         }
      } catch (JSONException var8) {
         FragmentNetBankingBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.errorField.setVisibility(0);
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.textView4.setText((CharSequence)"Error requesting payment");
         Log.e("Error in handling response", var8.toString());
         var8.printStackTrace();
      }

   }

   private static final void postRequest$lambda$24(NetBankingBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         FragmentNetBankingBottomSheetBinding var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.errorField.setVisibility(0);
         var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.textView4.setText((CharSequence)this$0.extractMessageFromErrorResponse(errorResponse));
         this$0.hideLoadingInButton();
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/NetBankingBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
