package com.example.tray;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import com.example.tray.databinding.FragmentPaymentFailureScreenBinding;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 \u00152\u00020\u0001:\u0001\u0015B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J&\u0010\r\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\u0012\u0010\u0013\u001a\u00020\u00142\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0016"},
   d2 = {"Lcom/example/tray/PaymentFailureScreen;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentPaymentFailureScreenBinding;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "onCreateDialog", "Landroid/app/Dialog;", "Companion", "Tray_release"}
)
public final class PaymentFailureScreen extends BottomSheetDialogFragment {
   @NotNull
   public static final PaymentFailureScreen.Companion Companion = new PaymentFailureScreen.Companion((DefaultConstructorMarker)null);
   private FragmentPaymentFailureScreenBinding binding;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentPaymentFailureScreenBinding.inflate(this.getLayoutInflater(), container, false);
      FragmentPaymentFailureScreenBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.retryButton.setOnClickListener(PaymentFailureScreen::onCreateView$lambda$0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      return (View)var10000.getRoot();
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(PaymentFailureScreen::onCreateDialog$lambda$2);
      return dialog;
   }

   private static final void onCreateView$lambda$0(PaymentFailureScreen this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.dismiss();
   }

   private static final void onCreateDialog$lambda$2(PaymentFailureScreen this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      Window window = d.getWindow();
      if (window != null) {
         int var7 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      int screenHeight = this$0.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.7D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 1:
               case 2:
               case 3:
               case 4:
               case 5:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/PaymentFailureScreen$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
