package com.example.tray;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.common.api.Status;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082D¢\u0006\u0002\n\u0000¨\u0006\f"},
   d2 = {"Lcom/example/tray/SmsReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "()V", "SMS_CONSENT_REQUEST", "", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "Tray_release"}
)
public final class SmsReceiver extends BroadcastReceiver {
   private final int SMS_CONSENT_REQUEST = 1010;

   public void onReceive(@NotNull Context context, @NotNull Intent intent) {
      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(intent, "intent");
      if (Intrinsics.areEqual("com.google.android.gms.auth.api.phone.SMS_RETRIEVED", intent.getAction())) {
         Bundle extras = intent.getExtras();
         Object var10000 = extras != null ? extras.get("com.google.android.gms.auth.api.phone.EXTRA_STATUS") : null;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type com.google.android.gms.common.api.Status");
         Status smsRetrieverStatus = (Status)var10000;
         switch(smsRetrieverStatus.getStatusCode()) {
         case 0:
            Intent var5 = (Intent)extras.getParcelable("com.google.android.gms.auth.api.phone.EXTRA_CONSENT_INTENT");

            try {
               ;
            } catch (ActivityNotFoundException var7) {
            }
         case 15:
         }
      }

   }
}
