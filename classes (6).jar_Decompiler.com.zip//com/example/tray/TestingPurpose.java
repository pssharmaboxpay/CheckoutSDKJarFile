package com.example.tray;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tray.R.layout;
import com.example.tray.paymentResult.PaymentResultObject;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\n¨\u0006\u000b"},
   d2 = {"Lcom/example/tray/TestingPurpose;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onPaymentResultCallback", "result", "Lcom/example/tray/paymentResult/PaymentResultObject;", "Tray_release"}
)
public final class TestingPurpose extends AppCompatActivity {
   protected void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.setContentView(layout.activity_testing_purpose);
      Log.d("called testing purpose", "here");
      (new BoxPayCheckout((Context)this, "3b9be777-2abc-491d-b2d5-6493104af4ab", (Function1)(new Function1<PaymentResultObject, Unit>(this) {
         public final void invoke(PaymentResultObject p0) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            ((TestingPurpose)this.receiver).onPaymentResultCallback(p0);
         }
      }), false, 8, (DefaultConstructorMarker)null)).display();
   }

   public final void onPaymentResultCallback(@NotNull PaymentResultObject result) {
      Intrinsics.checkNotNullParameter(result, "result");
      Intent intent;
      if (Intrinsics.areEqual(result.getStatus(), "Success")) {
         Log.d("onPaymentResultCallback", "Success");
         intent = new Intent((Context)this, SuccessScreenForTesting.class);
         this.startActivity(intent);
      } else {
         Log.d("onPaymentResultCallback", "Failure");
         intent = new Intent((Context)this, FailureScreenForTesting.class);
         this.startActivity(intent);
      }

   }
}
