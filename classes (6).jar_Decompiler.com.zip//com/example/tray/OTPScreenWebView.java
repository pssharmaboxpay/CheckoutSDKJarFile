package com.example.tray;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony.Sms;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStoreOwner;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.ViewModels.CallBackFunctions;
import com.example.tray.ViewModels.SharedViewModel;
import com.example.tray.databinding.ActivityOtpscreenWebViewBinding;
import com.example.tray.interfaces.OnWebViewCloseListener;
import com.example.tray.paymentResult.PaymentResultObject;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Closeable;
import java.util.concurrent.CancellationException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Function;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.Job.DefaultImpls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0099\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0003\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000b*\u0001D\b\u0000\u0018\u0000 ]2\u00020\u0001:\u0002]^B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010/\u001a\u000200J\u000e\u00101\u001a\u0002002\u0006\u00102\u001a\u00020\u0015J\b\u00103\u001a\u000200H\u0002J\u0012\u00104\u001a\u0002002\b\u00105\u001a\u0004\u0018\u000106H\u0015J\b\u00107\u001a\u000200H\u0002J\u000e\u00108\u001a\u00020\u001a2\u0006\u00109\u001a\u00020\u000bJ\b\u0010:\u001a\u000200H\u0002J+\u0010;\u001a\u0002002\u0006\u0010<\u001a\u00020,2\f\u0010=\u001a\b\u0012\u0004\u0012\u00020\u000b0>2\u0006\u0010?\u001a\u00020@H\u0016¢\u0006\u0002\u0010AJ\b\u0010B\u001a\u000200H\u0002J\u0010\u0010F\u001a\u0004\u0018\u00010\u000b2\u0006\u0010G\u001a\u00020\u000bJ\"\u0010H\u001a\u0002002\u0006\u0010<\u001a\u00020,2\u0006\u0010I\u001a\u00020,2\b\u0010J\u001a\u0004\u0018\u00010KH\u0014J\b\u0010L\u001a\u000200H\u0002J\u0006\u0010M\u001a\u000200J\b\u0010N\u001a\u000200H\u0002J\b\u0010O\u001a\u000200H\u0016J\u0010\u0010P\u001a\u0002002\b\u0010Q\u001a\u0004\u0018\u00010#J\u000e\u0010R\u001a\u0002002\u0006\u0010S\u001a\u00020TJ\u0010\u0010U\u001a\u0002002\u0006\u0010V\u001a\u00020\u000bH\u0002J\b\u0010W\u001a\u000200H\u0002J\b\u0010X\u001a\u000200H\u0002J\b\u0010Y\u001a\u000200H\u0014J\u0018\u0010Z\u001a\u0002002\u0006\u0010[\u001a\u00020\u000b2\u0006\u0010\\\u001a\u00020#H\u0002R\u001b\u0010\u0004\u001a\u00020\u00058BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007R\u0014\u0010\n\u001a\u00020\u000bX\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\u00020\u000bX\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0011\u0010\u0010\u001a\u00020\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0019\u001a\u00020\u001aX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010!\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082D¢\u0006\u0002\n\u0000R\u0010\u0010-\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010C\u001a\u00020DX\u0082\u0004¢\u0006\u0004\n\u0002\u0010E¨\u0006_"},
   d2 = {"Lcom/example/tray/OTPScreenWebView;", "Landroidx/appcompat/app/AppCompatActivity;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/ActivityOtpscreenWebViewBinding;", "getBinding", "()Lcom/example/tray/databinding/ActivityOtpscreenWebViewBinding;", "binding$delegate", "Lkotlin/Lazy;", "permissionReceive", "", "getPermissionReceive", "()Ljava/lang/String;", "permissionRead", "getPermissionRead", "smsVerificationReceiver", "Lcom/example/tray/SmsReceiver;", "getSmsVerificationReceiver", "()Lcom/example/tray/SmsReceiver;", "webViewCloseListener", "Lcom/example/tray/interfaces/OnWebViewCloseListener;", "job", "Lkotlinx/coroutines/Job;", "jobForFetchingSMS", "isBottomSheetShown", "", "()Z", "setBottomSheetShown", "(Z)V", "token", "requestQueue", "Lcom/android/volley/RequestQueue;", "successScreenFullReferencePath", "previousBottomSheet", "Landroid/content/Context;", "Base_Session_API_URL", "sharedViewModel", "Lcom/example/tray/ViewModels/SharedViewModel;", "handler", "Landroid/os/Handler;", "delayMillis", "", "SMS_CONSENT_REQUEST", "", "otpFetched", "startedCallsForOTPInject", "explicitDismiss", "", "setWebViewCloseListener", "listener", "notifyWebViewClosed", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "initAutoFill", "hasValidOTP", "input", "readSms", "onRequestPermissionsResult", "requestCode", "permissions", "", "grantResults", "", "(I[Ljava/lang/String;[I)V", "fetchAndInjectOtp", "runnable", "com/example/tray/OTPScreenWebView$runnable$1", "Lcom/example/tray/OTPScreenWebView$runnable$1;", "extractOTPFromMessage", "message", "onActivityResult", "resultCode", "data", "Landroid/content/Intent;", "unregisterReceiver", "stopTimer", "startFetchingOtpAtIntervals", "onBackPressed", "setPreviousBottomSheet", "bottomSheet", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "fetchStatusAndReason", "url", "startFunctionCalls", "fetchTransactionDetailsFromSharedPreferences", "onDestroy", "openActivity", "activityPath", "context", "Companion", "WebAppInterface", "Tray_release"}
)
public final class OTPScreenWebView extends AppCompatActivity {
   @NotNull
   public static final OTPScreenWebView.Companion Companion = new OTPScreenWebView.Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Lazy binding$delegate = LazyKt.lazy(OTPScreenWebView::binding_delegate$lambda$0);
   @NotNull
   private final String permissionReceive = "android.permission.RECEIVE_SMS";
   @NotNull
   private final String permissionRead = "android.permission.READ_SMS";
   @NotNull
   private final SmsReceiver smsVerificationReceiver = new SmsReceiver();
   @Nullable
   private OnWebViewCloseListener webViewCloseListener;
   @Nullable
   private Job job;
   @Nullable
   private Job jobForFetchingSMS;
   private boolean isBottomSheetShown;
   @Nullable
   private String token;
   private RequestQueue requestQueue;
   @Nullable
   private String successScreenFullReferencePath;
   @Nullable
   private Context previousBottomSheet;
   private String Base_Session_API_URL;
   private SharedViewModel sharedViewModel;
   @NotNull
   private final Handler handler = new Handler();
   private final long delayMillis = 4000L;
   private final int SMS_CONSENT_REQUEST = 1010;
   @Nullable
   private String otpFetched;
   private boolean startedCallsForOTPInject;
   @NotNull
   private final <undefinedtype> runnable = new Runnable() {
      public void run() {
         Log.d("otp fetched", "runnable " + OTPScreenWebView.this.otpFetched);
         OTPScreenWebView.this.fetchAndInjectOtp();
         OTPScreenWebView.this.handler.postDelayed((Runnable)this, OTPScreenWebView.this.delayMillis);
      }
   };

   private final ActivityOtpscreenWebViewBinding getBinding() {
      Lazy var1 = this.binding$delegate;
      return (ActivityOtpscreenWebViewBinding)var1.getValue();
   }

   @NotNull
   public final String getPermissionReceive() {
      return this.permissionReceive;
   }

   @NotNull
   public final String getPermissionRead() {
      return this.permissionRead;
   }

   @NotNull
   public final SmsReceiver getSmsVerificationReceiver() {
      return this.smsVerificationReceiver;
   }

   public final boolean isBottomSheetShown() {
      return this.isBottomSheetShown;
   }

   public final void setBottomSheetShown(boolean var1) {
      this.isBottomSheetShown = var1;
   }

   public final void explicitDismiss() {
      Log.d("cancel confirmation bottom sheet", "explicit dismiss called");
      this.finish();
   }

   public final void setWebViewCloseListener(@NotNull OnWebViewCloseListener listener) {
      Intrinsics.checkNotNullParameter(listener, "listener");
      this.webViewCloseListener = listener;
   }

   private final void notifyWebViewClosed() {
      OnWebViewCloseListener var10000 = this.webViewCloseListener;
      if (var10000 != null) {
         var10000.onWebViewClosed();
      }

   }

   @RequiresApi(26)
   protected void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      this.setContentView((View)this.getBinding().getRoot());
      this.sharedViewModel = (SharedViewModel)(new ViewModelProvider((ViewModelStoreOwner)this)).get(SharedViewModel.class);
      SharedViewModel var10000 = this.sharedViewModel;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedViewModel");
         var10000 = null;
      }

      LiveData var5 = var10000.getDismissBottomSheetEvent();
      LifecycleOwner var10001 = (LifecycleOwner)this;
      Function1 var2 = OTPScreenWebView::onCreate$lambda$1;
      var5.observe(var10001, (Observer)(new Observer(var2) {
         // $FF: synthetic field
         private final Function1 function;

         {
            Intrinsics.checkNotNullParameter(function, "function");
            this.function = function;
         }

         // $FF: synthetic method
         public final void onChanged(Object value) {
            this.function.invoke(value);
         }

         @NotNull
         public final Function<?> getFunctionDelegate() {
            return (Function)this.function;
         }

         public final boolean equals(@Nullable Object other) {
            return other instanceof Observer ? (other instanceof FunctionAdapter ? Intrinsics.areEqual(((FunctionAdapter)this).getFunctionDelegate(), ((FunctionAdapter)other).getFunctionDelegate()) : false) : false;
         }

         public final int hashCode() {
            return ((FunctionAdapter)this).getFunctionDelegate().hashCode();
         }
      }));
      SharedPreferences sharedPreferences = this.getSharedPreferences("TransactionDetails", 0);
      String environmentFetched = sharedPreferences.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.requestQueue = Volley.newRequestQueue((Context)this);
      String receivedUrl = this.getIntent().getStringExtra("url");
      Log.d("url", String.valueOf(receivedUrl));
      this.getBinding().webViewForOtpValidation.loadUrl(String.valueOf(receivedUrl));
      this.getBinding().webViewForOtpValidation.getSettings().setDomStorageEnabled(true);
      this.getBinding().webViewForOtpValidation.getSettings().setJavaScriptEnabled(true);
      this.startFunctionCalls();
      this.fetchTransactionDetailsFromSharedPreferences();
      (new Handler(Looper.getMainLooper())).postDelayed(OTPScreenWebView::onCreate$lambda$2, 5000L);
      this.getBinding().webViewForOtpValidation.setWebViewClient((WebViewClient)(new WebViewClient() {
         public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            Log.d("page finished loading", String.valueOf(url));
            if (!OTPScreenWebView.this.startedCallsForOTPInject) {
               OTPScreenWebView.this.startedCallsForOTPInject = true;
               OTPScreenWebView.this.startFetchingOtpAtIntervals();
            }

         }

         public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            Log.d("page failed loading", String.valueOf(error));
         }
      }));
   }

   private final void initAutoFill() {
      SmsRetriever.getClient((Activity)this).startSmsUserConsent((String)null).addOnCompleteListener(OTPScreenWebView::initAutoFill$lambda$3);
   }

   public final boolean hasValidOTP(@NotNull String input) {
      Intrinsics.checkNotNullParameter(input, "input");
      Regex regex = new Regex("(?:your|use this) (verification code|passcode|OTP)\\s*(\\d{6})(?<!\\d)", RegexOption.IGNORE_CASE);
      Log.d("Message Received", String.valueOf(regex.matches((CharSequence)input)));
      return regex.matches((CharSequence)input);
   }

   private final void readSms() {
      Activity var10000;
      try {
         ContentResolver var20 = this.getContentResolver();
         Intrinsics.checkNotNullExpressionValue(var20, "getContentResolver(...)");
         ContentResolver contentResolver = var20;
         Cursor cursor = contentResolver.query(Sms.CONTENT_URI, (String[])null, (String)null, (String[])null, "date DESC LIMIT 1");
         if (cursor != null) {
            Closeable var18 = (Closeable)cursor;
            Throwable var19 = null;

            try {
               Cursor it = (Cursor)var18;
               int var6 = false;
               if (it.moveToFirst()) {
                  String address = it.getString(it.getColumnIndexOrThrow("address"));
                  String body = it.getString(it.getColumnIndexOrThrow("body"));
                  Log.d("Message Received", "Address: " + address + ", Body: " + body);
                  Intrinsics.checkNotNull(body);
                  String extractedOTP = this.extractOTPFromMessage(body);
                  if (extractedOTP != null) {
                     Log.d("Extracted OTP", extractedOTP);
                     this.otpFetched = extractedOTP;
                     Job var21 = this.jobForFetchingSMS;
                     if (var21 != null) {
                        DefaultImpls.cancel$default(var21, (CancellationException)null, 1, (Object)null);
                        Unit var22 = Unit.INSTANCE;
                     } else {
                        var10000 = null;
                     }
                  } else {
                     Log.d("Extracted OTP", "null");
                  }
               } else {
                  Log.d("Message Received", "No SMS found");
               }
            } catch (Throwable var14) {
               var19 = var14;
               throw var14;
            } finally {
               CloseableKt.closeFinally(var18, var19);
            }
         }
      } catch (SecurityException var16) {
         Log.e("Error", "Permission Denied: " + var16.getMessage());
         String permission = "android.permission.RECEIVE_SMS";
         var10000 = (Activity)this;
         String[] var4 = new String[]{permission};
         ActivityCompat.requestPermissions(var10000, var4, 101);
      } catch (Exception var17) {
         Log.e("Error", "Error reading SMS: " + var17.getMessage());
      }

   }

   public void onRequestPermissionsResult(int requestCode, @NotNull String[] permissions, @NotNull int[] grantResults) {
      Intrinsics.checkNotNullParameter(permissions, "permissions");
      Intrinsics.checkNotNullParameter(grantResults, "grantResults");
      super.onRequestPermissionsResult(requestCode, permissions, grantResults);
      if (requestCode == 101 && grantResults.length != 0 && grantResults[0] == 0) {
         this.readSms();
      }

   }

   private final void fetchAndInjectOtp() {
      if (this.otpFetched == null) {
         Log.d("otp fetched", "null");
      } else {
         String var10000 = this.otpFetched;
         Intrinsics.checkNotNull(var10000);
         int otpNum = Integer.parseInt(var10000);
         this.getBinding().webViewForOtpValidation.addJavascriptInterface(new OTPScreenWebView.WebAppInterface((Context)this), "Android");
         Log.d("OTP Validation", String.valueOf(this.otpFetched));
         String jsCode = StringsKt.trimIndent("\n            var proceedButtonIDFC = document.querySelector('.btn-idfc-maroon');\n            var inputFieldWithPassword = document.querySelector('input[type=\"password\"]');\n            var inputFieldWithAutoComplete = document.querySelector('input[autocomplete=\"one-time-code\"]'); \n    var inputField = document.querySelector('input'); // Assuming this is your OTP input field\nvar submitButton = document.querySelector('button[type=\"submit\"]');\nvar submitButtonMainButton = document.querySelector('td.mainbutton a#submitOTP');\nvar makePaymentButton = document.querySelector('button[type=\"button\"]');\nvar amexContinueButton = document.querySelector('#otcContinueBtn');\n\nif(inputFieldWithAutoComplete){\n    inputFieldWithAutoComplete.type = \"text\";\n inputFieldWithAutoComplete.value = \"" + this.otpFetched + "\";\n    setTimeout(function() {\n    if(submitButtonMainButton){\n        submitButtonMainButton.disabled = false;\n                setTimeout(function() {\n                    submitButtonMainButton.click(); // Click the submit button after a delay\n                }, 2000);\n        }\n        else if (submitButton) {\n            if (submitButton.disabled) {\n                // If the submit button is disabled, enable it\n                submitButton.disabled = false;\n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            } else {\n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            }\n        }\n        // Change back to password after a de   lay\n        \n       }, 1000);\n    }\nelse if(inputFieldWithPassword){\ninputFieldWithPassword.value = \"" + this.otpFetched + "\";\n    setTimeout(function() {\n    if(amexContinueButton){\n                setTimeout(function() {\n                    amexContinueButton.click(); // Click the submit button after a delay\n                }, 2000);\n    }\n    else if(proceedButtonIDFC){\n    proceedButtonIDFC.disabled = false;\n                setTimeout(function() {\n                    proceedButtonIDFC.click(); // Click the submit button after a delay\n                }, 2000);\n    }\n    else if(submitButtonMainButton){\n        submitButtonMainButton.disabled = false;\n                setTimeout(function() {\n                    submitButtonMainButton.click(); // Click the submit button after a delay\n                }, 2000);\n        }\n        else if (submitButton) {\n            if (submitButton.disabled) {\n                // If the submit button is disabled, enable it\n                submitButton.disabled = false;\n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            } else {\n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            }\n        }else if(makePaymentButton){\n        if (makePaymentButton.disabled) {\n                // If the submit button is disabled, enable it\n                makePaymentButton.disabled = false;\n                setTimeout(function() {\n                    makePaymentButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            } else {\n                setTimeout(function() {\n                    makePaymentButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            }\n        }\n        \n        // Change back to password after a delay\n        \n    }, 1000); \n}\nelse if (inputField) {\n    inputField.value = \"" + this.otpFetched + "\";\n    setTimeout(function() {\n    if(submitButtonMainButton){\n        submitButtonMainButton.disabled = false;\n       \n                setTimeout(function() {\n                    submitButtonMainButton.click(); // Click the submit button after a delay\n                }, 2000);\n        }\n        else if (submitButton) {\n       \n        \n            if (submitButton.disabled) {\n                // If the submit button is disabled, enable it\n                submitButton.disabled = false;\n      \n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            } else {\n                setTimeout(function() {\n                    submitButton.click(); // Click the submit button after a delay\n                }, 2000); // Adjust the delay time as needed\n            }\n        }\n      \n        // Change back to password after a delay\n      \n    }, 1000); // Set the OTP value in the input field after a delay\n} else {\n    // Handle the case where the input field is not found\n}\n");
         this.getBinding().webViewForOtpValidation.evaluateJavascript(jsCode, OTPScreenWebView::fetchAndInjectOtp$lambda$5);
      }
   }

   @Nullable
   public final String extractOTPFromMessage(@NotNull String message) {
      Intrinsics.checkNotNullParameter(message, "message");
      String regex = "\\b\\d{4}\\b|\\b\\d{6}\\b";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher((CharSequence)message);
      if (matcher.find()) {
         return matcher.group();
      } else {
         Log.d("otp fetched", "extract OTP FROM MESSAGE null");
         return null;
      }
   }

   protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
      super.onActivityResult(requestCode, resultCode, data);
      if (requestCode == 1010 && resultCode == -1 && data != null) {
         String message = data.getStringExtra("com.google.android.gms.auth.api.phone.EXTRA_SMS_MESSAGE");
         this.otpFetched = this.extractOTPFromMessage(String.valueOf(message));
         Log.d("message fetched", String.valueOf(this.otpFetched));
      }

   }

   private final void unregisterReceiver() {
      try {
         this.unregisterReceiver((BroadcastReceiver)this.smsVerificationReceiver);
      } catch (IllegalArgumentException var2) {
      }

   }

   public final void stopTimer() {
      this.handler.removeCallbacks((Runnable)this.runnable);
   }

   private final void startFetchingOtpAtIntervals() {
      this.fetchAndInjectOtp();
      Log.d("otp fetched", "start fetching otp intervals");
      this.handler.postDelayed((Runnable)this.runnable, this.delayMillis);
   }

   public void onBackPressed() {
      if (!this.isBottomSheetShown) {
         CancelConfirmationBottomSheet bottomSheet = new CancelConfirmationBottomSheet();
         bottomSheet.show(this.getSupportFragmentManager(), "CancelConfirmationBottomSheet");
      } else {
         super.onBackPressed();
      }

   }

   public final void setPreviousBottomSheet(@Nullable Context bottomSheet) {
      this.previousBottomSheet = bottomSheet;
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Fetch Status", jsonStr);
   }

   private final void fetchStatusAndReason(String url) {
      Log.d("fetching function called correctly", "Fine");
      JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, url, (JSONObject)null, OTPScreenWebView::fetchStatusAndReason$lambda$6, OTPScreenWebView::fetchStatusAndReason$lambda$7);
      RequestQueue var10000 = this.requestQueue;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("requestQueue");
         var10000 = null;
      }

      var10000.add((Request)jsonObjectRequest);
   }

   private final void startFunctionCalls() {
      this.job = BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getIO()), (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         public final Object invokeSuspend(Object $result) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            CoroutineScope $this$launch;
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               $this$launch = (CoroutineScope)this.L$0;
               break;
            case 1:
               $this$launch = (CoroutineScope)this.L$0;
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            Continuation var4;
            do {
               if (!CoroutineScopeKt.isActive($this$launch)) {
                  return Unit.INSTANCE;
               }

               OTPScreenWebView var10000 = OTPScreenWebView.this;
               StringBuilder var10001 = new StringBuilder();
               String var10002 = OTPScreenWebView.this.Base_Session_API_URL;
               if (var10002 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
                  var10002 = null;
               }

               var10000.fetchStatusAndReason(var10001.append(var10002).append(OTPScreenWebView.this.token).append("/status").toString());
               var4 = (Continuation)this;
               this.L$0 = $this$launch;
               this.label = 1;
            } while(DelayKt.delay(2000L, var4) != var3);

            return var3;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            Function2 var3 = new <anonymous constructor>($completion);
            var3.L$0 = value;
            return (Continuation)var3;
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences sharedPreferences = this.getSharedPreferences("TransactionDetails", 0);
      this.token = sharedPreferences.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      this.successScreenFullReferencePath = sharedPreferences.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   protected void onDestroy() {
      super.onDestroy();
      Job var10000 = this.job;
      if (var10000 != null) {
         DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
      }

   }

   private final void openActivity(String activityPath, Context context) {
      if (context instanceof AppCompatActivity) {
         try {
            Class activityClass = Class.forName(activityPath);
            Object var10000 = activityClass.getDeclaredConstructor().newInstance();
            Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type androidx.appcompat.app.AppCompatActivity");
            AppCompatActivity activityInstance = (AppCompatActivity)var10000;
            if (activityInstance instanceof AppCompatActivity) {
               ((AppCompatActivity)context).startActivity(new Intent(context, activityClass));
            }
         } catch (ClassNotFoundException var5) {
         }
      }

   }

   private static final ActivityOtpscreenWebViewBinding binding_delegate$lambda$0(OTPScreenWebView this$0) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      return ActivityOtpscreenWebViewBinding.inflate(this$0.getLayoutInflater());
   }

   private static final Unit onCreate$lambda$1(OTPScreenWebView this$0, Boolean dismissed) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (dismissed) {
         this$0.explicitDismiss();
         SharedViewModel var10000 = this$0.sharedViewModel;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sharedViewModel");
            var10000 = null;
         }

         var10000.bottomSheetDismissed();
      }

      this$0.isBottomSheetShown = false;
      return Unit.INSTANCE;
   }

   private static final void onCreate$lambda$2(final OTPScreenWebView this$0) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Activity var10000;
      String[] var1;
      if (ContextCompat.checkSelfPermission((Context)this$0, this$0.permissionReceive) == 0) {
         Log.d("Permission given", "For Receive SMS");
      } else {
         var10000 = (Activity)this$0;
         var1 = new String[]{this$0.permissionReceive};
         ActivityCompat.requestPermissions(var10000, var1, 101);
      }

      if (ContextCompat.checkSelfPermission((Context)this$0, this$0.permissionRead) == 0) {
         Log.d("Permission given", "For Read SMS");
      } else {
         var10000 = (Activity)this$0;
         var1 = new String[]{this$0.permissionRead};
         ActivityCompat.requestPermissions(var10000, var1, 101);
      }

      if (ContextCompat.checkSelfPermission((Context)this$0, this$0.permissionRead) == 0 && ContextCompat.checkSelfPermission((Context)this$0, this$0.permissionReceive) == 0) {
         IntentFilter intentFilter = new IntentFilter("com.google.android.gms.auth.api.phone.SMS_RETRIEVED");
         this$0.registerReceiver((BroadcastReceiver)this$0.smsVerificationReceiver, intentFilter, 1);
         this$0.readSms();
      } else {
         var10000 = (Activity)this$0;
         var1 = new String[]{this$0.permissionRead, this$0.permissionReceive};
         ActivityCompat.requestPermissions(var10000, var1, 101);
      }

      this$0.jobForFetchingSMS = BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getIO()), (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         public final Object invokeSuspend(Object $result) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            CoroutineScope $this$launch;
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               $this$launch = (CoroutineScope)this.L$0;
               break;
            case 1:
               $this$launch = (CoroutineScope)this.L$0;
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            Continuation var10001;
            do {
               if (!CoroutineScopeKt.isActive($this$launch)) {
                  return Unit.INSTANCE;
               }

               Log.d("Read Sms", "Called");
               this$0.readSms();
               var10001 = (Continuation)this;
               this.L$0 = $this$launch;
               this.label = 1;
            } while(DelayKt.delay(1000L, var10001) != var3);

            return var3;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            Function2 var3 = new <anonymous constructor>($completion);
            var3.L$0 = value;
            return (Continuation)var3;
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   private static final void initAutoFill$lambda$3(Task task) {
      Intrinsics.checkNotNullParameter(task, "task");
      if (task.isSuccessful()) {
         Log.d("ADD Card listening", "here");
      } else {
         Log.d("ADD Card listening failed", "here");
      }

   }

   private static final void fetchAndInjectOtp$lambda$5(OTPScreenWebView this$0, String value) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (value != null) {
         if (StringsKt.startsWith$default(value, "throw", false, 2, (Object)null)) {
            Log.e("JavaScript Error", value);
         } else {
            this$0.otpFetched = null;
            Log.d("JavaScript Result", value);
         }
      }

   }

   private static final void fetchStatusAndReason$lambda$6(OTPScreenWebView this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObject(response);
         String status = response.getString("status");
         String statusReason = response.getString("statusReason");
         Log.d("WebView Status", status);
         Log.d("Status Reason", statusReason);
         Intrinsics.checkNotNull(status);
         Job var10000;
         if (!StringsKt.contains((CharSequence)status, (CharSequence)"Approved", true)) {
            Intrinsics.checkNotNull(statusReason);
            if (!StringsKt.contains((CharSequence)statusReason, (CharSequence)"Received by BoxPay for processing", true) && !StringsKt.contains((CharSequence)statusReason, (CharSequence)"Approved by PSP", true) && !StringsKt.contains((CharSequence)status, (CharSequence)"PAID", true)) {
               if (!StringsKt.contains((CharSequence)status, (CharSequence)"PENDING", true)) {
                  if (StringsKt.contains((CharSequence)status, (CharSequence)"EXPIRED", true)) {
                     var10000 = this$0.job;
                     if (var10000 != null) {
                        DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                     }

                     return;
                  } else {
                     if (!StringsKt.contains((CharSequence)status, (CharSequence)"PROCESSING", true)) {
                        .FailureScreenSharedViewModel callback;
                        if (StringsKt.contains((CharSequence)status, (CharSequence)"FAILED", true)) {
                           var10000 = this$0.job;
                           if (var10000 != null) {
                              DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                           }

                           callback = FailureScreenCallBackSingletonClass.Companion.getInstance().getYourObject();
                           if (callback == null) {
                              Log.d("callback is null", "PaymentFailed");
                           } else {
                              callback.getOpenFailureScreen().invoke();
                           }

                           this$0.finish();
                           Log.d("Failure Screen View Model", "OTP Screen " + status);
                        } else if (StringsKt.contains((CharSequence)status, (CharSequence)"Rejected", true)) {
                           Log.d("Failure Screen View Model", "OTP Screen " + status);
                           var10000 = this$0.job;
                           if (var10000 != null) {
                              DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                           }

                           callback = FailureScreenCallBackSingletonClass.Companion.getInstance().getYourObject();
                           if (callback == null) {
                              Log.d("callback is null", "PaymentFailed");
                           } else {
                              callback.getOpenFailureScreen().invoke();
                           }

                           this$0.finish();
                           return;
                        }

                        return;
                     }

                     return;
                  }
               }

               return;
            }
         }

         var10000 = this$0.job;
         if (var10000 != null) {
            DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
         }

         SharedPreferences sharedPreferences = this$0.getSharedPreferences("TransactionDetails", 0);
         CallBackFunctions callback = .SingletonClass.Companion.getInstance().getYourObject();
         if (callback == null) {
            Log.d("call back is null", "Success");
         } else {
            var10000 = this$0.job;
            if (var10000 != null) {
               DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
            }

            callback.getOnPaymentResult().invoke(new PaymentResultObject("Success"));
            this$0.finish();
         }
      } catch (JSONException var6) {
         var6.printStackTrace();
      }

   }

   private static final void fetchStatusAndReason$lambda$7(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/OTPScreenWebView$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0007J\u0010\u0010\n\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"},
      d2 = {"Lcom/example/tray/OTPScreenWebView$WebAppInterface;", "", "mContext", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "showToast", "", "message", "", "logStatement", "Tray_release"}
   )
   public static final class WebAppInterface {
      @NotNull
      private final Context mContext;

      public WebAppInterface(@NotNull Context mContext) {
         Intrinsics.checkNotNullParameter(mContext, "mContext");
         super();
         this.mContext = mContext;
      }

      @JavascriptInterface
      public final void showToast(@NotNull String message) {
         Intrinsics.checkNotNullParameter(message, "message");
         if (!Intrinsics.areEqual(message, "Success")) {
            Toast.makeText(this.mContext, (CharSequence)message, 0).show();
         }

      }

      @JavascriptInterface
      public final void logStatement(@NotNull String message) {
         Intrinsics.checkNotNullParameter(message, "message");
         Log.d("OTP Validation", message);
      }
   }
}
