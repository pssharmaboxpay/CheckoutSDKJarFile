package com.example.tray.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0006R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\b8F¢\u0006\u0006\u001a\u0004\b\t\u0010\n¨\u0006\u000e"},
   d2 = {"Lcom/example/tray/ViewModels/OverlayViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "_showOverlay", "Landroidx/lifecycle/MutableLiveData;", "", "showOverlay", "Landroidx/lifecycle/LiveData;", "getShowOverlay", "()Landroidx/lifecycle/LiveData;", "setShowOverlay", "", "value", "Tray_release"}
)
public final class OverlayViewModel extends ViewModel {
   @NotNull
   private final MutableLiveData<Boolean> _showOverlay = new MutableLiveData();

   public OverlayViewModel() {
      this._showOverlay.setValue(true);
   }

   @NotNull
   public final LiveData<Boolean> getShowOverlay() {
      return (LiveData)this._showOverlay;
   }

   public final void setShowOverlay(boolean value) {
      this._showOverlay.setValue(value);
   }
}
