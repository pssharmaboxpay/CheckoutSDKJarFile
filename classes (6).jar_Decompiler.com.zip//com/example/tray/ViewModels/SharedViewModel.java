package com.example.tray.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\fR\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u000e"},
   d2 = {"Lcom/example/tray/ViewModels/SharedViewModel;", "Landroidx/lifecycle/ViewModel;", "<init>", "()V", "_dismissBottomSheetEvent", "Landroidx/lifecycle/MutableLiveData;", "", "dismissBottomSheetEvent", "Landroidx/lifecycle/LiveData;", "getDismissBottomSheetEvent", "()Landroidx/lifecycle/LiveData;", "dismissBottomSheet", "", "bottomSheetDismissed", "Tray_release"}
)
public final class SharedViewModel extends ViewModel {
   @NotNull
   private final MutableLiveData<Boolean> _dismissBottomSheetEvent = new MutableLiveData();
   @NotNull
   private final LiveData<Boolean> dismissBottomSheetEvent;

   public SharedViewModel() {
      this.dismissBottomSheetEvent = (LiveData)this._dismissBottomSheetEvent;
   }

   @NotNull
   public final LiveData<Boolean> getDismissBottomSheetEvent() {
      return this.dismissBottomSheetEvent;
   }

   public final void dismissBottomSheet() {
      this._dismissBottomSheetEvent.setValue(true);
   }

   public final void bottomSheetDismissed() {
      this._dismissBottomSheetEvent.setValue(false);
   }
}
