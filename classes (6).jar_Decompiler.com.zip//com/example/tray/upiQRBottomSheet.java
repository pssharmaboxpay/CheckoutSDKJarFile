package com.example.tray;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.databinding.FragmentUpiQRBottomSheetBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \"2\u00020\u0001:\u0001\"B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J&\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u00172\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\u0010\u0010\u0018\u001a\u00020\u000f2\u0006\u0010\u0019\u001a\u00020\u001aH\u0002J\u0010\u0010\u001b\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u000bH\u0002J\u000e\u0010\u001d\u001a\u00020\u000f2\u0006\u0010\u001e\u001a\u00020\u001fJ\u000e\u0010 \u001a\u00020\u000b2\u0006\u0010!\u001a\u00020\u000bR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006#"},
   d2 = {"Lcom/example/tray/upiQRBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentUpiQRBottomSheetBinding;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "Base_Session_API_URL", "", "transactionId", "token", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "postRequest", "context", "Landroid/content/Context;", "updateTransactionIDInSharedPreferences", "transactionIdArg", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "urlToBase64", "base64String", "Companion", "Tray_release"}
)
public final class upiQRBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final upiQRBottomSheet.Companion Companion = new upiQRBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentUpiQRBottomSheetBinding binding;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   private String Base_Session_API_URL;
   @Nullable
   private String transactionId;
   @Nullable
   private String token;

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentUpiQRBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.token = var10001.getString("token", "empty");
      SharedPreferences var10000 = this.sharedPreferences;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10000 = null;
      }

      String environmentFetched = var10000.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      Context var6 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var6, "requireContext(...)");
      this.postRequest(var6);
      FragmentUpiQRBottomSheetBinding var5 = this.binding;
      if (var5 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var5 = null;
      }

      return (View)var5.getRoot();
   }

   private final void postRequest(Context context) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var4 = new JSONObject();
      int var6 = false;
      JSONObject var7 = new JSONObject();
      int var9 = false;
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("state", var10002.getString("state", "null"));
      var4.put("billingAddress", var7);
      JSONObject var8 = new JSONObject();
      int var11 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var8.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var8.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var8.put("acceptHeader", "application/json");
      var8.put("userAgentHeader", userAgentHeader);
      var8.put("browserLanguage", Locale.getDefault().toString());
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("ipAddress", var10002.getString("ipAddress", "null"));
      var8.put("colorDepth", 24);
      var8.put("javaEnabled", true);
      var8.put("timeZoneOffSet", 330);
      var4.put("browserData", var8);
      JSONObject var23 = new JSONObject();
      int var12 = false;
      var23.put("type", "upi/qr");
      var4.put("instrumentDetails", var23);
      JSONObject var25 = new JSONObject();
      int var26 = false;
      JSONObject var27 = new JSONObject();
      int var16 = false;
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var27.put("state", var10002.getString("state", "null"));
      var25.put("deliveryAddress", var27);
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var25.put("email", var10002.getString("email", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var25.put("firstName", var10002.getString("firstName", "null"));
      SharedPreferences var28 = this.sharedPreferences;
      if (var28 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var28 = null;
      }

      if (Intrinsics.areEqual(var28.getString("gender", "null"), "null")) {
         var25.put("gender", JSONObject.NULL);
      } else {
         var10002 = this.sharedPreferences;
         if (var10002 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
            var10002 = null;
         }

         var25.put("gender", var10002.getString("gender", "null"));
      }

      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var25.put("lastName", var10002.getString("lastName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var25.put("phoneNumber", var10002.getString("phoneNumber", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var25.put("uniqueReference", var10002.getString("uniqueReference", "null"));
      this.logJsonObject(var25);
      var4.put("shopper", var25);
      StringBuilder var29 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var5 = var29.append(var10001).append(this.token).toString();
      Listener var19 = upiQRBottomSheet::postRequest$lambda$6;
      ErrorListener var20 = upiQRBottomSheet::postRequest$lambda$7;
      JsonObjectRequest var18 = new JsonObjectRequest(var4, var5, var19, var20) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(upiQRBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var21 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var18.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var18);
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body UPI QR", jsonStr);
   }

   @NotNull
   public final String urlToBase64(@NotNull String base64String) {
      Intrinsics.checkNotNullParameter(base64String, "base64String");

      String var2;
      try {
         byte[] decodedBytes = Base64.decode(base64String, 0);
         Intrinsics.checkNotNull(decodedBytes);
         Charset var10000 = StandardCharsets.UTF_8;
         Intrinsics.checkNotNullExpressionValue(var10000, "UTF_8");
         Charset var5 = var10000;
         String decodedString = new String(decodedBytes, var5);
         var2 = URLDecoder.decode(decodedString, "UTF-8");
      } catch (Exception var6) {
         var6.printStackTrace();
         var2 = "";
      }

      return var2;
   }

   private static final void postRequest$lambda$6(upiQRBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.transactionId = response.getString("transactionId").toString();
      String var10001 = this$0.transactionId;
      Intrinsics.checkNotNull(var10001);
      this$0.updateTransactionIDInSharedPreferences(var10001);
      JSONObject valuesObject = response.getJSONArray("actions").getJSONObject(0);
      String urlBase64 = valuesObject.getString("content");
      Log.d("urlBase64", urlBase64);
      byte[] var10000 = Base64.decode(urlBase64, 0);
      Intrinsics.checkNotNullExpressionValue(var10000, "decode(...)");
      byte[] decodedBytes = var10000;
      Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
      FragmentUpiQRBottomSheetBinding var7 = this$0.binding;
      if (var7 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var7 = null;
      }

      ImageView var8 = var7.qrCode;
      Intrinsics.checkNotNullExpressionValue(var8, "qrCode");
      ImageView imageView = var8;
      imageView.setImageBitmap(bitmap);
      Intrinsics.checkNotNull(response);
      this$0.logJsonObject(response);
   }

   private static final void postRequest$lambda$7(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/upiQRBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
