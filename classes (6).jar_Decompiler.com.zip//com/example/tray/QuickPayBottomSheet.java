package com.example.tray;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.databinding.FragmentQuickPayBottomSheetBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 $2\u00020\u0001:\u0001$B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J&\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u00172\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u0018\u001a\u00020\u000fH\u0002J\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u001a\u001a\u00020\u000bJ\u000e\u0010\u001b\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0018\u0010\u001e\u001a\u00020\u000f2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u000bH\u0002J\u0010\u0010\"\u001a\u00020\u000f2\u0006\u0010#\u001a\u00020\u000bH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"},
   d2 = {"Lcom/example/tray/QuickPayBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentQuickPayBottomSheetBinding;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "Base_Session_API_URL", "", "transactionId", "token", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "fetchLastUsedPaymentMethods", "extractMessageFromErrorResponse", "response", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "postRequestForUPICollect", "context", "Landroid/content/Context;", "userVPA", "updateTransactionIDInSharedPreferences", "transactionIdArg", "Companion", "Tray_release"}
)
public final class QuickPayBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final QuickPayBottomSheet.Companion Companion = new QuickPayBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentQuickPayBottomSheetBinding binding;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   private String Base_Session_API_URL;
   @Nullable
   private String transactionId;
   @Nullable
   private String token;

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentQuickPayBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      SharedPreferences var10000 = this.sharedPreferences;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10000 = null;
      }

      String environmentFetched = var10000.getString("environment", "null");
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.token = var10001.getString("token", "empty");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchLastUsedPaymentMethods();
      FragmentQuickPayBottomSheetBinding var5 = this.binding;
      if (var5 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var5 = null;
      }

      return (View)var5.getRoot();
   }

   private final void fetchLastUsedPaymentMethods() {
      SharedPreferences sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      RequestQueue var10000 = Volley.newRequestQueue(this.getContext());
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      String environmentFetched = sharedPreferences.getString("environment", "null");
      String url = "https://" + environmentFetched + "apis.boxpay.tech/v0/shoppers/+919818198330/instruments";
      Listener var6 = QuickPayBottomSheet::fetchLastUsedPaymentMethods$lambda$0;
      ErrorListener var7 = QuickPayBottomSheet::fetchLastUsedPaymentMethods$lambda$1;
      JsonArrayRequest var12 = new JsonArrayRequest(url, var6, var7) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("Authorization", "Session 82168892-b4a6-4b44-8a66-120fe5c6329f");
            return (Map)headers;
         }
      };
      int var8 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var12.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var12);
   }

   @Nullable
   public final String extractMessageFromErrorResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");

      try {
         JSONObject jsonObject = new JSONObject(response);
         return jsonObject.getString("message");
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body QuickPay", jsonStr);
   }

   private final void postRequestForUPICollect(Context context, String userVPA) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var5 = new JSONObject();
      int var7 = false;
      JSONObject var8 = new JSONObject();
      int var10 = false;
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("state", var10002.getString("state", "null"));
      var5.put("billingAddress", var8);
      JSONObject var9 = new JSONObject();
      int var12 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var9.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var9.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var9.put("acceptHeader", "application/json");
      var9.put("userAgentHeader", userAgentHeader);
      var9.put("browserLanguage", Locale.getDefault().toString());
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var9.put("ipAddress", var10002.getString("ipAddress", "null"));
      var9.put("colorDepth", 24);
      var9.put("javaEnabled", true);
      var9.put("timeZoneOffSet", 330);
      var5.put("browserData", var9);
      JSONObject var24 = new JSONObject();
      int var13 = false;
      var24.put("type", "upi/collect");
      JSONObject var27 = new JSONObject();
      int var16 = false;
      var27.put("shopperVpa", userVPA);
      var24.put("upi", var27);
      var5.put("instrumentDetails", var24);
      JSONObject var26 = new JSONObject();
      int var28 = false;
      JSONObject var29 = new JSONObject();
      int var17 = false;
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("state", var10002.getString("state", "null"));
      var26.put("deliveryAddress", var29);
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("email", var10002.getString("email", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("firstName", var10002.getString("firstName", "null"));
      SharedPreferences var30 = this.sharedPreferences;
      if (var30 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var30 = null;
      }

      if (Intrinsics.areEqual(var30.getString("gender", "null"), "null")) {
         var26.put("gender", JSONObject.NULL);
      } else {
         var10002 = this.sharedPreferences;
         if (var10002 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
            var10002 = null;
         }

         var26.put("gender", var10002.getString("gender", "null"));
      }

      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("lastName", var10002.getString("lastName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("phoneNumber", var10002.getString("phoneNumber", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("uniqueReference", var10002.getString("uniqueReference", "null"));
      this.logJsonObject(var26);
      var5.put("shopper", var26);
      StringBuilder var31 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var6 = var31.append(var10001).append(this.token).toString();
      Listener var20 = QuickPayBottomSheet::postRequestForUPICollect$lambda$10;
      ErrorListener var21 = QuickPayBottomSheet::postRequestForUPICollect$lambda$11;
      JsonObjectRequest var19 = new JsonObjectRequest(var5, var6, var20, var21) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(QuickPayBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var22 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var19.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var19);
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   private static final void fetchLastUsedPaymentMethods$lambda$0(QuickPayBottomSheet this$0, JSONArray response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      JSONObject var10001 = response.getJSONObject(0);
      Intrinsics.checkNotNullExpressionValue(var10001, "getJSONObject(...)");
      this$0.logJsonObject(var10001);
   }

   private static final void fetchLastUsedPaymentMethods$lambda$1(QuickPayBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Detailed error response:", "Detailed error response: " + errorResponse);
         String errorMessage = String.valueOf(this$0.extractMessageFromErrorResponse(errorResponse));
         Log.d("Error message", errorMessage);
         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"Session is no longer accepting the payment as payment is already completed", true)) {
         }
      }

   }

   private static final void postRequestForUPICollect$lambda$10(QuickPayBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.transactionId = response.getString("transactionId").toString();
      String var10001 = this$0.transactionId;
      Intrinsics.checkNotNull(var10001);
      this$0.updateTransactionIDInSharedPreferences(var10001);
      Intrinsics.checkNotNull(response);
      this$0.logJsonObject(response);
   }

   private static final void postRequestForUPICollect$lambda$11(QuickPayBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         String errorMessage = String.valueOf(this$0.extractMessageFromErrorResponse(errorResponse));
         Log.d("Error message", errorMessage);
         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"Session is no longer accepting the payment as payment is already completed", true)) {
         }
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/QuickPayBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
