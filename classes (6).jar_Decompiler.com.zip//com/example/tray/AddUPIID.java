package com.example.tray;

import android.animation.ObjectAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.MutableLiveData;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.R.drawable;
import com.example.tray.databinding.FragmentAddUPIIDBinding;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0000\u0018\u0000 A2\u00020\u0001:\u0001AB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J&\u0010\u001c\u001a\u0004\u0018\u00010\n2\u0006\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010 2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0017J\u0010\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\fH\u0002J\b\u0010#\u001a\u00020\u0019H\u0002J\u001a\u0010$\u001a\u00020\u00192\u0006\u0010%\u001a\u00020\n2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\b\u0010&\u001a\u00020\u0019H\u0002J\u0012\u0010'\u001a\u00020(2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\u0010\u0010)\u001a\u00020\u00192\u0006\u0010*\u001a\u00020+H\u0016J\b\u0010,\u001a\u00020\u0019H\u0016J\u0010\u0010-\u001a\u00020\u00192\u0006\u0010*\u001a\u00020+H\u0016J\b\u0010.\u001a\u00020\u0019H\u0002J\u0006\u0010/\u001a\u00020\u0019J\u0018\u00100\u001a\u00020\u00192\u0006\u00101\u001a\u0002022\u0006\u0010\u0012\u001a\u00020\fH\u0002J\u000e\u00103\u001a\u00020\u00192\u0006\u00104\u001a\u000205J\u0006\u00106\u001a\u00020\u0019J\u0006\u00107\u001a\u00020\u0019J\b\u00108\u001a\u00020\u0019H\u0002J\b\u00109\u001a\u00020\u0019H\u0002J\b\u0010:\u001a\u00020\u0019H\u0002J\u0010\u0010;\u001a\u0004\u0018\u00010\f2\u0006\u0010<\u001a\u00020\fJ\u0010\u0010=\u001a\u00020\u00192\u0006\u0010>\u001a\u00020?H\u0002J\u0010\u0010@\u001a\u00020\u00192\u0006\u00101\u001a\u000202H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006B"},
   d2 = {"Lcom/example/tray/AddUPIID;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentAddUPIIDBinding;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "overlayViewCurrentBottomSheet", "Landroid/view/View;", "Base_Session_API_URL", "", "token", "proceedButtonIsEnabled", "Landroidx/lifecycle/MutableLiveData;", "", "successScreenFullReferencePath", "userVPA", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "transactionId", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "updateTransactionIDInSharedPreferences", "transactionIdArg", "fetchTransactionDetailsFromSharedPreferences", "onViewCreated", "view", "dismissAndMakeButtonsOfMainBottomSheetEnabled", "onCreateDialog", "Landroid/app/Dialog;", "onCancel", "dialog", "Landroid/content/DialogInterface;", "onStart", "onDismiss", "showOverlayInCurrentBottomSheet", "removeOverlayFromCurrentBottomSheet", "postRequest", "context", "Landroid/content/Context;", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "hideLoadingInButton", "showLoadingInButton", "enableProceedButton", "disableProceedButton", "openUPITimerBottomSheet", "extractMessageFromErrorResponse", "response", "closeKeyboard", "fragment", "Landroidx/fragment/app/Fragment;", "launchSuccessScreen", "Companion", "Tray_release"}
)
public final class AddUPIID extends BottomSheetDialogFragment {
   @NotNull
   public static final AddUPIID.Companion Companion = new AddUPIID.Companion((DefaultConstructorMarker)null);
   private FragmentAddUPIIDBinding binding;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @Nullable
   private View overlayViewCurrentBottomSheet;
   private String Base_Session_API_URL;
   @Nullable
   private String token;
   @NotNull
   private MutableLiveData<Boolean> proceedButtonIsEnabled = new MutableLiveData();
   @Nullable
   private String successScreenFullReferencePath;
   @Nullable
   private String userVPA;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   @Nullable
   private String transactionId;

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @RequiresApi(26)
   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentAddUPIIDBinding.inflate(inflater, container, false);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      SharedPreferences var10000 = this.sharedPreferences;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10000 = null;
      }

      String environmentFetched = var10000.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.requireActivity().setRequestedOrientation(1);
      }

      BooleanRef checked = new BooleanRef();
      Dialog var7 = this.getDialog();
      if (var7 != null) {
         Window var8 = var7.getWindow();
         if (var8 != null) {
            var8.setSoftInputMode(16);
         }
      }

      FragmentAddUPIIDBinding var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.progressBar.setVisibility(4);
      Log.d("Timezone", TimeZone.getDefault().getID());
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.imageView3.setOnClickListener(AddUPIID::onCreateView$lambda$0);
      this.fetchTransactionDetailsFromSharedPreferences();
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.backButton.setOnClickListener(AddUPIID::onCreateView$lambda$1);
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.proceedButton.setEnabled(false);
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.editText.addTextChangedListener((TextWatcher)(new TextWatcher() {
         public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            Log.d("beforeTextChanged", String.valueOf(s));
         }

         public void onTextChanged(CharSequence s, int start, int before, int count) {
            String textNow = String.valueOf(s);
            Log.d("onTextChanged", String.valueOf(s));
            if (!StringsKt.isBlank((CharSequence)textNow)) {
               FragmentAddUPIIDBinding var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.proceedButtonRelativeLayout.setEnabled(true);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.proceedButton.setEnabled(true);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               RelativeLayout var8 = var10000.proceedButtonRelativeLayout;
               SharedPreferences var10001 = AddUPIID.this.sharedPreferences;
               if (var10001 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
                  var10001 = null;
               }

               var8.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.proceedButton.setBackgroundResource(drawable.button_bg);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.ll1InvalidUPI.setVisibility(8);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               TextView var6 = var10000.textView6;
               var10001 = AddUPIID.this.sharedPreferences;
               if (var10001 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
                  var10001 = null;
               }

               var6.setTextColor(Color.parseColor(var10001.getString("buttonTextColor", "#000000")));
               BottomSheetBehavior var7 = AddUPIID.this.bottomSheetBehavior;
               if (var7 != null) {
                  var7.setState(3);
               }
            }

         }

         public void afterTextChanged(Editable s) {
            String textNow = String.valueOf(s);
            Log.d("afterTextChanged", String.valueOf(s));
            if (StringsKt.isBlank((CharSequence)textNow)) {
               FragmentAddUPIIDBinding var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.proceedButtonRelativeLayout.setEnabled(false);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.disable_button);
               var10000 = AddUPIID.this.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.ll1InvalidUPI.setVisibility(8);
            }

         }
      }));
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.ll1InvalidUPI.setVisibility(8);
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      var9.proceedButton.setOnClickListener(AddUPIID::onCreateView$lambda$2);
      var9 = this.binding;
      if (var9 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var9 = null;
      }

      return (View)var9.getRoot();
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.token = var10001.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.successScreenFullReferencePath = var10001.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(view, "view");
      super.onViewCreated(view, savedInstanceState);
   }

   private final void dismissAndMakeButtonsOfMainBottomSheetEnabled() {
      Fragment var2 = this.getParentFragmentManager().findFragmentByTag("MainBottomSheet");
      MainBottomSheet mainBottomSheetFragment = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if (mainBottomSheetFragment != null) {
         mainBottomSheetFragment.enabledButtonsForAllPaymentMethods();
      }

      this.dismiss();
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(AddUPIID::onCreateDialog$lambda$4);
      return dialog;
   }

   public void onCancel(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onCancel(dialog);
      this.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   public void onStart() {
      super.onStart();
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      Fragment var2 = this.getParentFragment();
      MainBottomSheet var10000 = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if ((var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null) != null) {
         var10000.removeOverlayFromCurrentBottomSheet();
      }

      super.onDismiss(dialog);
   }

   private final void showOverlayInCurrentBottomSheet() {
      this.overlayViewCurrentBottomSheet = new View(this.requireContext());
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         var10000.setBackgroundColor(Color.parseColor("#80000000"));
      }

      FragmentAddUPIIDBinding var1 = this.binding;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var1 = null;
      }

      var1.getRoot().addView(this.overlayViewCurrentBottomSheet, -1, -1);
   }

   public final void removeOverlayFromCurrentBottomSheet() {
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         View it = var10000;
         int var2 = false;
         FragmentAddUPIIDBinding var3 = this.binding;
         if (var3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var3 = null;
         }

         var3.getRoot().removeView(it);
      }

   }

   private final void postRequest(Context context, String userVPA) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var5 = new JSONObject();
      int var7 = false;
      JSONObject var8 = new JSONObject();
      int var10 = false;
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("state", var10002.getString("state", "null"));
      var5.put("billingAddress", var8);
      JSONObject var9 = new JSONObject();
      int var12 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var9.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var9.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var9.put("acceptHeader", "application/json");
      var9.put("userAgentHeader", userAgentHeader);
      var9.put("browserLanguage", Locale.getDefault().toString());
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var9.put("ipAddress", var10002.getString("ipAddress", "null"));
      var9.put("colorDepth", 24);
      var9.put("javaEnabled", true);
      var9.put("timeZoneOffSet", 330);
      var5.put("browserData", var9);
      JSONObject var24 = new JSONObject();
      int var13 = false;
      var24.put("type", "upi/collect");
      JSONObject var27 = new JSONObject();
      int var16 = false;
      var27.put("shopperVpa", userVPA);
      var24.put("upi", var27);
      var5.put("instrumentDetails", var24);
      JSONObject var26 = new JSONObject();
      int var28 = false;
      JSONObject var29 = new JSONObject();
      int var17 = false;
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address1", var10002.getString("address1", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address2", var10002.getString("address2", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("address3", var10002.getString("address3", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("city", var10002.getString("city", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("countryCode", var10002.getString("countryCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("countryName", var10002.getString("countryName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("postalCode", var10002.getString("postalCode", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var29.put("state", var10002.getString("state", "null"));
      var26.put("deliveryAddress", var29);
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("email", var10002.getString("email", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("firstName", var10002.getString("firstName", "null"));
      SharedPreferences var30 = this.sharedPreferences;
      if (var30 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var30 = null;
      }

      if (Intrinsics.areEqual(var30.getString("gender", "null"), "null")) {
         var26.put("gender", JSONObject.NULL);
      } else {
         var10002 = this.sharedPreferences;
         if (var10002 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
            var10002 = null;
         }

         var26.put("gender", var10002.getString("gender", "null"));
      }

      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("lastName", var10002.getString("lastName", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("phoneNumber", var10002.getString("phoneNumber", "null"));
      var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var26.put("uniqueReference", var10002.getString("uniqueReference", "null"));
      this.logJsonObject(var26);
      var5.put("shopper", var26);
      StringBuilder var31 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var6 = var31.append(var10001).append(this.token).toString();
      Listener var20 = AddUPIID::postRequest$lambda$13;
      ErrorListener var21 = AddUPIID::postRequest$lambda$14;
      JsonObjectRequest var19 = new JsonObjectRequest(var5, var6, var20, var21) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(AddUPIID.this.token));
            return (Map)headers;
         }
      };
      int var22 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var19.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var19);
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body UPI", jsonStr);
   }

   public final void hideLoadingInButton() {
      FragmentAddUPIIDBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(ContextCompat.getColor(this.requireContext(), 17170443));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
   }

   public final void showLoadingInButton() {
      FragmentAddUPIIDBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      ProgressBar var3 = var10000.progressBar;
      float[] var2 = new float[]{0.0F, 360.0F};
      ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(var3, "rotation", var2);
      rotateAnimation.setDuration(3000L);
      rotateAnimation.setRepeatCount(-1);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      rotateAnimation.start();
   }

   private final void enableProceedButton() {
      FragmentAddUPIIDBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(ContextCompat.getColor(this.requireContext(), 17170443));
   }

   private final void disableProceedButton() {
      FragmentAddUPIIDBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(Color.parseColor("#ADACB0"));
   }

   private final void openUPITimerBottomSheet() {
      UPITimerBottomSheet bottomSheetFragment = UPITimerBottomSheet.Companion.newInstance(this.userVPA);
      bottomSheetFragment.show(this.getParentFragmentManager(), "UPITimerBottomSheet");
   }

   @Nullable
   public final String extractMessageFromErrorResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");

      try {
         JSONObject jsonObject = new JSONObject(response);
         return jsonObject.getString("message");
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   private final void closeKeyboard(Fragment fragment) {
      FragmentActivity activity = fragment.getActivity();
      View view = fragment.getView();
      if (activity != null && view != null) {
         InputMethodManager imm = (InputMethodManager)ContextCompat.getSystemService((Context)activity, InputMethodManager.class);
         if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
         }
      }

   }

   private final void launchSuccessScreen(Context context) {
      try {
         Intent var3 = new Intent();
         int var5 = false;
         var3.setClassName(context.getPackageName(), "com.example.AndroidCheckOutSDK.SuccessScreen");
         var3.setFlags(268435456);
         context.startActivity(var3);
      } catch (Exception var6) {
         Log.d("Exception in launching success screen : ", var6.toString());
         var6.printStackTrace();
      }

   }

   private static final void onCreateView$lambda$0(BooleanRef $checked, AddUPIID this$0, View it) {
      Intrinsics.checkNotNullParameter($checked, "$checked");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentAddUPIIDBinding var10000;
      if (!$checked.element) {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.imageView3.setImageResource(drawable.checkbox);
         $checked.element = true;
      } else {
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.imageView3.setImageResource(0);
         $checked.element = false;
      }

   }

   private static final void onCreateView$lambda$1(AddUPIID this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   private static final void onCreateView$lambda$2(AddUPIID this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentAddUPIIDBinding var10001 = this$0.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      this$0.userVPA = var10001.editText.getText().toString();
      this$0.closeKeyboard((Fragment)this$0);
      Context var2 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var2, "requireContext(...)");
      String var10002 = this$0.userVPA;
      Intrinsics.checkNotNull(var10002);
      this$0.postRequest(var2, var10002);
      this$0.showLoadingInButton();
   }

   private static final void onCreateDialog$lambda$4(final AddUPIID this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      Window window = d.getWindow();
      if (window != null) {
         int var7 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      int screenHeight = this$0.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.7D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final void postRequest$lambda$13(AddUPIID this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.transactionId = response.getString("transactionId").toString();
      String var10001 = this$0.transactionId;
      Intrinsics.checkNotNull(var10001);
      this$0.updateTransactionIDInSharedPreferences(var10001);
      this$0.openUPITimerBottomSheet();
      this$0.hideLoadingInButton();
      Intrinsics.checkNotNull(response);
      this$0.logJsonObject(response);
   }

   private static final void postRequest$lambda$14(AddUPIID this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         FragmentAddUPIIDBinding var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.ll1InvalidUPI.setVisibility(0);
         String errorMessage = String.valueOf(this$0.extractMessageFromErrorResponse(errorResponse));
         Log.d("Error message", errorMessage);
         if (StringsKt.contains((CharSequence)errorMessage, (CharSequence)"Session is no longer accepting the payment as payment is already completed", true)) {
            var4 = this$0.binding;
            if (var4 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var4 = null;
            }

            var4.textView4.setText((CharSequence)"Payment is already done");
         } else {
            var4 = this$0.binding;
            if (var4 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var4 = null;
            }

            var4.textView4.setText((CharSequence)"Invalid UPI ID");
         }

         this$0.hideLoadingInButton();
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/AddUPIID$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
