package com.example.tray;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import com.example.tray.ViewModels.CallBackFunctions;
import com.example.tray.paymentResult.PaymentResultObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\u0006\u0010\u0015\u001a\u00020\tJ\b\u0010\u0016\u001a\u00020\tH\u0002J\u0006\u0010\u0017\u001a\u00020\tJ\b\u0010\u0018\u001a\u00020\tH\u0002J\u000e\u0010\u0019\u001a\u00020\t2\u0006\u0010\u001a\u001a\u00020\u001bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001c"},
   d2 = {"Lcom/example/tray/BoxPayCheckout;", "", "context", "Landroid/content/Context;", "token", "", "onPaymentResult", "Lkotlin/Function1;", "Lcom/example/tray/paymentResult/PaymentResultObject;", "", "sandboxEnabled", "", "<init>", "(Landroid/content/Context;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Z)V", "getOnPaymentResult", "()Lkotlin/jvm/functions/Function1;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "environment", "display", "openBottomSheet", "initializingCallBackFunctions", "putTransactionDetailsInSharedPreferences", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "Tray_release"}
)
public final class BoxPayCheckout {
   @NotNull
   private final Context context;
   @NotNull
   private final String token;
   @NotNull
   private final Function1<PaymentResultObject, Unit> onPaymentResult;
   private final boolean sandboxEnabled;
   @NotNull
   private SharedPreferences sharedPreferences;
   @NotNull
   private Editor editor;
   @NotNull
   private String environment;

   public BoxPayCheckout(@NotNull Context context, @NotNull String token, @NotNull Function1<? super PaymentResultObject, Unit> onPaymentResult, boolean sandboxEnabled) {
      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(token, "token");
      Intrinsics.checkNotNullParameter(onPaymentResult, "onPaymentResult");
      super();
      this.context = context;
      this.token = token;
      this.onPaymentResult = onPaymentResult;
      this.sandboxEnabled = sandboxEnabled;
      SharedPreferences var10001 = this.context.getSharedPreferences("TransactionDetails", 0);
      Intrinsics.checkNotNullExpressionValue(var10001, "getSharedPreferences(...)");
      this.sharedPreferences = var10001;
      Editor var5 = this.sharedPreferences.edit();
      Intrinsics.checkNotNullExpressionValue(var5, "edit(...)");
      this.editor = var5;
      this.environment = "";
      if (this.sandboxEnabled) {
         this.editor.putString("environment", "sandbox-");
         this.environment = "sandbox-";
      } else {
         this.editor.putString("environment", "");
         this.environment = "";
      }

      this.editor.apply();
   }

   // $FF: synthetic method
   public BoxPayCheckout(Context var1, String var2, Function1 var3, boolean var4, int var5, DefaultConstructorMarker var6) {
      if ((var5 & 8) != 0) {
         var4 = false;
      }

      this(var1, var2, var3, var4);
   }

   @NotNull
   public final Function1<PaymentResultObject, Unit> getOnPaymentResult() {
      return this.onPaymentResult;
   }

   public final void display() {
      if (this.context instanceof Activity) {
         Log.d("Checked", "inside context if condition");
         Context var10000 = this.context;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type androidx.appcompat.app.AppCompatActivity");
         AppCompatActivity activity = (AppCompatActivity)var10000;
         Intrinsics.checkNotNullExpressionValue(activity.getSupportFragmentManager(), "getSupportFragmentManager(...)");
         this.openBottomSheet();
      }

      Log.d("Checking Time issue", "Called display");
      Log.d("environment variable", String.valueOf(this.sharedPreferences.getString("environment", "null")));
      this.putTransactionDetailsInSharedPreferences();
      Log.d("Checked", "Executed minView Checkout");
      Log.d("Checking Time issue", "Before fetching shopper details");
   }

   private final void openBottomSheet() {
      this.initializingCallBackFunctions();
      if (this.context instanceof Activity) {
         Log.d("Checked", "inside context if condition");
         Context var10000 = this.context;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type androidx.appcompat.app.AppCompatActivity");
         AppCompatActivity activity = (AppCompatActivity)var10000;
         FragmentManager var4 = activity.getSupportFragmentManager();
         Intrinsics.checkNotNullExpressionValue(var4, "getSupportFragmentManager(...)");
         FragmentManager fragmentManager = var4;
         MainBottomSheet bottomSheet = new MainBottomSheet();
         bottomSheet.show(fragmentManager, "MainBottomSheet");
      }

   }

   public final void initializingCallBackFunctions() {
      Log.d("result for callback", "checkingPurpose");
      CallBackFunctions callBackFunctions = new CallBackFunctions(this.onPaymentResult);
      .SingletonClass.Companion.getInstance().setCallBackFunctions(callBackFunctions);
   }

   private final void putTransactionDetailsInSharedPreferences() {
      this.editor.putString("token", this.token);
      Log.d("token added to sharedPreferences", this.token);
      this.editor.apply();
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Checkout", jsonStr);
   }
}
