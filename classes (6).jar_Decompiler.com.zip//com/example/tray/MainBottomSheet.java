package com.example.tray;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentViewModelLazyKt;
import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.Transformation;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.example.tray.R.drawable;
import com.example.tray.R.font;
import com.example.tray.ViewModels.CallBackFunctions;
import com.example.tray.ViewModels.OverlayViewModel;
import com.example.tray.ViewModels.SingletonClassForLoadingState;
import com.example.tray.ViewModels.callBackFunctionForLoadingState;
import com.example.tray.adapters.OrderSummaryItemsAdapter;
import com.example.tray.databinding.FragmentMainBottomSheetBinding;
import com.example.tray.paymentResult.PaymentResultObject;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CancellationException;
import jp.wasabeef.glide.transformations.BlurTransformation;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.jvm.internal.Ref.BooleanRef;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.Job.DefaultImpls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000Ú\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010%\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010!\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\b\u0000\u0018\u0000 \u0098\u00012\u00020\u0001:\u0002\u0098\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010?\u001a\u00020@2\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\u0010\u0010C\u001a\u00020@2\u0006\u0010D\u001a\u00020EH\u0016J\b\u0010F\u001a\u00020@H\u0002J\u0012\u0010G\u001a\u0004\u0018\u00010\u00052\u0006\u0010H\u001a\u00020\u0005H\u0002J\b\u0010I\u001a\u00020\u0005H\u0002J\b\u0010J\u001a\u00020@H\u0016J\u0010\u0010K\u001a\u00020@2\u0006\u0010D\u001a\u00020EH\u0016J\u0006\u0010L\u001a\u00020@J\u0010\u0010M\u001a\u00020@2\u0006\u0010N\u001a\u00020OH\u0002J\u0018\u0010P\u001a\u00020@2\u0006\u0010Q\u001a\u00020R2\u0006\u0010S\u001a\u00020\u0005H\u0002J\u0010\u0010T\u001a\u00020@2\u0006\u0010U\u001a\u00020\u0005H\u0002J\b\u0010V\u001a\u00020@H\u0002J\"\u0010W\u001a\u00020@2\u0006\u0010X\u001a\u00020\"2\u0006\u0010Y\u001a\u00020\"2\b\u0010Z\u001a\u0004\u0018\u00010\u001dH\u0016J\u0010\u0010[\u001a\u00020@2\u0006\u0010\\\u001a\u00020\u0005H\u0002J\b\u0010]\u001a\u00020@H\u0002J\u000e\u0010^\u001a\u00020\u00052\u0006\u0010_\u001a\u00020\u0005J\u0010\u0010`\u001a\u00020@2\u0006\u0010\\\u001a\u00020\u0005H\u0002J\u0010\u0010a\u001a\u00020@2\u0006\u0010S\u001a\u00020\u0005H\u0002J&\u0010b\u001a\u0004\u0018\u00010\n2\u0006\u0010c\u001a\u00020d2\b\u0010e\u001a\u0004\u0018\u00010f2\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\b\u0010g\u001a\u00020@H\u0002J\b\u0010h\u001a\u00020@H\u0002J\b\u0010i\u001a\u00020@H\u0002J\b\u0010j\u001a\u00020@H\u0002J\b\u0010k\u001a\u00020@H\u0002J\u0010\u0010l\u001a\u00020@2\u0006\u0010Q\u001a\u00020RH\u0002J\u0010\u0010m\u001a\u00020@2\u0006\u0010n\u001a\u00020\u0005H\u0002J\u0018\u0010o\u001a\u00020@2\u0006\u0010p\u001a\u00020\u00052\u0006\u0010Q\u001a\u00020RH\u0002J\b\u0010q\u001a\u00020@H\u0002J\u0006\u0010r\u001a\u00020@J\b\u0010s\u001a\u00020@H\u0002J\b\u0010t\u001a\u00020@H\u0002J\u0010\u0010u\u001a\u00020v2\u0006\u0010w\u001a\u00020\"H\u0002J\u0010\u0010x\u001a\u00020y2\u0006\u0010w\u001a\u00020\"H\u0002J\u0010\u0010z\u001a\u00020{2\u0006\u0010w\u001a\u00020\"H\u0002J\u0010\u0010|\u001a\u00020@2\u0006\u0010\\\u001a\u00020\u0005H\u0002J\b\u0010}\u001a\u00020@H\u0002J\b\u0010~\u001a\u00020@H\u0002J\b\u0010\u007f\u001a\u00020@H\u0002J\u0007\u0010\u0080\u0001\u001a\u00020@J\u0007\u0010\u0081\u0001\u001a\u00020@J\t\u0010\u0082\u0001\u001a\u00020@H\u0002J\t\u0010\u0083\u0001\u001a\u00020@H\u0002J\t\u0010\u0084\u0001\u001a\u00020@H\u0002J\t\u0010\u0085\u0001\u001a\u00020@H\u0002J\u0015\u0010\u0086\u0001\u001a\u00020\u00052\f\u0010/\u001a\b\u0012\u0004\u0012\u00020\u00050-J\u001c\u0010\u0087\u0001\u001a\u00020@2\u0007\u0010\u0088\u0001\u001a\u00020\n2\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\u0014\u0010\u0089\u0001\u001a\u00030\u008a\u00012\b\u0010A\u001a\u0004\u0018\u00010BH\u0016J\t\u0010\u008b\u0001\u001a\u00020@H\u0002J\t\u0010\u008c\u0001\u001a\u00020@H\u0002J\t\u0010\u008d\u0001\u001a\u00020@H\u0002J\t\u0010\u008e\u0001\u001a\u00020@H\u0002J\u0013\u0010\u008f\u0001\u001a\u00020@2\b\u0010\u0090\u0001\u001a\u00030\u0091\u0001H\u0002J\u0013\u0010\u0092\u0001\u001a\u00020@2\b\u0010\u0090\u0001\u001a\u00030\u0091\u0001H\u0002J\t\u0010\u0093\u0001\u001a\u00020@H\u0002J\t\u0010\u0094\u0001\u001a\u00020@H\u0002J\u0012\u0010\u0095\u0001\u001a\u00020@2\u0007\u0010\u0096\u0001\u001a\u00020\u0005H\u0002J\t\u0010\u0097\u0001\u001a\u00020@H\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082.¢\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u001b\u0010\u0010\u001a\u00020\u00118BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0012\u0010\u0013R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00050-X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010.\u001a\b\u0012\u0004\u0012\u00020\u00050-X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010/\u001a\b\u0012\u0004\u0012\u00020\u00050-X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u001c\u00101\u001a\u0004\u0018\u000102X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b3\u00104\"\u0004\b5\u00106R\u000e\u00107\u001a\u000208X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020:X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020<X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010=\u001a\u0004\u0018\u00010>X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0099\u0001"},
   d2 = {"Lcom/example/tray/MainBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "transactionId", "", "isSuccessful", "", "qrCodeShown", "overlayViewMainBottomSheet", "Landroid/view/View;", "binding", "Lcom/example/tray/databinding/FragmentMainBottomSheetBinding;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "overlayViewModel", "Lcom/example/tray/ViewModels/OverlayViewModel;", "getOverlayViewModel", "()Lcom/example/tray/ViewModels/OverlayViewModel;", "overlayViewModel$delegate", "Lkotlin/Lazy;", "overlayViewCurrentBottomSheet", "token", "successScreenFullReferencePath", "UPIAppsAndPackageMap", "", "activityResultLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "job", "Lkotlinx/coroutines/Job;", "isTablet", "i", "", "transactionAmount", "upiAvailable", "upiCollectMethod", "upiIntentMethod", "upiQRMethod", "cardsMethod", "walletMethods", "netBankingMethods", "overLayPresent", "items", "", "imagesUrls", "prices", "Base_Session_API_URL", "queue", "Lcom/android/volley/RequestQueue;", "getQueue", "()Lcom/android/volley/RequestQueue;", "setQueue", "(Lcom/android/volley/RequestQueue;)V", "countdownTimer", "Landroid/os/CountDownTimer;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "callBackFunctions", "Lcom/example/tray/ViewModels/CallBackFunctions;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCancel", "dialog", "Landroid/content/DialogInterface;", "fetchShopperDetailsAndUpdateInSharedPreferences", "convertIPv6ToIPv4", "ipv6Address", "getLocalIpAddress", "onStart", "onDismiss", "dismissTheSheetAfterSuccess", "getAllInstalledApps", "packageManager", "Landroid/content/pm/PackageManager;", "fetchUPIIntentURL", "context", "Landroid/content/Context;", "appName", "showLoadingState", "source", "removeLoadingState", "onActivityResult", "requestCode", "resultCode", "data", "launchUPIIntent", "url", "startFunctionCalls", "urlToBase64", "base64String", "fetchStatusAndReason", "getUrlForUPIIntent", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "showQRCode", "fetchQRCode", "hideQRCode", "startTimer", "blurImageView", "postRequestForQRCode", "updateTransactionIDInSharedPreferences", "transactionIdArg", "openActivity", "activityPath", "fetchAllPaymentMethods", "enabledButtonsForAllPaymentMethods", "putTransactionDetailsInSharedPreferences", "populatePopularUPIApps", "getPopularImageViewByNum", "Landroid/widget/ImageView;", "num", "getPopularConstraintLayoutByNum", "Landroid/widget/LinearLayout;", "getPopularTextViewByNum", "Landroid/widget/TextView;", "openDefaultUPIIntentBottomSheetFromAndroid", "getUrlForDefaultUPIIntent", "addOverlayToActivity", "removeOverlayFromActivity", "showOverlayInCurrentBottomSheet", "removeOverlayFromCurrentBottomSheet", "showPriceBreakUp", "hidePriceBreakUp", "showUPIOptions", "hideUPIOptions", "extractSum", "onViewCreated", "view", "onCreateDialog", "Landroid/app/Dialog;", "openAddUPIIDBottomSheet", "openAddCardBottomSheet", "openNetBankingBottomSheet", "openWalletBottomSheet", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "logJsonObjectUPIIntent", "getAndSetOrderDetails", "fetchTransactionDetailsFromSharedPreferences", "updateTransactionAmountInSharedPreferences", "transactionAmountArgs", "callFunctionInActivity", "Companion", "Tray_release"}
)
@SourceDebugExtension({"SMAP\nMainBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MainBottomSheet.kt\ncom/example/tray/MainBottomSheet\n+ 2 FragmentViewModelLazy.kt\nandroidx/fragment/app/FragmentViewModelLazyKt\n*L\n1#1,1846:1\n77#2,6:1847\n*S KotlinDebug\n*F\n+ 1 MainBottomSheet.kt\ncom/example/tray/MainBottomSheet\n*L\n93#1:1847,6\n*E\n"})
public final class MainBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final MainBottomSheet.Companion Companion = new MainBottomSheet.Companion((DefaultConstructorMarker)null);
   @Nullable
   private String transactionId;
   private boolean isSuccessful;
   private boolean qrCodeShown;
   @Nullable
   private View overlayViewMainBottomSheet;
   private FragmentMainBottomSheetBinding binding;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @NotNull
   private final Lazy overlayViewModel$delegate;
   @Nullable
   private View overlayViewCurrentBottomSheet;
   @Nullable
   private String token;
   @Nullable
   private String successScreenFullReferencePath;
   @NotNull
   private Map<String, String> UPIAppsAndPackageMap;
   private ActivityResultLauncher<Intent> activityResultLauncher;
   @Nullable
   private Job job;
   private boolean isTablet;
   private int i;
   @Nullable
   private String transactionAmount;
   private boolean upiAvailable;
   private boolean upiCollectMethod;
   private boolean upiIntentMethod;
   private boolean upiQRMethod;
   private boolean cardsMethod;
   private boolean walletMethods;
   private boolean netBankingMethods;
   private boolean overLayPresent;
   @NotNull
   private List<String> items;
   @NotNull
   private List<String> imagesUrls;
   @NotNull
   private List<String> prices;
   private String Base_Session_API_URL;
   @Nullable
   private RequestQueue queue;
   private CountDownTimer countdownTimer;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   @Nullable
   private CallBackFunctions callBackFunctions;

   public MainBottomSheet() {
      Fragment $this$activityViewModels_u24default$iv = (Fragment)this;
      Function0 factoryProducer$iv = null;
      int $i$f$activityViewModels = false;
      this.overlayViewModel$delegate = FragmentViewModelLazyKt.createViewModelLazy($this$activityViewModels_u24default$iv, Reflection.getOrCreateKotlinClass(OverlayViewModel.class), (Function0)(new MainBottomSheet$special$$inlined$activityViewModels$default$1($this$activityViewModels_u24default$iv)), (Function0)(new MainBottomSheet$special$$inlined$activityViewModels$default$2($this$activityViewModels_u24default$iv)));
      this.UPIAppsAndPackageMap = (Map)(new LinkedHashMap());
      this.i = 1;
      this.items = (List)(new ArrayList());
      this.imagesUrls = (List)(new ArrayList());
      this.prices = (List)(new ArrayList());
   }

   private final OverlayViewModel getOverlayViewModel() {
      Lazy var1 = this.overlayViewModel$delegate;
      return (OverlayViewModel)var1.getValue();
   }

   @Nullable
   public final RequestQueue getQueue() {
      return this.queue;
   }

   public final void setQueue(@Nullable RequestQueue var1) {
      this.queue = var1;
   }

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   public void onCancel(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onCancel(dialog);
      this.removeOverlayFromActivity();
      this.dismiss();
   }

   private final void fetchShopperDetailsAndUpdateInSharedPreferences() {
      SharedPreferences var10000 = this.sharedPreferences;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10000 = null;
      }

      String environmentFetched = var10000.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "MainBottomSheet");
      String url = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/" + this.token;
      RequestQueue var11 = Volley.newRequestQueue(this.getContext());
      Intrinsics.checkNotNullExpressionValue(var11, "newRequestQueue(...)");
      RequestQueue queue = var11;
      Log.d("fetchShopperDetailsAndUpdate", "Checkout");
      JsonObjectRequest var5 = new JsonObjectRequest(0, url, (JSONObject)null, MainBottomSheet::fetchShopperDetailsAndUpdateInSharedPreferences$lambda$0, MainBottomSheet::fetchShopperDetailsAndUpdateInSharedPreferences$lambda$1);
      int var7 = false;
      int timeoutMs = 1000000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var5.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      queue.add((Request)var5);
   }

   private final String convertIPv6ToIPv4(String ipv6Address) {
      try {
         InetAddress inet6Address = InetAddress.getByName(ipv6Address);
         if (inet6Address instanceof Inet6Address) {
            if (((Inet6Address)inet6Address).isLinkLocalAddress()) {
               return "127.0.0.1";
            }

            String var10001 = ((Inet6Address)inet6Address).getHostAddress();
            Intrinsics.checkNotNullExpressionValue(var10001, "getHostAddress(...)");
            String var4 = var10001;
            byte[] var6 = var4.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(var6, "getBytes(...)");
            InetAddress inetAddress = InetAddress.getByAddress((String)null, var6);
            return inetAddress.getHostAddress();
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      }

      return null;
   }

   private final String getLocalIpAddress() {
      try {
         Enumeration networkInterfaces = NetworkInterface.getNetworkInterfaces();
         Iterator var10000 = Collections.list(networkInterfaces).iterator();
         Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
         Iterator var2 = var10000;

         while(var2.hasNext()) {
            NetworkInterface networkInterface = (NetworkInterface)var2.next();
            ArrayList inetAddresses = Collections.list(networkInterface.getInetAddresses());
            var10000 = inetAddresses.iterator();
            Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
            Iterator var5 = var10000;

            while(var5.hasNext()) {
               InetAddress inetAddress = (InetAddress)var5.next();
               if (!inetAddress.isLoopbackAddress() && inetAddress != null) {
                  String var8 = inetAddress.getHostAddress();
                  Intrinsics.checkNotNullExpressionValue(var8, "getHostAddress(...)");
                  return var8;
               }
            }
         }
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      return "";
   }

   public void onStart() {
      super.onStart();
      this.showLoadingState("onStart");
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      this.queue = Volley.newRequestQueue(this.requireContext());
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in Main Bottom Sheet onStart", userAgentHeader);
      CoroutineScope coroutineScope = CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getMain());
      Job coroutine = BuildersKt.launch$default(coroutineScope, (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;

         public final Object invokeSuspend(Object $result) {
            Object var2 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               CoroutineContext var10000 = (CoroutineContext)Dispatchers.getIO();
               Function2 var10001 = (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
                  int label;

                  public final Object invokeSuspend(Object var1) {
                     IntrinsicsKt.getCOROUTINE_SUSPENDED();
                     switch(this.label) {
                     case 0:
                        ResultKt.throwOnFailure(var1);
                        MainBottomSheet.this.getAndSetOrderDetails();
                        MainBottomSheet.this.fetchAllPaymentMethods();
                        MainBottomSheet.this.fetchShopperDetailsAndUpdateInSharedPreferences();
                        return Unit.INSTANCE;
                     default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                     }
                  }

                  public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
                     return (Continuation)(new <anonymous constructor>($completion));
                  }

                  public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
                     return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
                  }
               });
               Continuation var10002 = (Continuation)this;
               this.label = 1;
               if (BuildersKt.withContext(var10000, var10001, var10002) == var2) {
                  return var2;
               }
               break;
            case 1:
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            return Unit.INSTANCE;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            return (Continuation)(new <anonymous constructor>($completion));
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
      coroutine.invokeOnCompletion(MainBottomSheet::onStart$lambda$3);
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      Log.d("Overlay", "Bottom sheet dismissed");
      this.getOverlayViewModel().setShowOverlay(false);
      CallBackFunctions callback = .SingletonClass.Companion.getInstance().getYourObject();
      if (callback == null) {
         Log.d("call back is null", "Failed");
      } else if (!this.isSuccessful) {
         callback.getOnPaymentResult().invoke(new PaymentResultObject("Failed"));
      }

      super.onDismiss(dialog);
   }

   public final void dismissTheSheetAfterSuccess() {
      this.isSuccessful = true;
      this.dismiss();
   }

   private final void getAllInstalledApps(PackageManager packageManager) {
      Log.d("getAllInstalledApps", "here");
      List var10000 = packageManager.getInstalledApplications(256);
      Intrinsics.checkNotNullExpressionValue(var10000, "getInstalledApplications(...)");
      List apps = var10000;
      Iterator var3 = apps.iterator();

      while(var3.hasNext()) {
         ApplicationInfo app = (ApplicationInfo)var3.next();
         String appName = packageManager.getApplicationLabel(app).toString();
         Log.d("all apps", "allApps " + appName);
         Intent upiIntent = new Intent("android.intent.action.VIEW");
         upiIntent.setData(Uri.parse("upi://pay"));
         upiIntent.setPackage(app.packageName);
         var10000 = packageManager.queryIntentActivities(upiIntent, 0);
         Intrinsics.checkNotNullExpressionValue(var10000, "queryIntentActivities(...)");
         List upiApps = var10000;
         int var8;
         if (Intrinsics.areEqual(appName, "PhonePe")) {
            var8 = this.i++;
            Log.d("UPI App", appName);
            Log.d("UPI App Package Name", app.packageName);
            this.UPIAppsAndPackageMap.put(appName, app.packageName);
         }

         if (!upiApps.isEmpty() || Intrinsics.areEqual(appName, "Paytm") || Intrinsics.areEqual(appName, "GPay") || Intrinsics.areEqual(appName, "PhonePe")) {
            var8 = this.i++;
            Log.d("UPI App", appName);
            Log.d("UPI App Package Name", app.packageName);
            this.UPIAppsAndPackageMap.put(appName, app.packageName);
         }

         if (packageManager.getLaunchIntentForPackage(app.packageName) != null && (app.flags & 128) == 0 && (app.flags & 1) != 0) {
         }
      }

      Log.d("Checking Time issue", "fetch upi apps");
   }

   private final void fetchUPIIntentURL(Context context, String appName) {
      Log.d(" upiIntent Details launch UPI Payment", appName);
      this.showLoadingState("fetchIntentURL");
      this.getUrlForUPIIntent(appName);
   }

   private final void showLoadingState(String source) {
      Log.d("Source of loading state", source);
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      LottieAnimationView var2 = var10000.boxpayLogoLottie;
      int var4 = false;
      var2.setAnimation("boxpayLogo.json");
      var2.setRepeatCount(-1);
      var2.playAnimation();
   }

   private final void removeLoadingState() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.boxpayLogoLottie.cancelAnimation();
   }

   public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
      super.onActivityResult(requestCode, resultCode, data);
      Log.d("upiIntent Status", "inside onActivityResult");
      Job var10000 = this.job;
      if (var10000 != null) {
         DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
      }

      if (requestCode == 121) {
         switch(resultCode) {
         case -1:
            Log.d("upiIntent Status", "Success");
            break;
         case 0:
            Log.d("upiIntent Status", "Fail");
         }
      }

   }

   private final void launchUPIIntent(String url) {
      Intent intent = new Intent("android.intent.action.VIEW");
      Log.d("upiIntent", url);
      Uri uri = Uri.parse(url);
      intent.setData(uri);

      try {
         this.startFunctionCalls();
         this.startActivityForResult(intent, 121);
         this.removeLoadingState();
      } catch (ActivityNotFoundException var5) {
         Log.d("upiIntent Details Activity Not found", var5.toString());
      }

   }

   private final void startFunctionCalls() {
      this.job = BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getIO()), (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;
         // $FF: synthetic field
         private Object L$0;

         public final Object invokeSuspend(Object $result) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            CoroutineScope $this$launch;
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               $this$launch = (CoroutineScope)this.L$0;
               break;
            case 1:
               $this$launch = (CoroutineScope)this.L$0;
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            Continuation var4;
            do {
               if (!CoroutineScopeKt.isActive($this$launch)) {
                  return Unit.INSTANCE;
               }

               MainBottomSheet var10000 = MainBottomSheet.this;
               StringBuilder var10001 = new StringBuilder();
               String var10002 = MainBottomSheet.this.Base_Session_API_URL;
               if (var10002 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
                  var10002 = null;
               }

               var10000.fetchStatusAndReason(var10001.append(var10002).append(MainBottomSheet.this.token).append("/status").toString());
               var4 = (Continuation)this;
               this.L$0 = $this$launch;
               this.label = 1;
            } while(DelayKt.delay(2000L, var4) != var3);

            return var3;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            Function2 var3 = new <anonymous constructor>($completion);
            var3.L$0 = value;
            return (Continuation)var3;
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   @NotNull
   public final String urlToBase64(@NotNull String base64String) {
      Intrinsics.checkNotNullParameter(base64String, "base64String");

      String var2;
      try {
         byte[] decodedBytes = Base64.decode(base64String, 0);
         Intrinsics.checkNotNull(decodedBytes);
         Charset var10000 = StandardCharsets.UTF_8;
         Intrinsics.checkNotNullExpressionValue(var10000, "UTF_8");
         Charset var5 = var10000;
         String decodedString = new String(decodedBytes, var5);
         var2 = URLDecoder.decode(decodedString, "UTF-8");
      } catch (Exception var6) {
         var6.printStackTrace();
         var2 = "";
      }

      return var2;
   }

   private final void fetchStatusAndReason(String url) {
      Log.d("fetching function called correctly", "Fine Main Bottom SHeet");
      JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, url, (JSONObject)null, MainBottomSheet::fetchStatusAndReason$lambda$5, MainBottomSheet::fetchStatusAndReason$lambda$6);
      RequestQueue var10000 = this.queue;
      if (var10000 != null) {
         var10000.add((Request)jsonObjectRequest);
      }

   }

   private final void getUrlForUPIIntent(String appName) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(this.getContext());
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var4 = new JSONObject();
      int var6 = false;
      JSONObject var7 = new JSONObject();
      int var9 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var7.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var7.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var7.put("acceptHeader", "application/json");
      var7.put("userAgentHeader", userAgentHeader);
      var7.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("ipAddress", var10002.getString("ipAddress", "null"));
      var7.put("colorDepth", 24);
      var7.put("javaEnabled", true);
      var7.put("timeZoneOffSet", 330);
      var4.put("browserData", var7);
      JSONObject var8 = new JSONObject();
      int var10 = false;
      var8.put("type", "upi/intent");
      JSONObject var23 = new JSONObject();
      int var14 = false;
      var23.put("upiApp", appName);
      var8.put("upiAppDetails", var23);
      var4.put("instrumentDetails", var8);
      StringBuilder var24 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var5 = var24.append(var10001).append(this.token).toString();
      Listener var17 = MainBottomSheet::getUrlForUPIIntent$lambda$11;
      ErrorListener var18 = MainBottomSheet::getUrlForUPIIntent$lambda$12;
      JsonObjectRequest var16 = new JsonObjectRequest(var4, var5, var17, var18) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(MainBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var19 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var16.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var16);
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      Log.d("Checking Time issue", "Main Bottom Sheet");
      this.binding = FragmentMainBottomSheetBinding.inflate(inflater, container, false);
      Object var10000 = this.requireActivity().getSystemService("input_method");
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
      InputMethodManager imm = (InputMethodManager)var10000;
      View var14 = this.getView();
      if (var14 != null) {
         View it = var14;
         int var8 = false;
         imm.hideSoftInputFromWindow(it.getWindowToken(), 0);
      }

      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      this.queue = Volley.newRequestQueue(this.requireContext());
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.isTablet = false;
         this.requireActivity().setRequestedOrientation(1);
      } else {
         this.isTablet = true;
      }

      callBackFunctionForLoadingState callback = SingletonClassForLoadingState.Companion.getInstance().getYourObject();
      if (callback == null) {
         Log.d("call back for loading is null", "Failed");
      } else {
         Log.d("call back for loading", "Success");
         callback.getOnBottomSheetOpened().invoke();
      }

      SharedPreferences var15 = this.sharedPreferences;
      if (var15 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var15 = null;
      }

      String environmentFetched = var15.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "MainBottomSheet");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchTransactionDetailsFromSharedPreferences();
      this.getOverlayViewModel().getShowOverlay().observe((LifecycleOwner)this, MainBottomSheet::onCreateView$lambda$15);
      this.getOverlayViewModel().setShowOverlay(true);
      this.hidePriceBreakUp();
      List var10002 = this.imagesUrls;
      List var10003 = this.items;
      List var10004 = this.prices;
      Context var10005 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10005, "requireContext(...)");
      OrderSummaryItemsAdapter orderSummaryAdapter = new OrderSummaryItemsAdapter(var10002, var10003, var10004, var10005);
      FragmentMainBottomSheetBinding var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.itemsInOrderRecyclerView.setLayoutManager((LayoutManager)(new LinearLayoutManager(this.requireContext())));
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.itemsInOrderRecyclerView.setAdapter((Adapter)orderSummaryAdapter);
      var15 = this.sharedPreferences;
      if (var15 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var15 = null;
      }

      String currencySymbol = var15.getString("currencySymbol", "");
      this.updateTransactionAmountInSharedPreferences(currencySymbol + this.transactionAmount);
      if (Intrinsics.areEqual(currencySymbol, "")) {
         currencySymbol = "₹";
      }

      this.showUPIOptions();
      BooleanRef priceBreakUpVisible = new BooleanRef();
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.orderSummaryConstraintLayout.setOnClickListener(MainBottomSheet::onCreateView$lambda$16);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.itemsInOrderRecyclerView.setOnClickListener(MainBottomSheet::onCreateView$lambda$17);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.totalValueRelativeLayout.setOnClickListener(MainBottomSheet::onCreateView$lambda$18);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.backButton.setOnClickListener(MainBottomSheet::onCreateView$lambda$19);
      BooleanRef upiOptionsShown = new BooleanRef();
      upiOptionsShown.element = true;
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.upiLinearLayout.setOnClickListener(MainBottomSheet::onCreateView$lambda$20);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.payUsingAnyUPIConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$21);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.addNewUPIIDConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$22);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.UPIQRConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$23);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.qrCodeOpenConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$24);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.cardConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$25);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.walletConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$26);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.netBankingConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$27);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.refreshButton.setOnClickListener(MainBottomSheet::onCreateView$lambda$28);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      var16.popularUPIAppsConstraint.setOnClickListener(MainBottomSheet::onCreateView$lambda$29);
      var16 = this.binding;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var16 = null;
      }

      return (View)var16.getRoot();
   }

   private final void showQRCode() {
      this.qrCodeShown = true;
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.qrCodeOpenConstraint.setVisibility(0);
      this.showLoadingState("showQRCode");
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.refreshButton.setVisibility(8);
      this.fetchQRCode();
   }

   private final void fetchQRCode() {
      Context var10001 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10001, "requireContext(...)");
      this.postRequestForQRCode(var10001);
   }

   private final void hideQRCode() {
      this.qrCodeShown = false;
      CountDownTimer var10000 = this.countdownTimer;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
         var10000 = null;
      }

      var10000.cancel();
      FragmentMainBottomSheetBinding var1 = this.binding;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var1 = null;
      }

      var1.qrCodeOpenConstraint.setVisibility(8);
   }

   private final void startTimer() {
      this.countdownTimer = (CountDownTimer)(new CountDownTimer() {
         public void onTick(long millisUntilFinished) {
            long minutes = millisUntilFinished / (long)1000 / (long)60;
            long seconds = millisUntilFinished / (long)1000 % (long)60;
            StringCompanionObject var10000 = StringCompanionObject.INSTANCE;
            String var8 = "%02d:%02d";
            Object[] var9 = new Object[]{minutes, seconds};
            String var10 = String.format(var8, Arrays.copyOf(var9, var9.length));
            Intrinsics.checkNotNullExpressionValue(var10, "format(...)");
            String timeString = var10;
            FragmentMainBottomSheetBinding var11 = MainBottomSheet.this.binding;
            if (var11 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var11 = null;
            }

            var11.qrCodeTimer.setText((CharSequence)(timeString + " min"));
         }

         public void onFinish() {
            FragmentMainBottomSheetBinding var10000 = MainBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.qrCodeTimer.setText((CharSequence)"00:00");
            var10000 = MainBottomSheet.this.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.refreshButton.setVisibility(0);
            MainBottomSheet.this.blurImageView();
         }
      });
      CountDownTimer var10000 = this.countdownTimer;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("countdownTimer");
         var10000 = null;
      }

      var10000.start();
   }

   private final void blurImageView() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      Drawable var2 = var10000.qrCodeImageView.getDrawable();
      Intrinsics.checkNotNull(var2, "null cannot be cast to non-null type android.graphics.drawable.BitmapDrawable");
      Bitmap bitmap = ((BitmapDrawable)var2).getBitmap();
      RequestBuilder var3 = Glide.with(this.requireContext()).asBitmap().load(bitmap).apply((BaseRequestOptions)RequestOptions.bitmapTransform((Transformation)(new BlurTransformation(25, 3))));
      FragmentMainBottomSheetBinding var10001 = this.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      var3.into(var10001.qrCodeImageView);
   }

   private final void postRequestForQRCode(Context context) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var4 = new JSONObject();
      int var6 = false;
      JSONObject var7 = new JSONObject();
      int var9 = false;
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var7.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var7.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var7.put("acceptHeader", "application/json");
      var7.put("userAgentHeader", userAgentHeader);
      var7.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var7.put("ipAddress", var10002.getString("ipAddress", "null"));
      var7.put("colorDepth", 24);
      var7.put("javaEnabled", true);
      var7.put("timeZoneOffSet", 330);
      var4.put("browserData", var7);
      JSONObject var8 = new JSONObject();
      int var19 = false;
      var8.put("type", "upi/qr");
      var4.put("instrumentDetails", var8);
      StringBuilder var21 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var5 = var21.append(var10001).append(this.token).toString();
      Listener var14 = MainBottomSheet::postRequestForQRCode$lambda$33;
      ErrorListener var15 = MainBottomSheet::postRequestForQRCode$lambda$34;
      JsonObjectRequest var13 = new JsonObjectRequest(var4, var5, var14, var15) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(MainBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var16 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var13.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var13);
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   private final void openActivity(String activityPath, Context context) {
      if (context instanceof AppCompatActivity) {
         try {
            Class activityClass = Class.forName(activityPath);
            Object var10000 = activityClass.getDeclaredConstructor().newInstance();
            Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type androidx.appcompat.app.AppCompatActivity");
            AppCompatActivity activityInstance = (AppCompatActivity)var10000;
            if (activityInstance instanceof AppCompatActivity) {
               ((AppCompatActivity)context).startActivity(new Intent(context, activityClass));
            }
         } catch (ClassNotFoundException var5) {
         }
      }

   }

   private final void fetchAllPaymentMethods() {
      StringBuilder var10000 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String url = var10000.append(var10001).append(this.token).toString();
      Log.d("Base URL", url);
      JsonObjectRequest jsonObjectAll = new JsonObjectRequest(0, url, (JSONObject)null, MainBottomSheet::fetchAllPaymentMethods$lambda$36, MainBottomSheet::fetchAllPaymentMethods$lambda$37);
      RequestQueue var3 = this.queue;
      if (var3 != null) {
         var3.add((Request)jsonObjectAll);
      }

   }

   public final void enabledButtonsForAllPaymentMethods() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.payUsingAnyUPIConstraint.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.addNewUPIIDConstraint.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.cardConstraint.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.walletConstraint.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.netBankingConstraint.setEnabled(true);
   }

   private final void putTransactionDetailsInSharedPreferences() {
      SharedPreferences sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      Editor editor = sharedPreferences.edit();
      editor.putString("token", this.token);
      Log.d("token added to sharedPreferences", String.valueOf(this.token));
      editor.putString("successScreenFullReferencePath", this.successScreenFullReferencePath);
      Log.d("success Screen added to sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
      editor.apply();
   }

   private final void populatePopularUPIApps() {
      int i = 1;
      ImageView imageView;
      TextView textView;
      if (this.UPIAppsAndPackageMap.containsKey("PhonePe")) {
         imageView = this.getPopularImageViewByNum(i);
         textView = this.getPopularTextViewByNum(i);
         imageView.setImageResource(drawable.phonepe_logo);
         textView.setText((CharSequence)"PhonePe");
         this.getPopularConstraintLayoutByNum(i).setOnClickListener(MainBottomSheet::populatePopularUPIApps$lambda$38);
         Log.d("i and app inside if statement", i + " and app = PhonePe");
         ++i;
      }

      if (this.UPIAppsAndPackageMap.containsKey("GPay")) {
         imageView = this.getPopularImageViewByNum(i);
         textView = this.getPopularTextViewByNum(i);
         imageView.setImageResource(drawable.google_pay_seeklogo);
         textView.setText((CharSequence)"GPay");
         this.getPopularConstraintLayoutByNum(i).setOnClickListener(MainBottomSheet::populatePopularUPIApps$lambda$39);
         Log.d("i and app inside if statement", i + " and app = GPay");
         ++i;
      }

      if (this.UPIAppsAndPackageMap.containsKey("Paytm")) {
         imageView = this.getPopularImageViewByNum(i);
         textView = this.getPopularTextViewByNum(i);
         imageView.setImageResource(drawable.paytm_upi_logo);
         textView.setText((CharSequence)"Paytm");
         this.getPopularConstraintLayoutByNum(i).setOnClickListener(MainBottomSheet::populatePopularUPIApps$lambda$40);
         Log.d("i and app inside if statement", i + " and app = Paytm");
         ++i;
      }

      if (i == 1) {
         FragmentMainBottomSheetBinding var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.popularUPIAppsConstraint.setVisibility(8);
      }

   }

   private final ImageView getPopularImageViewByNum(int num) {
      FragmentMainBottomSheetBinding var10000;
      ImageView var2;
      switch(num) {
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPIImageView1;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPIImageView1");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPIImageView2;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPIImageView2");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPIImageView3;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPIImageView3");
         break;
      case 4:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPIImageView4;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPIImageView4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number: " + num);
      }

      return var2;
   }

   private final LinearLayout getPopularConstraintLayoutByNum(int num) {
      FragmentMainBottomSheetBinding var10000;
      LinearLayout var2;
      switch(num) {
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.PopularUPILinearLayout1;
         Intrinsics.checkNotNullExpressionValue(var2, "PopularUPILinearLayout1");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.PopularUPILinearLayout2;
         Intrinsics.checkNotNullExpressionValue(var2, "PopularUPILinearLayout2");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.PopularUPILinearLayout3;
         Intrinsics.checkNotNullExpressionValue(var2, "PopularUPILinearLayout3");
         break;
      case 4:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.PopularUPILinearLayout4;
         Intrinsics.checkNotNullExpressionValue(var2, "PopularUPILinearLayout4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number: " + num);
      }

      return var2;
   }

   private final TextView getPopularTextViewByNum(int num) {
      FragmentMainBottomSheetBinding var10000;
      TextView var2;
      switch(num) {
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPITextView1;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPITextView1");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPITextView2;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPITextView2");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPITextView3;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPITextView3");
         break;
      case 4:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularUPITextView4;
         Intrinsics.checkNotNullExpressionValue(var2, "popularUPITextView4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number: " + num);
      }

      return var2;
   }

   private final void openDefaultUPIIntentBottomSheetFromAndroid(String url) {
      Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
      this.startFunctionCalls();
      this.startActivityForResult(intent, 121);
      this.removeLoadingState();
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.payUsingAnyUPIConstraint.setEnabled(true);
   }

   private final void getUrlForDefaultUPIIntent() {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(this.getContext());
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var3 = new JSONObject();
      int var5 = false;
      JSONObject var6 = new JSONObject();
      int var8 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var6.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var6.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var6.put("acceptHeader", "application/json");
      var6.put("userAgentHeader", userAgentHeader);
      var6.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var6.put("ipAddress", var10002.getString("ipAddress", "null"));
      var6.put("colorDepth", 24);
      var6.put("javaEnabled", true);
      var6.put("timeZoneOffSet", 330);
      var3.put("browserData", var6);
      JSONObject var7 = new JSONObject();
      int var9 = false;
      var7.put("type", "upi/intent");
      var3.put("instrumentDetails", var7);
      StringBuilder var20 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var4 = var20.append(var10001).append(this.token).toString();
      Listener var14 = MainBottomSheet::getUrlForDefaultUPIIntent$lambda$44;
      ErrorListener var15 = MainBottomSheet::getUrlForDefaultUPIIntent$lambda$45;
      JsonObjectRequest var13 = new JsonObjectRequest(var3, var4, var14, var15) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(MainBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var16 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var13.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var13);
   }

   private final void addOverlayToActivity() {
      this.overLayPresent = true;
      Log.d("Overlay", "overlay added......");
      this.overlayViewMainBottomSheet = new View(this.requireContext());
      View var10000 = this.overlayViewMainBottomSheet;
      if (var10000 != null) {
         var10000.setBackgroundColor(Color.parseColor("#80000000"));
      }

      Object var3 = this.requireContext().getSystemService("window");
      Intrinsics.checkNotNull(var3, "null cannot be cast to non-null type android.view.WindowManager");
      WindowManager windowManager = (WindowManager)var3;
      LayoutParams layoutParams = new LayoutParams(-1, -1, 1000, 8, -3);
      windowManager.addView(this.overlayViewMainBottomSheet, (android.view.ViewGroup.LayoutParams)layoutParams);
   }

   private final void removeOverlayFromActivity() {
      View var10000 = this.overlayViewMainBottomSheet;
      if (var10000 != null) {
         View it = var10000;
         int var2 = false;
         Object var4 = this.requireContext().getSystemService("window");
         Intrinsics.checkNotNull(var4, "null cannot be cast to non-null type android.view.WindowManager");
         WindowManager windowManager = (WindowManager)var4;
         windowManager.removeView(it);
      }

      this.overlayViewMainBottomSheet = null;
   }

   public final void showOverlayInCurrentBottomSheet() {
      this.overlayViewCurrentBottomSheet = new View(this.requireContext());
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         var10000.setBackgroundColor(Color.parseColor("#80000000"));
      }

      FragmentMainBottomSheetBinding var1 = this.binding;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var1 = null;
      }

      var1.getRoot().addView(this.overlayViewCurrentBottomSheet, -1, -1);
   }

   public final void removeOverlayFromCurrentBottomSheet() {
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         View it = var10000;
         int var2 = false;
         FragmentMainBottomSheetBinding var3 = this.binding;
         if (var3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var3 = null;
         }

         var3.getRoot().removeView(it);
      }

   }

   private final void showPriceBreakUp() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.itemsInOrderRecyclerView.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView18.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.ItemsPrice.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.priceBreakUpDetailsLinearLayout.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.arrowIcon.animate().rotation(180.0F).setDuration(250L).withEndAction(MainBottomSheet::showPriceBreakUp$lambda$49).start();
   }

   private final void hidePriceBreakUp() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.itemsInOrderRecyclerView.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView18.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.ItemsPrice.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.priceBreakUpDetailsLinearLayout.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.arrowIcon.animate().rotation(0.0F).setDuration(250L).withEndAction(MainBottomSheet::hidePriceBreakUp$lambda$50).start();
   }

   private final void showUPIOptions() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.upiConstraint.setBackgroundColor(Color.parseColor("#E0F1FF"));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.upiOptionsLinearLayout.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView20.setTypeface(ResourcesCompat.getFont(this.requireContext(), font.poppins_semibold));
      Log.d("made visible", String.valueOf(this.i));
      if (this.i > 1) {
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.popularUPIAppsConstraint.setVisibility(0);
      }

   }

   private final void hideUPIOptions() {
      FragmentMainBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.upiConstraint.setBackgroundColor(Color.parseColor("#FFFFFF"));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.upiOptionsLinearLayout.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView20.setTypeface(ResourcesCompat.getFont(this.requireContext(), font.poppins));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularUPIAppsConstraint.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.imageView12.animate().rotation(0.0F).setDuration(500L).withEndAction(MainBottomSheet::hideUPIOptions$lambda$51).start();
   }

   @NotNull
   public final String extractSum(@NotNull List<String> prices) {
      Intrinsics.checkNotNullParameter(prices, "prices");
      int finalSum = 0;

      String numericPart;
      for(Iterator var3 = prices.iterator(); var3.hasNext(); finalSum += Integer.parseInt(numericPart)) {
         String price = (String)var3.next();
         CharSequence var6 = (CharSequence)price;
         Regex var7 = new Regex("[^0-9]");
         String var8 = "";
         numericPart = var7.replace(var6, var8);
         if (((CharSequence)numericPart).length() == 0) {
            return "0";
         }
      }

      StringCompanionObject var10000 = StringCompanionObject.INSTANCE;
      numericPart = "₹%.2f";
      Object[] var11 = new Object[]{(double)finalSum / 100.0D};
      String var10 = String.format(numericPart, Arrays.copyOf(var11, var11.length));
      Intrinsics.checkNotNullExpressionValue(var10, "format(...)");
      String formattedSum = var10;
      return formattedSum;
   }

   public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(view, "view");
      super.onViewCreated(view, savedInstanceState);
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(MainBottomSheet::onCreateDialog$lambda$52);
      return dialog;
   }

   private final void openAddUPIIDBottomSheet() {
      AddUPIID bottomSheetFragment = new AddUPIID();
      bottomSheetFragment.show(this.getParentFragmentManager(), "AddUPIBottomSheet");
   }

   private final void openAddCardBottomSheet() {
      AddCardBottomSheet bottomSheetFragment = new AddCardBottomSheet();
      bottomSheetFragment.show(this.getParentFragmentManager(), "AddCardBottomSheet");
   }

   private final void openNetBankingBottomSheet() {
      NetBankingBottomSheet bottomSheetFragment = new NetBankingBottomSheet();
      bottomSheetFragment.show(this.getParentFragmentManager(), "NetBankingBottomSheet");
   }

   private final void openWalletBottomSheet() {
      WalletBottomSheet bottomSheetFragment = new WalletBottomSheet();
      bottomSheetFragment.show(this.getParentFragmentManager(), "WalletBottomSheet");
   }

   private final void logJsonObject(JSONObject jsonObject) {
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Main Bottom Sheet", jsonStr);
   }

   private final void logJsonObjectUPIIntent(JSONObject jsonObject) {
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("upiIntent call for url", jsonStr);
   }

   private final void getAndSetOrderDetails() {
      StringBuilder var10000 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String url = var10000.append(var10001).append(this.token).toString();
      RequestQueue var4 = Volley.newRequestQueue(this.requireContext());
      Intrinsics.checkNotNullExpressionValue(var4, "newRequestQueue(...)");
      RequestQueue queue = var4;
      JsonObjectRequest jsonObjectAll = new JsonObjectRequest(0, url, (JSONObject)null, MainBottomSheet::getAndSetOrderDetails$lambda$53, MainBottomSheet::getAndSetOrderDetails$lambda$54);
      queue.add((Request)jsonObjectAll);
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences sharedPreferences = this.requireContext().getSharedPreferences("TransactionDetails", 0);
      this.token = sharedPreferences.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      this.successScreenFullReferencePath = sharedPreferences.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   private final void updateTransactionAmountInSharedPreferences(String transactionAmountArgs) {
      SharedPreferences sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      Editor editor = sharedPreferences.edit();
      editor.putString("transactionAmount", transactionAmountArgs);
      editor.apply();
   }

   private final void callFunctionInActivity() {
      FragmentActivity activity = this.getActivity();
      if (activity instanceof Check) {
         ((Check)activity).removeLoadingAndEnabledProceedButton();
      }

   }

   private static final void fetchShopperDetailsAndUpdateInSharedPreferences$lambda$0(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObject(response);
         Log.d("Checking Time issue", "after fetching shopper details");
         JSONObject paymentDetailsObject = response.getJSONObject("paymentDetails");
         JSONObject moneyObject = paymentDetailsObject.getJSONObject("money");
         Editor var10000 = this$0.editor;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editor");
            var10000 = null;
         }

         var10000.putString("amount", moneyObject.getString("amount"));
         var10000 = this$0.editor;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("editor");
            var10000 = null;
         }

         var10000.apply();
         this$0.removeLoadingState();
      } catch (Exception var4) {
         Toast.makeText(this$0.requireContext(), (CharSequence)"Invalid token/selected environment.\nPlease press back button and try again", 1).show();
         Log.d("Error Occurred", var4.toString());
         var4.printStackTrace();
      }

   }

   private static final void fetchShopperDetailsAndUpdateInSharedPreferences$lambda$1(MainBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Toast.makeText(this$0.requireContext(), (CharSequence)"Invalid token/selected environment.\nPlease press back button and try again", 1).show();
      this$0.dismiss();
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", " fetching Checkout error response: " + errorResponse);
      }

   }

   private static final Unit onStart$lambda$3(MainBottomSheet this$0, Throwable it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      PackageManager packageManager = this$0.requireContext().getPackageManager();
      Intrinsics.checkNotNull(packageManager);
      this$0.getAllInstalledApps(packageManager);
      this$0.populatePopularUPIApps();
      return Unit.INSTANCE;
   }

   private static final void fetchStatusAndReason$lambda$5(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         String status = response.getString("status");
         String statusReason = response.getString("statusReason");
         Log.d("MainBottomSheet Status", status);
         Log.d("Status Reason", statusReason);
         Intrinsics.checkNotNull(status);
         Job var10000;
         FragmentMainBottomSheetBinding var7;
         if (!StringsKt.contains((CharSequence)status, (CharSequence)"Approved", true)) {
            Intrinsics.checkNotNull(statusReason);
            if (!StringsKt.contains((CharSequence)statusReason, (CharSequence)"Received by BoxPay for processing", true) && !StringsKt.contains((CharSequence)statusReason, (CharSequence)"Approved by PSP", true) && !StringsKt.contains((CharSequence)status, (CharSequence)"PAID", true)) {
               if (!StringsKt.contains((CharSequence)status, (CharSequence)"PENDING", true)) {
                  if (StringsKt.contains((CharSequence)status, (CharSequence)"EXPIRED", true)) {
                     Log.d("Inside Expired", "Expired");
                     var10000 = this$0.job;
                     if (var10000 != null) {
                        DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                     }

                     var7 = this$0.binding;
                     if (var7 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("binding");
                        var7 = null;
                     }

                     var7.payUsingAnyUPIConstraint.setEnabled(true);
                  } else if (!StringsKt.contains((CharSequence)status, (CharSequence)"PROCESSING", true)) {
                     if (StringsKt.contains((CharSequence)status, (CharSequence)"FAILED", true)) {
                        var10000 = this$0.job;
                        if (var10000 != null) {
                           DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                        }

                        var7 = this$0.binding;
                        if (var7 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var7 = null;
                        }

                        var7.payUsingAnyUPIConstraint.setEnabled(true);
                        .FailureScreenSharedViewModel callback = FailureScreenCallBackSingletonClass.Companion.getInstance().getYourObject();
                        if (callback == null) {
                           Log.d("callback is null", "PaymentFailedWithDetailsSheet");
                        } else {
                           callback.getOpenFailureScreen().invoke();
                        }

                        return;
                     } else {
                        var10000 = this$0.job;
                        if (var10000 != null) {
                           DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
                        }

                        var7 = this$0.binding;
                        if (var7 == null) {
                           Intrinsics.throwUninitializedPropertyAccessException("binding");
                           var7 = null;
                        }

                        var7.payUsingAnyUPIConstraint.setEnabled(true);
                        Log.d("inside else condition", "else");
                        return;
                     }
                  }

                  return;
               }

               return;
            }
         }

         var10000 = this$0.job;
         if (var10000 != null) {
            DefaultImpls.cancel$default(var10000, (CancellationException)null, 1, (Object)null);
         }

         var7 = this$0.binding;
         if (var7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var7 = null;
         }

         var7.payUsingAnyUPIConstraint.setEnabled(true);
         CallBackFunctions callback = .SingletonClass.Companion.getInstance().getYourObject();
         if (callback == null) {
            Log.d("call back is null", "Success");
         } else {
            callback.getOnPaymentResult().invoke(new PaymentResultObject("Success"));
            this$0.dismiss();
         }
      } catch (JSONException var5) {
         var5.printStackTrace();
      }

   }

   private static final void fetchStatusAndReason$lambda$6(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
      }

   }

   private static final void getUrlForUPIIntent$lambda$11(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObjectUPIIntent(response);
         JSONArray actionsArray = response.getJSONArray("actions");
         String urlForIntent = actionsArray.getJSONObject(0).getString("url");
         String status = response.getJSONObject("status").getString("status");
         Log.d("status for intent", status.toString());
         Intrinsics.checkNotNull(status);
         if (StringsKt.contains((CharSequence)status, (CharSequence)"rejected", true)) {
            this$0.removeLoadingState();
            (new PaymentFailureScreen()).show(this$0.getParentFragmentManager(), "FailureScreenFromUPIIntent");
         }

         Intrinsics.checkNotNull(urlForIntent);
         String urlInBase64 = this$0.urlToBase64(urlForIntent);
         Log.d("upiIntent Details inside upi Intent call", urlInBase64);
         this$0.launchUPIIntent(urlInBase64);
      } catch (JSONException var6) {
         Log.d("upiIntent Details status check error", var6.toString());
         this$0.removeLoadingState();
         (new PaymentFailureScreen()).show(this$0.getParentFragmentManager(), "FailureScreenFromUPIIntent");
      }

   }

   private static final void getUrlForUPIIntent$lambda$12(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
      }

   }

   private static final void onCreateView$lambda$15(MainBottomSheet this$0, Boolean showOverlay) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (showOverlay) {
         this$0.addOverlayToActivity();
      } else {
         this$0.removeOverlayFromActivity();
      }

   }

   private static final void onCreateView$lambda$16(BooleanRef $priceBreakUpVisible, MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter($priceBreakUpVisible, "$priceBreakUpVisible");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!$priceBreakUpVisible.element) {
         this$0.showPriceBreakUp();
         $priceBreakUpVisible.element = true;
      } else {
         this$0.hidePriceBreakUp();
         $priceBreakUpVisible.element = false;
      }

   }

   private static final void onCreateView$lambda$17(View it) {
   }

   private static final void onCreateView$lambda$18(View it) {
   }

   private static final void onCreateView$lambda$19(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.removeOverlayFromActivity();
      this$0.dismiss();
   }

   private static final void onCreateView$lambda$20(BooleanRef $upiOptionsShown, MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter($upiOptionsShown, "$upiOptionsShown");
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (!$upiOptionsShown.element) {
         $upiOptionsShown.element = true;
         this$0.showUPIOptions();
      } else {
         $upiOptionsShown.element = false;
         this$0.hideUPIOptions();
      }

   }

   private static final void onCreateView$lambda$21(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentMainBottomSheetBinding var10000 = this$0.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.payUsingAnyUPIConstraint.setEnabled(false);
      this$0.showLoadingState("payUsingAnyUPIConstraint");
      this$0.getUrlForDefaultUPIIntent();
   }

   private static final void onCreateView$lambda$22(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentMainBottomSheetBinding var10000 = this$0.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.addNewUPIIDConstraint.setEnabled(false);
      this$0.openAddUPIIDBottomSheet();
   }

   private static final void onCreateView$lambda$23(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (this$0.qrCodeShown) {
         this$0.qrCodeShown = false;
         FragmentMainBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.UPIQRConstraint.setEnabled(true);
         this$0.hideQRCode();
      } else {
         this$0.qrCodeShown = true;
         this$0.showQRCode();
      }

   }

   private static final void onCreateView$lambda$24(View it) {
   }

   private static final void onCreateView$lambda$25(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (this$0.qrCodeShown) {
         FragmentMainBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.cardConstraint.setEnabled(false);
      }

      this$0.openAddCardBottomSheet();
   }

   private static final void onCreateView$lambda$26(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentMainBottomSheetBinding var10000 = this$0.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.walletConstraint.setEnabled(false);
      this$0.openWalletBottomSheet();
   }

   private static final void onCreateView$lambda$27(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      FragmentMainBottomSheetBinding var10000 = this$0.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.netBankingConstraint.setEnabled(false);
      this$0.openNetBankingBottomSheet();
   }

   private static final void onCreateView$lambda$28(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.showQRCode();
   }

   private static final void onCreateView$lambda$29(View it) {
   }

   private static final void postRequestForQRCode$lambda$33(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.transactionId = response.getString("transactionId").toString();
      String var10001 = this$0.transactionId;
      Intrinsics.checkNotNull(var10001);
      this$0.updateTransactionIDInSharedPreferences(var10001);
      JSONObject valuesObject = response.getJSONArray("actions").getJSONObject(0);
      String urlBase64 = valuesObject.getString("content");
      Log.d("urlBase64", urlBase64);
      byte[] var10000 = Base64.decode(urlBase64, 0);
      Intrinsics.checkNotNullExpressionValue(var10000, "decode(...)");
      byte[] decodedBytes = var10000;
      Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
      FragmentMainBottomSheetBinding var7 = this$0.binding;
      if (var7 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var7 = null;
      }

      ImageView var8 = var7.qrCodeImageView;
      Intrinsics.checkNotNullExpressionValue(var8, "qrCodeImageView");
      ImageView imageView = var8;
      imageView.setImageBitmap(bitmap);
      this$0.startTimer();
      this$0.removeLoadingState();
   }

   private static final void postRequestForQRCode$lambda$34(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
      }

   }

   private static final void fetchAllPaymentMethods$lambda$36(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         JSONArray paymentMethodsArray = response.getJSONObject("configs").getJSONArray("paymentMethods");
         JSONObject paymentDetailsObject = response.getJSONObject("paymentDetails");

         JSONArray additionalDetails;
         int i;
         FragmentMainBottomSheetBinding var10000;
         try {
            additionalDetails = paymentDetailsObject.getJSONObject("order").getJSONArray("items");
            int i = 0;

            for(i = additionalDetails.length(); i < i; ++i) {
               String imageURL = additionalDetails.getJSONObject(i).getString("imageUrl");
               Log.d("imageURL", imageURL);
               List var16 = this$0.imagesUrls;
               Intrinsics.checkNotNull(imageURL);
               var16.add(imageURL);
            }
         } catch (Exception var12) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView3.setVisibility(8);
         }

         additionalDetails = response.getJSONObject("configs").getJSONArray("additionalFieldSets");
         Log.d("additionalDetails", additionalDetails.toString());
         boolean orderSummaryEnable = false;
         i = 0;

         int var15;
         for(var15 = additionalDetails.length(); i < var15; ++i) {
            if (Intrinsics.areEqual(additionalDetails.get(i), "ORDER_ITEM_DETAILS")) {
               orderSummaryEnable = true;
            }
         }

         Log.d("orderSummaryEnable", String.valueOf(orderSummaryEnable));
         if (!orderSummaryEnable) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView3.setVisibility(8);
         }

         i = 0;

         for(var15 = paymentMethodsArray.length(); i < var15; ++i) {
            JSONObject paymentMethod = paymentMethodsArray.getJSONObject(i);
            String paymentMethodName = paymentMethod.getString("type");
            Log.d("paymentMethodName", paymentMethodName);
            if (Intrinsics.areEqual(paymentMethodName, "Upi")) {
               String brand = paymentMethod.getString("brand");
               if (Intrinsics.areEqual(brand, "UpiCollect")) {
                  this$0.upiCollectMethod = true;
                  this$0.upiAvailable = true;
               }

               if (Intrinsics.areEqual(brand, "UpiIntent")) {
                  this$0.upiIntentMethod = true;
                  this$0.upiAvailable = true;
               }

               if (Intrinsics.areEqual(brand, "UpiQr")) {
                  String userAgentHeader = WebSettings.getDefaultUserAgent(this$0.requireContext());
                  Log.d("user Agent for device in Main Bottom Sheet", userAgentHeader);
                  Intrinsics.checkNotNull(userAgentHeader);
                  if (!StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
                     this$0.upiQRMethod = true;
                  }

                  this$0.upiAvailable = true;
               }
            }

            if (Intrinsics.areEqual(paymentMethodName, "Card")) {
               this$0.cardsMethod = true;
            }

            if (Intrinsics.areEqual(paymentMethodName, "Wallet")) {
               this$0.walletMethods = true;
            }

            if (Intrinsics.areEqual(paymentMethodName, "NetBanking")) {
               this$0.netBankingMethods = true;
            }
         }

         Log.d("paymentMethods : ", "" + this$0.upiAvailable + this$0.cardsMethod);
         if (this$0.upiAvailable) {
            Log.d("upi  available", "here");
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView4.setVisibility(0);
            if (this$0.upiIntentMethod) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.payUsingAnyUPIConstraint.setVisibility(0);
            }

            if (this$0.upiCollectMethod) {
               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.addNewUPIIDConstraint.setVisibility(0);
            }

            if (this$0.upiQRMethod) {
               if (!this$0.upiIntentMethod && !this$0.upiCollectMethod && !this$0.cardsMethod && !this$0.walletMethods && !this$0.netBankingMethods) {
                  this$0.showQRCode();
               }

               var10000 = this$0.binding;
               if (var10000 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var10000 = null;
               }

               var10000.UPIQRConstraint.setVisibility(0);
            }
         } else {
            Log.d("upi Not available", "here");
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView4.setVisibility(8);
         }

         if (this$0.cardsMethod) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView5.setVisibility(0);
         } else {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView5.setVisibility(8);
         }

         if (this$0.walletMethods) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView6.setVisibility(0);
         } else {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView6.setVisibility(8);
         }

         if (this$0.netBankingMethods) {
            var10000 = this$0.binding;
            if (var10000 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var10000 = null;
            }

            var10000.cardView7.setVisibility(0);
         }

         Log.d("Checking Time issue", "fetch all payments methods");
      } catch (Exception var13) {
         Log.d("Error Occurred", var13.toString());
         var13.printStackTrace();
      }

   }

   private static final void fetchAllPaymentMethods$lambda$37(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var2 = var10000;
         String errorResponse = new String(var2, Charsets.UTF_8);
         Log.e("Error", " fetching MainBottomSheet error response: " + errorResponse);
      }

   }

   private static final void populatePopularUPIApps$lambda$38(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.getOverlayViewModel().setShowOverlay(false);
      Context var10001 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10001, "requireContext(...)");
      this$0.fetchUPIIntentURL(var10001, "PhonePe");
   }

   private static final void populatePopularUPIApps$lambda$39(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.getOverlayViewModel().setShowOverlay(false);
      Context var10001 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10001, "requireContext(...)");
      this$0.fetchUPIIntentURL(var10001, "GPay");
   }

   private static final void populatePopularUPIApps$lambda$40(MainBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.getOverlayViewModel().setShowOverlay(false);
      Context var10001 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10001, "requireContext(...)");
      this$0.fetchUPIIntentURL(var10001, "PayTm");
   }

   private static final void getUrlForDefaultUPIIntent$lambda$44(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         Intrinsics.checkNotNull(response);
         this$0.logJsonObjectUPIIntent(response);
         JSONArray actionsArray = response.getJSONArray("actions");
         String urlForIntent = actionsArray.getJSONObject(0).getString("url");
         String status = response.getJSONObject("status").getString("status");
         Log.d("status for intent", status.toString());
         Intrinsics.checkNotNull(status);
         if (StringsKt.contains((CharSequence)status, (CharSequence)"rejected", true)) {
            this$0.removeLoadingState();
            (new PaymentFailureScreen()).show(this$0.getParentFragmentManager(), "FailureScreenFromUPIIntent");
         }

         Intrinsics.checkNotNull(urlForIntent);
         String urlInBase64 = this$0.urlToBase64(urlForIntent);
         Log.d("upiIntent Details inside upi Intent call", urlInBase64);
         this$0.openDefaultUPIIntentBottomSheetFromAndroid(urlInBase64);
      } catch (JSONException var6) {
         Log.d("upiIntent Details status check error", var6.toString());
         this$0.removeLoadingState();
         (new PaymentFailureScreen()).show(this$0.getParentFragmentManager(), "FailureScreenFromDefaultUPIIntent");
      }

   }

   private static final void getUrlForDefaultUPIIntent$lambda$45(VolleyError error) {
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
      }

   }

   private static final void showPriceBreakUp$lambda$49() {
   }

   private static final void hidePriceBreakUp$lambda$50() {
   }

   private static final void hideUPIOptions$lambda$51() {
   }

   private static final void onCreateDialog$lambda$52(final MainBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      int screenHeight = this$0.requireContext().getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.7D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      if (this$0.bottomSheetBehavior == null) {
         Log.d("MainBottomSheet  bottomSheet is null", "Main Bottom Sheet");
      }

      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      ((BottomSheetDialog)dialog).setCancelable(false);
      if (((BottomSheetDialog)dialog).getWindow() == null) {
         Log.d("window will not be called here", "Main Bottom Sheet");
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismiss();
                  CallBackFunctions callback = .SingletonClass.Companion.getInstance().getYourObject();
                  if (callback == null) {
                     Log.d("call back is null", "Success");
                  } else {
                     callback.getOnPaymentResult().invoke(new PaymentResultObject("Failed"));
                  }
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final void getAndSetOrderDetails$lambda$53(MainBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         JSONObject paymentDetailsObject = response.getJSONObject("paymentDetails");
         String totalAmount = paymentDetailsObject.getJSONObject("money").getString("amount");
         JSONObject orderObject = paymentDetailsObject.getJSONObject("order");
         String originalAmount = orderObject.getString("originalAmount");
         String shippingCharges = orderObject.getString("shippingAmount");
         String taxes = orderObject.getString("taxAmount");
         SharedPreferences var10000 = this$0.sharedPreferences;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
            var10000 = null;
         }

         String currencySymbol = var10000.getString("currencySymbol", "");
         if (Intrinsics.areEqual(currencySymbol, "")) {
            currencySymbol = "₹";
         }

         this$0.transactionAmount = totalAmount;
         JSONArray itemsArray = orderObject.getJSONArray("items");
         int totalQuantity = 0;

         try {
            int i = 0;

            for(int var12 = itemsArray.length(); i < var12; ++i) {
               Log.d("Quantity", String.valueOf(totalQuantity));
               JSONObject itemObject = itemsArray.getJSONObject(i);
               List var21 = this$0.items;
               String var10001 = itemObject.getString("itemName");
               Intrinsics.checkNotNullExpressionValue(var10001, "getString(...)");
               var21.add(var10001);
               var21 = this$0.prices;
               var10001 = itemObject.getString("amountWithoutTaxLocale");
               Intrinsics.checkNotNullExpressionValue(var10001, "getString(...)");
               var21.add(var10001);
               int quantity = itemObject.getInt("quantity");
               totalQuantity += quantity;
            }
         } catch (Exception var15) {
         }

         JSONObject merchantDetailsObject = response.getJSONObject("merchantDetails");
         JSONObject checkoutThemeObject = merchantDetailsObject.getJSONObject("checkoutTheme");
         SharedPreferences sharedPreferences = this$0.requireContext().getSharedPreferences("TransactionDetails", 0);
         Editor editor = sharedPreferences.edit();
         editor.putString("headerColor", checkoutThemeObject.getString("headerColor"));
         Log.d("merchantDetails headerColor", checkoutThemeObject.getString("headerColor"));
         editor.putString("primaryButtonColor", checkoutThemeObject.getString("primaryButtonColor"));
         Log.d("merchantDetails buttonColor", checkoutThemeObject.getString("primaryButtonColor"));
         editor.putString("buttonTextColor", checkoutThemeObject.getString("buttonTextColor"));
         editor.apply();
         Log.d("merchantDetails headerColor", String.valueOf(sharedPreferences.getString("headerColor", "null")));
         Log.d("merchantDetails buttonTextColor", String.valueOf(sharedPreferences.getString("buttonTextColor", "null")));
         Log.d("merchantDetails buttonColor", String.valueOf(sharedPreferences.getString("primaryButtonColor", "null")));
         Log.d("order details subtotal", originalAmount);
         Log.d("order details taxes", taxes.toString());
         Log.d("order details shipping charges", shippingCharges.toString());
         Log.d("order details subtotal", originalAmount.toString());
         this$0.transactionAmount = totalAmount.toString();
         FragmentMainBottomSheetBinding var22 = this$0.binding;
         if (var22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var22 = null;
         }

         var22.unopenedTotalValue.setText((CharSequence)(currencySymbol + totalAmount));
         if (totalQuantity == 1) {
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.numberOfItems.setText((CharSequence)(totalQuantity + " item"));
         } else {
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.numberOfItems.setText((CharSequence)(totalQuantity + " items"));
         }

         var22 = this$0.binding;
         if (var22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var22 = null;
         }

         var22.ItemsPrice.setText((CharSequence)(currencySymbol + totalAmount));
         if (!Intrinsics.areEqual(originalAmount, totalAmount)) {
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.subtotalTextView.setText((CharSequence)(currencySymbol + originalAmount));
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.subTotalRelativeLayout.setVisibility(0);
         }

         if (!Intrinsics.areEqual(taxes, "null")) {
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.taxTextView.setText((CharSequence)(currencySymbol + taxes));
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.taxesRelativeLayout.setVisibility(0);
         }

         if (!Intrinsics.areEqual(shippingCharges, "null")) {
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.shippingChargesTextView.setText((CharSequence)(currencySymbol + shippingCharges));
            var22 = this$0.binding;
            if (var22 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var22 = null;
            }

            var22.shippingChargesRelativeLayout.setVisibility(0);
         }

         Log.d("Checking Time issue", "get and set order details");
      } catch (Exception var16) {
         Toast.makeText(this$0.requireContext(), (CharSequence)"Invalid token/selected environment.\nPlease press back button and try again", 1).show();
         Log.d("Error Occurred in MainBottomSheet", var16.toString());
         var16.printStackTrace();
      }

   }

   private static final void getAndSetOrderDetails$lambda$54(MainBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Toast.makeText(this$0.requireContext(), (CharSequence)"Invalid token/selected environment.\nPlease press back button and try again", 1).show();
      this$0.dismiss();
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", " fetching wallets error response: " + errorResponse);
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/MainBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
