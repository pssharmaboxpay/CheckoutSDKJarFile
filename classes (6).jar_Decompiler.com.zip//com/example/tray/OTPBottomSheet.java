package com.example.tray;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Telephony.Sms;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.example.tray.databinding.FragmentOTPBottomSheetBinding;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import java.io.Closeable;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000p\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0000\u0018\u0000 *2\u00020\u0001:\u0002)*B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\u0010\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0012\u0010\u0015\u001a\u00020\u00162\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J&\u0010\u0017\u001a\u0004\u0018\u00010\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001c2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u001d\u001a\u00020\u000fH\u0002J+\u0010\u001e\u001a\u00020\u000f2\u0006\u0010\u001f\u001a\u00020\n2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\r0!2\u0006\u0010\"\u001a\u00020#H\u0016¢\u0006\u0002\u0010$J\b\u0010'\u001a\u00020\u000fH\u0016J\b\u0010(\u001a\u00020\u000fH\u0016R\u0016\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082D¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010%\u001a\u00060&R\u00020\u0000X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006+"},
   d2 = {"Lcom/example/tray/OTPBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "binding", "Lcom/example/tray/databinding/FragmentOTPBottomSheetBinding;", "SMS_CONSENT_REQUEST", "", "smsList", "Ljava/util/ArrayList;", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onDismiss", "dialog", "Landroid/content/DialogInterface;", "onCreateDialog", "Landroid/app/Dialog;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "readSms", "onRequestPermissionsResult", "requestCode", "permissions", "", "grantResults", "", "(I[Ljava/lang/String;[I)V", "smsReceiver", "Lcom/example/tray/OTPBottomSheet$SmsReceiver;", "onResume", "onPause", "SmsReceiver", "Companion", "Tray_release"}
)
public final class OTPBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final OTPBottomSheet.Companion Companion = new OTPBottomSheet.Companion((DefaultConstructorMarker)null);
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   private FragmentOTPBottomSheetBinding binding;
   private final int SMS_CONSENT_REQUEST = 101;
   @NotNull
   private final ArrayList<String> smsList = new ArrayList();
   @NotNull
   private final OTPBottomSheet.SmsReceiver smsReceiver = new OTPBottomSheet.SmsReceiver();

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onDismiss(dialog);
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(OTPBottomSheet::onCreateDialog$lambda$0);
      return dialog;
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentOTPBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      this.readSms();
      FragmentOTPBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      return (View)var10000.getRoot();
   }

   private final void readSms() {
      Log.d("Message Received", "readSms Function");
      ContentResolver var10000 = this.requireActivity().getContentResolver();
      Intrinsics.checkNotNullExpressionValue(var10000, "getContentResolver(...)");
      ContentResolver contentResolver = var10000;
      Cursor cursor = contentResolver.query(Sms.CONTENT_URI, (String[])null, (String)null, (String[])null, "date DESC LIMIT 1");
      if (cursor != null) {
         Closeable var3 = (Closeable)cursor;
         Throwable var4 = null;

         try {
            Cursor it = (Cursor)var3;
            int var6 = false;
            if (it.moveToFirst()) {
               String address = it.getString(it.getColumnIndexOrThrow("address"));
               String body = it.getString(it.getColumnIndexOrThrow("body"));
               Log.d("Message Received", body);
               FragmentOTPBottomSheetBinding var14 = this.binding;
               if (var14 == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("binding");
                  var14 = null;
               }

               var14.sampleTextView.setText((CharSequence)body);
               this.smsList.add("Sender: " + address + "\nMessage: " + body);
            }

            Unit var13 = Unit.INSTANCE;
         } catch (Throwable var11) {
            var4 = var11;
            throw var11;
         } finally {
            CloseableKt.closeFinally(var3, var4);
         }
      }

   }

   public void onRequestPermissionsResult(int requestCode, @NotNull String[] permissions, @NotNull int[] grantResults) {
      Intrinsics.checkNotNullParameter(permissions, "permissions");
      Intrinsics.checkNotNullParameter(grantResults, "grantResults");
      super.onRequestPermissionsResult(requestCode, permissions, grantResults);
      if (requestCode == 101 && grantResults.length != 0 && grantResults[0] == 0) {
         this.readSms();
      }

   }

   public void onResume() {
      super.onResume();
      IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
      this.requireActivity().registerReceiver((BroadcastReceiver)this.smsReceiver, intentFilter);
   }

   public void onPause() {
      super.onPause();
      this.requireActivity().unregisterReceiver((BroadcastReceiver)this.smsReceiver);
   }

   private static final void onCreateDialog$lambda$0(final OTPBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      int screenHeight = this$0.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.7D;
      int var10000 = (int)((double)screenHeight * percentageOfScreenHeight);
      BottomSheetBehavior var8 = this$0.bottomSheetBehavior;
      if (var8 != null) {
         var8.setState(3);
      }

      var8 = this$0.bottomSheetBehavior;
      if (var8 != null) {
         var8.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismiss();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/OTPBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016¨\u0006\n"},
      d2 = {"Lcom/example/tray/OTPBottomSheet$SmsReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "(Lcom/example/tray/OTPBottomSheet;)V", "onReceive", "", "context", "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "Tray_release"}
   )
   private final class SmsReceiver extends BroadcastReceiver {
      public SmsReceiver() {
      }

      public void onReceive(@NotNull Context context, @NotNull Intent intent) {
         Intrinsics.checkNotNullParameter(context, "context");
         Intrinsics.checkNotNullParameter(intent, "intent");
         if (Intrinsics.areEqual("android.provider.Telephony.SMS_RECEIVED", intent.getAction())) {
            Log.d("Message Received", "onReceiver");
            OTPBottomSheet.this.readSms();
         }

      }
   }
}
