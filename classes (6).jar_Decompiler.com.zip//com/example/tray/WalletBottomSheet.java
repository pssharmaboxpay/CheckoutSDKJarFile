package com.example.tray;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.SearchView.OnQueryTextListener;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;
import coil.Coil;
import coil.ImageLoader;
import coil.decode.Decoder;
import coil.decode.SvgDecoder;
import coil.fetch.SourceResult;
import coil.request.ImageRequest;
import coil.request.Options;
import coil.request.ImageRequest.Builder;
import coil.transform.CircleCropTransformation;
import coil.transform.Transformation;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.R.color;
import com.example.tray.R.drawable;
import com.example.tray.adapters.WalletAdapter;
import com.example.tray.databinding.FragmentWalletBottomSheetBinding;
import com.example.tray.dataclasses.WalletDataClass;
import com.google.android.material.R.id;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.bottomsheet.BottomSheetBehavior.BottomSheetCallback;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.skydoves.balloon.Balloon;
import com.skydoves.balloon.BalloonAnimation;
import com.skydoves.balloon.BalloonCenterAlign;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¾\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0000\u0018\u0000 n2\u00020\u0001:\u0001nB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010,\u001a\u00020-2\b\u0010.\u001a\u0004\u0018\u00010/H\u0016J\u0012\u00100\u001a\u0002012\b\u0010.\u001a\u0004\u0018\u00010/H\u0016J\b\u00102\u001a\u00020-H\u0002J\u0010\u00103\u001a\u0002042\u0006\u00105\u001a\u00020\u0016H\u0002J\b\u00106\u001a\u00020-H\u0002J\u0018\u00107\u001a\u00020-2\u0006\u00108\u001a\u0002042\u0006\u00109\u001a\u00020\u0011H\u0002J\b\u0010:\u001a\u00020-H\u0002J\b\u0010;\u001a\u00020-H\u0002J\u0010\u0010<\u001a\u00020=2\u0006\u00105\u001a\u00020\u0016H\u0002J\u0010\u0010>\u001a\u00020?2\u0006\u00105\u001a\u00020\u0016H\u0002J\u0010\u0010@\u001a\u00020-2\u0006\u0010A\u001a\u00020\u0011H\u0002J\b\u0010H\u001a\u00020-H\u0002J&\u0010I\u001a\u0004\u0018\u00010\u000f2\u0006\u0010J\u001a\u00020K2\b\u0010L\u001a\u0004\u0018\u00010M2\b\u0010.\u001a\u0004\u0018\u00010/H\u0016J\b\u0010N\u001a\u00020-H\u0002J\u0018\u0010O\u001a\u00020&2\u0006\u0010P\u001a\u00020\u00162\u0006\u0010Q\u001a\u00020\u0016H\u0002J\u0006\u0010R\u001a\u00020-J\b\u0010S\u001a\u00020-H\u0002J\b\u0010T\u001a\u00020-H\u0002J\u0010\u0010U\u001a\u00020-2\u0006\u0010V\u001a\u00020WH\u0016J\u0010\u0010X\u001a\u00020-2\u0006\u0010V\u001a\u00020WH\u0016J\u0012\u0010Y\u001a\u00020-2\b\u0010Z\u001a\u0004\u0018\u00010\u0011H\u0002J\u0006\u0010[\u001a\u00020-J\u0006\u0010\\\u001a\u00020-J\u0006\u0010]\u001a\u00020-J\b\u0010^\u001a\u00020-H\u0002J\u0006\u0010_\u001a\u00020-J\u0018\u0010`\u001a\u00020-2\u0006\u0010a\u001a\u00020b2\u0006\u0010c\u001a\u00020\u0011H\u0002J\u000e\u0010d\u001a\u00020-2\u0006\u0010e\u001a\u00020fJ\b\u0010g\u001a\u00020-H\u0002J\b\u0010h\u001a\u00020-H\u0002J\u0006\u0010i\u001a\u00020-J\u0006\u0010j\u001a\u00020-J\b\u0010k\u001a\u00020-H\u0002J\u0010\u0010l\u001a\u0004\u0018\u00010\u00112\u0006\u0010m\u001a\u00020\u0011R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R \u0010\b\u001a\u0012\u0012\u0004\u0012\u00020\n0\u000bj\b\u0012\u0004\u0012\u00020\n`\tX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR \u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\n0\u000bj\b\u0012\u0004\u0012\u00020\n`\tX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\fR\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0017R\u0016\u0010\u0018\u001a\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R\u000e\u0010#\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0011X\u0082.¢\u0006\u0002\n\u0000R\u001b\u0010B\u001a\u00020C8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\bF\u0010G\u001a\u0004\bD\u0010E¨\u0006o"},
   d2 = {"Lcom/example/tray/WalletBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "binding", "Lcom/example/tray/databinding/FragmentWalletBottomSheetBinding;", "allWalletAdapter", "Lcom/example/tray/adapters/WalletAdapter;", "walletDetailsOriginal", "Lkotlin/collections/ArrayList;", "Lcom/example/tray/dataclasses/WalletDataClass;", "Ljava/util/ArrayList;", "Ljava/util/ArrayList;", "walletDetailsFiltered", "overlayViewCurrentBottomSheet", "Landroid/view/View;", "token", "", "proceedButtonIsEnabled", "Landroidx/lifecycle/MutableLiveData;", "", "checkedPosition", "", "Ljava/lang/Integer;", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/FrameLayout;", "bottomSheet", "successScreenFullReferencePath", "transactionId", "liveDataPopularWalletSelectedOrNot", "getLiveDataPopularWalletSelectedOrNot", "()Landroidx/lifecycle/MutableLiveData;", "setLiveDataPopularWalletSelectedOrNot", "(Landroidx/lifecycle/MutableLiveData;)V", "popularWalletsSelected", "popularWalletsSelectedIndex", "colorAnimation", "Landroid/animation/ValueAnimator;", "sharedPreferences", "Landroid/content/SharedPreferences;", "editor", "Landroid/content/SharedPreferences$Editor;", "Base_Session_API_URL", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "unselectItemsInPopularLayout", "getConstraintLayoutByNum", "Landroidx/constraintlayout/widget/ConstraintLayout;", "num", "fetchAndUpdateApiInPopularWallets", "showToolTipPopularWallets", "constraintLayout", "walletName", "removeLoadingScreenState", "dismissAndMakeButtonsOfMainBottomSheetEnabled", "fetchRelativeLayout", "Landroid/widget/RelativeLayout;", "getPopularTextViewByNum", "Landroid/widget/TextView;", "updateTransactionIDInSharedPreferences", "transactionIdArg", "requestQueue", "Lcom/android/volley/RequestQueue;", "getRequestQueue", "()Lcom/android/volley/RequestQueue;", "requestQueue$delegate", "Lkotlin/Lazy;", "hideKeyboard", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "startBackgroundAnimation", "createColorAnimation", "startColor", "endColor", "failurePaymentFunction", "fetchWalletDetails", "applyLoadingScreenState", "onCancel", "dialog", "Landroid/content/DialogInterface;", "onDismiss", "filterWallets", "query", "showAllWallets", "makeRecyclerViewJustBelowEditText", "removeRecyclerViewFromBelowEditText", "showOverlayInCurrentBottomSheet", "removeOverlayFromCurrentBottomSheet", "postRequest", "context", "Landroid/content/Context;", "instrumentTypeValue", "logJsonObject", "jsonObject", "Lorg/json/JSONObject;", "enableProceedButton", "disableProceedButton", "hideLoadingInButton", "showLoadingInButton", "fetchTransactionDetailsFromSharedPreferences", "extractMessageFromErrorResponse", "response", "Companion", "Tray_release"}
)
@SourceDebugExtension({"SMAP\nWalletBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WalletBottomSheet.kt\ncom/example/tray/WalletBottomSheet\n+ 2 Extensions.kt\ncoil/-SingletonExtensions\n+ 3 Balloon.kt\ncom/skydoves/balloon/BalloonKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,961:1\n54#2,3:962\n24#2:965\n59#2,6:966\n133#3:972\n13346#4,2:973\n*S KotlinDebug\n*F\n+ 1 WalletBottomSheet.kt\ncom/example/tray/WalletBottomSheet\n*L\n212#1:962,3\n212#1:965\n212#1:966,6\n260#1:972\n574#1:973,2\n*E\n"})
public final class WalletBottomSheet extends BottomSheetDialogFragment {
   @NotNull
   public static final WalletBottomSheet.Companion Companion = new WalletBottomSheet.Companion((DefaultConstructorMarker)null);
   private FragmentWalletBottomSheetBinding binding;
   private WalletAdapter allWalletAdapter;
   @NotNull
   private ArrayList<WalletDataClass> walletDetailsOriginal = new ArrayList();
   @NotNull
   private ArrayList<WalletDataClass> walletDetailsFiltered = new ArrayList();
   @Nullable
   private View overlayViewCurrentBottomSheet;
   @Nullable
   private String token;
   @NotNull
   private MutableLiveData<Boolean> proceedButtonIsEnabled = new MutableLiveData();
   @Nullable
   private Integer checkedPosition;
   @Nullable
   private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
   @Nullable
   private FrameLayout bottomSheet;
   @Nullable
   private String successScreenFullReferencePath;
   @Nullable
   private String transactionId;
   @NotNull
   private MutableLiveData<Boolean> liveDataPopularWalletSelectedOrNot;
   private boolean popularWalletsSelected;
   private int popularWalletsSelectedIndex;
   private ValueAnimator colorAnimation;
   private SharedPreferences sharedPreferences;
   private Editor editor;
   private String Base_Session_API_URL;
   @NotNull
   private final Lazy requestQueue$delegate;

   public WalletBottomSheet() {
      MutableLiveData var1 = new MutableLiveData();
      int var3 = false;
      var1.setValue(false);
      this.liveDataPopularWalletSelectedOrNot = var1;
      this.popularWalletsSelectedIndex = -1;
      this.requestQueue$delegate = LazyKt.lazy(WalletBottomSheet::requestQueue_delegate$lambda$9);
   }

   @NotNull
   public final MutableLiveData<Boolean> getLiveDataPopularWalletSelectedOrNot() {
      return this.liveDataPopularWalletSelectedOrNot;
   }

   public final void setLiveDataPopularWalletSelectedOrNot(@NotNull MutableLiveData<Boolean> var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.liveDataPopularWalletSelectedOrNot = var1;
   }

   public void onCreate(@Nullable Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog dialog = var10000;
      dialog.setOnShowListener(WalletBottomSheet::onCreateDialog$lambda$2);
      return dialog;
   }

   private final void unselectItemsInPopularLayout() {
      if (this.popularWalletsSelectedIndex != -1) {
         this.fetchRelativeLayout(this.popularWalletsSelectedIndex).setBackgroundResource(drawable.popular_item_unselected_bg);
      }

      this.popularWalletsSelected = false;
   }

   private final ConstraintLayout getConstraintLayoutByNum(int num) {
      FragmentWalletBottomSheetBinding var10000;
      ConstraintLayout var3;
      switch(num) {
      case 0:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularWalletConstraintLayout1;
         Intrinsics.checkNotNullExpressionValue(var3, "popularWalletConstraintLayout1");
         break;
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularWalletConstraintLayout2;
         Intrinsics.checkNotNullExpressionValue(var3, "popularWalletConstraintLayout2");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularWalletConstraintLayout3;
         Intrinsics.checkNotNullExpressionValue(var3, "popularWalletConstraintLayout3");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularWalletConstraintLayout4;
         Intrinsics.checkNotNullExpressionValue(var3, "popularWalletConstraintLayout4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number Relative layout");
      }

      ConstraintLayout constraintLayout = var3;
      return constraintLayout;
   }

   private final void fetchAndUpdateApiInPopularWallets() {
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      FragmentWalletBottomSheetBinding var1 = var10000;
      FragmentWalletBottomSheetBinding $this$fetchAndUpdateApiInPopularWallets_u24lambda_u247 = var1;
      int var3 = false;

      for(int index = 0; index < 4; ++index) {
         ConstraintLayout constraintLayout = this.getConstraintLayoutByNum(index);
         if (index < this.walletDetailsOriginal.size()) {
            Object var21 = this.walletDetailsOriginal.get(index);
            Intrinsics.checkNotNullExpressionValue(var21, "get(...)");
            WalletDataClass walletDetail = (WalletDataClass)var21;
            RelativeLayout relativeLayout = this.fetchRelativeLayout(index);
            ImageView var22;
            switch(index) {
            case 0:
               var22 = $this$fetchAndUpdateApiInPopularWallets_u24lambda_u247.popularWalletImageView1;
               break;
            case 1:
               var22 = $this$fetchAndUpdateApiInPopularWallets_u24lambda_u247.popularWalletImageView2;
               break;
            case 2:
               var22 = $this$fetchAndUpdateApiInPopularWallets_u24lambda_u247.popularWalletImageView3;
               break;
            case 3:
               var22 = $this$fetchAndUpdateApiInPopularWallets_u24lambda_u247.popularWalletImageView4;
               break;
            default:
               var22 = null;
            }

            ImageView imageView = var22;
            int var23 = (int)((float)50 * this.getResources().getDisplayMetrics().density);
            if (imageView != null) {
               Object data$iv = walletDetail.getWalletImage();
               Context $this$imageLoader$iv$iv = imageView.getContext();
               int $i$f$getImageLoader = false;
               ImageLoader imageLoader$iv = Coil.imageLoader($this$imageLoader$iv$iv);
               int $i$f$load = false;
               Builder var20 = (new Builder(imageView.getContext())).data(data$iv).target(imageView);
               int var17 = false;
               var20.decoderFactory(WalletBottomSheet::fetchAndUpdateApiInPopularWallets$lambda$7$lambda$4$lambda$3);
               Transformation[] var18 = new Transformation[]{new CircleCropTransformation()};
               var20.transformations(var18);
               var20.size(80, 80);
               ImageRequest request$iv = var20.build();
               imageLoader$iv.enqueue(request$iv);
            }

            this.getPopularTextViewByNum(index + 1).setText((CharSequence)((WalletDataClass)this.walletDetailsOriginal.get(index)).getWalletName());
            constraintLayout.setOnClickListener(WalletBottomSheet::fetchAndUpdateApiInPopularWallets$lambda$7$lambda$5);
            constraintLayout.setOnLongClickListener(WalletBottomSheet::fetchAndUpdateApiInPopularWallets$lambda$7$lambda$6);
         } else {
            constraintLayout.setVisibility(8);
         }
      }

   }

   private final void showToolTipPopularWallets(ConstraintLayout constraintLayout, String walletName) {
      Context var10000 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10000, "requireContext(...)");
      Context context$iv = var10000;
      int $i$f$createBalloon = false;
      com.skydoves.balloon.Balloon.Builder var6 = new com.skydoves.balloon.Balloon.Builder(context$iv);
      int var8 = false;
      var6.setArrowSize(10);
      var6.setWidthRatio(0.3F);
      var6.setHeight(65);
      var6.setArrowPosition(0.5F);
      var6.setCornerRadius(4.0F);
      var6.setAlpha(0.9F);
      var6.setText((CharSequence)walletName);
      var6.setTextColorResource(color.colorEnd);
      var6.setBackgroundColorResource(color.tooltip_bg);
      var6.setBalloonAnimation(BalloonAnimation.FADE);
      var6.setLifecycleOwner(var6.getLifecycleOwner());
      Balloon balloon = var6.build();
      Log.d("long click detected", "popular wallet");
      balloon.showAtCenter((View)constraintLayout, 0, 0, BalloonCenterAlign.TOP);
      balloon.dismissWithDelay(2000L);
   }

   private final void removeLoadingScreenState() {
      Log.d("removeLoadingScreenState", "called");
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.walletsRecyclerView.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularItemRelativeLayout1.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularItemRelativeLayout2.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularItemRelativeLayout3.setBackgroundResource(drawable.popular_item_unselected_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.popularItemRelativeLayout4.setBackgroundResource(drawable.popular_item_unselected_bg);
      ValueAnimator var1 = this.colorAnimation;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var1 = null;
      }

      var1.cancel();
   }

   private final void dismissAndMakeButtonsOfMainBottomSheetEnabled() {
      Fragment var2 = this.getParentFragmentManager().findFragmentByTag("MainBottomSheet");
      MainBottomSheet mainBottomSheetFragment = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if (mainBottomSheetFragment != null) {
         mainBottomSheetFragment.enabledButtonsForAllPaymentMethods();
      }

      this.dismiss();
   }

   private final RelativeLayout fetchRelativeLayout(int num) {
      FragmentWalletBottomSheetBinding var10000;
      RelativeLayout var3;
      switch(num) {
      case 0:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularItemRelativeLayout1;
         Intrinsics.checkNotNullExpressionValue(var3, "popularItemRelativeLayout1");
         break;
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularItemRelativeLayout2;
         Intrinsics.checkNotNullExpressionValue(var3, "popularItemRelativeLayout2");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularItemRelativeLayout3;
         Intrinsics.checkNotNullExpressionValue(var3, "popularItemRelativeLayout3");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var3 = var10000.popularItemRelativeLayout4;
         Intrinsics.checkNotNullExpressionValue(var3, "popularItemRelativeLayout4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number Relative layout");
      }

      RelativeLayout relativeLayout = var3;
      return relativeLayout;
   }

   private final TextView getPopularTextViewByNum(int num) {
      FragmentWalletBottomSheetBinding var10000;
      TextView var2;
      switch(num) {
      case 1:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularWalletsNameTextView1;
         Intrinsics.checkNotNullExpressionValue(var2, "popularWalletsNameTextView1");
         break;
      case 2:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularWalletsNameTextView2;
         Intrinsics.checkNotNullExpressionValue(var2, "popularWalletsNameTextView2");
         break;
      case 3:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularWalletsNameTextView3;
         Intrinsics.checkNotNullExpressionValue(var2, "popularWalletsNameTextView3");
         break;
      case 4:
         var10000 = this.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var2 = var10000.popularWalletsNameTextView4;
         Intrinsics.checkNotNullExpressionValue(var2, "popularWalletsNameTextView4");
         break;
      default:
         throw new IllegalArgumentException("Invalid number: " + num + "  TextView1234");
      }

      return var2;
   }

   private final void updateTransactionIDInSharedPreferences(String transactionIdArg) {
      Editor var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.putString("transactionId", transactionIdArg);
      var10000 = this.editor;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("editor");
         var10000 = null;
      }

      var10000.apply();
   }

   private final RequestQueue getRequestQueue() {
      Lazy var1 = this.requestQueue$delegate;
      Object var10000 = var1.getValue();
      Intrinsics.checkNotNullExpressionValue(var10000, "getValue(...)");
      return (RequestQueue)var10000;
   }

   private final void hideKeyboard() {
      Object var10000 = this.requireContext().getSystemService("input_method");
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
      InputMethodManager imm = (InputMethodManager)var10000;
      FragmentWalletBottomSheetBinding var10001 = this.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      imm.hideSoftInputFromWindow(var10001.searchView.getWindowToken(), 0);
   }

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = FragmentWalletBottomSheetBinding.inflate(this.getLayoutInflater(), container, false);
      .FailureScreenSharedViewModel failureScreenSharedViewModelCallback = new .FailureScreenSharedViewModel((Function0)(new Function0<Unit>(this) {
         public final void invoke() {
            ((WalletBottomSheet)this.receiver).failurePaymentFunction();
         }
      }));
      FailureScreenCallBackSingletonClass.Companion.getInstance().setCallBackFunctions(failureScreenSharedViewModelCallback);
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      Log.d("userAgentHeader in MainBottom Sheet onCreateView", userAgentHeader);
      Intrinsics.checkNotNull(userAgentHeader);
      if (StringsKt.contains((CharSequence)userAgentHeader, (CharSequence)"Mobile", true)) {
         this.requireActivity().setRequestedOrientation(1);
      }

      int screenHeight = this.requireContext().getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.45D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      LayoutParams var13 = var10000.nestedScrollView.getLayoutParams();
      Intrinsics.checkNotNull(var13, "null cannot be cast to non-null type androidx.constraintlayout.widget.ConstraintLayout.LayoutParams");
      androidx.constraintlayout.widget.ConstraintLayout.LayoutParams layoutParams = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams)var13;
      layoutParams.height = desiredHeight;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.nestedScrollView.setLayoutParams((LayoutParams)layoutParams);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var13 = var10000.loadingRelativeLayout.getLayoutParams();
      Intrinsics.checkNotNull(var13, "null cannot be cast to non-null type androidx.constraintlayout.widget.ConstraintLayout.LayoutParams");
      androidx.constraintlayout.widget.ConstraintLayout.LayoutParams layoutParamsLoading = (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams)var13;
      layoutParamsLoading.height = desiredHeight;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.loadingRelativeLayout.setLayoutParams((LayoutParams)layoutParamsLoading);
      this.sharedPreferences = this.requireActivity().getSharedPreferences("TransactionDetails", 0);
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      this.editor = var10001.edit();
      SharedPreferences var16 = this.sharedPreferences;
      if (var16 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var16 = null;
      }

      String environmentFetched = var16.getString("environment", "null");
      Log.d("environment is " + environmentFetched, "Add UPI ID");
      this.Base_Session_API_URL = "https://" + environmentFetched + "apis.boxpay.tech/v0/checkout/sessions/";
      this.fetchTransactionDetailsFromSharedPreferences();
      this.walletDetailsOriginal = new ArrayList();
      if (this.successScreenFullReferencePath != null) {
         String var14 = this.successScreenFullReferencePath;
         Intrinsics.checkNotNull(var14);
         Log.d("WalletBottomSheetReference", var14);
      }

      WalletAdapter var15 = new WalletAdapter;
      ArrayList var10003 = this.walletDetailsFiltered;
      FragmentWalletBottomSheetBinding var10004 = this.binding;
      if (var10004 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10004 = null;
      }

      RecyclerView var17 = var10004.walletsRecyclerView;
      Intrinsics.checkNotNullExpressionValue(var17, "walletsRecyclerView");
      MutableLiveData var10005 = this.liveDataPopularWalletSelectedOrNot;
      Context var10006 = this.requireContext();
      Intrinsics.checkNotNullExpressionValue(var10006, "requireContext(...)");
      FragmentWalletBottomSheetBinding var10007 = this.binding;
      if (var10007 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10007 = null;
      }

      SearchView var19 = var10007.searchView;
      Intrinsics.checkNotNullExpressionValue(var19, "searchView");
      var15.<init>(var10003, var17, var10005, var10006, var19);
      this.allWalletAdapter = var15;
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.walletsRecyclerView.setLayoutManager((LayoutManager)(new LinearLayoutManager(this.requireContext())));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RecyclerView var18 = var10000.walletsRecyclerView;
      var15 = this.allWalletAdapter;
      if (var15 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
         var15 = null;
      }

      var18.setAdapter((Adapter)var15);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.boxPayLogoLottieAnimation.playAnimation();
      this.startBackgroundAnimation();
      this.disableProceedButton();
      this.fetchWalletDetails();
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.searchView.setOnQueryTextListener((OnQueryTextListener)(new OnQueryTextListener() {
         public boolean onQueryTextSubmit(String query) {
            Intrinsics.checkNotNullParameter(query, "query");
            if (((CharSequence)query).length() == 0) {
               WalletBottomSheet.this.removeRecyclerViewFromBelowEditText();
            } else {
               WalletBottomSheet.this.makeRecyclerViewJustBelowEditText();
            }

            WalletBottomSheet.this.filterWallets(query);
            WalletBottomSheet.this.disableProceedButton();
            return true;
         }

         public boolean onQueryTextChange(String newText) {
            Intrinsics.checkNotNullParameter(newText, "newText");
            if (((CharSequence)newText).length() == 0) {
               WalletBottomSheet.this.removeRecyclerViewFromBelowEditText();
            } else {
               WalletBottomSheet.this.makeRecyclerViewJustBelowEditText();
            }

            WalletBottomSheet.this.filterWallets(newText);
            WalletBottomSheet.this.disableProceedButton();
            return true;
         }
      }));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.backButton.setOnClickListener(WalletBottomSheet::onCreateView$lambda$10);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.checkingTextView.setOnClickListener(WalletBottomSheet::onCreateView$lambda$11);
      this.proceedButtonIsEnabled.observe((LifecycleOwner)this, WalletBottomSheet::onCreateView$lambda$12);
      WalletAdapter var20 = this.allWalletAdapter;
      if (var20 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
         var20 = null;
      }

      var20.getCheckPositionLiveData().observe((LifecycleOwner)this, WalletBottomSheet::onCreateView$lambda$13);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setOnClickListener(WalletBottomSheet::onCreateView$lambda$14);
      this.liveDataPopularWalletSelectedOrNot.observe((LifecycleOwner)this, WalletBottomSheet::onCreateView$lambda$15);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView19.setOnClickListener(WalletBottomSheet::onCreateView$lambda$16);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.searchView.setOnCloseListener(WalletBottomSheet::onCreateView$lambda$17);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      return (View)var10000.getRoot();
   }

   private final void startBackgroundAnimation() {
      int colorStart = this.getResources().getColor(color.colorStart);
      int colorEnd = this.getResources().getColor(color.colorEnd);
      this.colorAnimation = this.createColorAnimation(colorStart, colorEnd);
      ValueAnimator var10000 = this.colorAnimation;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var10000 = null;
      }

      var10000.start();
   }

   private final ValueAnimator createColorAnimation(int startColor, int endColor) {
      int var4 = 0;

      RelativeLayout[] var5;
      for(var5 = new RelativeLayout[4]; var4 < 4; ++var4) {
         var5[var4] = null;
      }

      FragmentWalletBottomSheetBinding var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[0] = var10002.popularItemRelativeLayout1;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[1] = var10002.popularItemRelativeLayout2;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[2] = var10002.popularItemRelativeLayout3;
      var10002 = this.binding;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10002 = null;
      }

      var5[3] = var10002.popularItemRelativeLayout4;
      TypeEvaluator var10000 = (TypeEvaluator)(new ArgbEvaluator());
      Object[] var8 = new Object[]{startColor, endColor};
      ValueAnimator var9 = ValueAnimator.ofObject(var10000, var8);
      int var7 = false;
      var9.setDuration(500L);
      var9.setInterpolator((TimeInterpolator)(new AccelerateDecelerateInterpolator()));
      var9.setRepeatCount(-1);
      var9.setRepeatMode(2);
      var9.addUpdateListener(WalletBottomSheet::createColorAnimation$lambda$20$lambda$19);
      Intrinsics.checkNotNullExpressionValue(var9, "apply(...)");
      return var9;
   }

   public final void failurePaymentFunction() {
      Log.d("Failure Screen View Model", "failurePaymentFunction");
      BuildersKt.launch$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getMain()), (CoroutineContext)null, (CoroutineStart)null, (Function2)(new Function2<CoroutineScope, Continuation<? super Unit>, Object>((Continuation)null) {
         int label;

         public final Object invokeSuspend(Object $result) {
            Object var3 = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch(this.label) {
            case 0:
               ResultKt.throwOnFailure($result);
               Continuation var10001 = (Continuation)this;
               this.label = 1;
               if (DelayKt.delay(1000L, var10001) == var3) {
                  return var3;
               }
               break;
            case 1:
               ResultKt.throwOnFailure($result);
               break;
            default:
               throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }

            PaymentFailureScreen bottomSheet = new PaymentFailureScreen();
            bottomSheet.show(WalletBottomSheet.this.getParentFragmentManager(), "PaymentFailureScreen");
            return Unit.INSTANCE;
         }

         public final Continuation<Unit> create(Object value, Continuation<?> $completion) {
            return (Continuation)(new <anonymous constructor>($completion));
         }

         public final Object invoke(CoroutineScope p1, Continuation<? super Unit> p2) {
            return ((<undefinedtype>)this.create(p1, p2)).invokeSuspend(Unit.INSTANCE);
         }
      }), 3, (Object)null);
   }

   private final void fetchWalletDetails() {
      StringBuilder var10000 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String url = var10000.append(var10001).append(this.token).toString();
      RequestQueue var4 = Volley.newRequestQueue(this.requireContext());
      Intrinsics.checkNotNullExpressionValue(var4, "newRequestQueue(...)");
      RequestQueue queue = var4;
      JsonObjectRequest jsonObjectAll = new JsonObjectRequest(0, url, (JSONObject)null, WalletBottomSheet::fetchWalletDetails$lambda$21, WalletBottomSheet::fetchWalletDetails$lambda$22);
      queue.add((Request)jsonObjectAll);
   }

   private final void applyLoadingScreenState() {
   }

   public void onCancel(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      super.onCancel(dialog);
      this.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   public void onDismiss(@NotNull DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(dialog, "dialog");
      Fragment var2 = this.getParentFragment();
      MainBottomSheet var10000 = var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null;
      if ((var2 instanceof MainBottomSheet ? (MainBottomSheet)var2 : null) != null) {
         var10000.removeOverlayFromCurrentBottomSheet();
      }

      ValueAnimator var3 = this.colorAnimation;
      if (var3 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("colorAnimation");
         var3 = null;
      }

      var3.cancel();
      super.onDismiss(dialog);
   }

   private final void filterWallets(String query) {
      this.walletDetailsFiltered.clear();
      Iterator var10000 = this.walletDetailsOriginal.iterator();
      Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
      Iterator var2 = var10000;

      while(true) {
         while(var2.hasNext()) {
            Object var4 = var2.next();
            Intrinsics.checkNotNullExpressionValue(var4, "next(...)");
            WalletDataClass wallet = (WalletDataClass)var4;
            if (!StringsKt.isBlank((CharSequence)String.valueOf(query)) && !StringsKt.isBlank((CharSequence)String.valueOf(query))) {
               if (StringsKt.contains((CharSequence)wallet.getWalletName(), (CharSequence)String.valueOf(query), true)) {
                  this.walletDetailsFiltered.add(new WalletDataClass(wallet.getWalletName(), wallet.getWalletImage(), wallet.getWalletBrand(), wallet.getInstrumentTypeValue()));
               }
            } else {
               this.showAllWallets();
            }
         }

         FragmentWalletBottomSheetBinding var5;
         if (this.walletDetailsFiltered.size() == 0) {
            var5 = this.binding;
            if (var5 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var5 = null;
            }

            var5.noResultsFoundTextView.setVisibility(0);
         } else {
            var5 = this.binding;
            if (var5 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("binding");
               var5 = null;
            }

            var5.noResultsFoundTextView.setVisibility(8);
         }

         WalletAdapter var6 = this.allWalletAdapter;
         if (var6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
            var6 = null;
         }

         var6.deselectSelectedItem();
         var6 = this.allWalletAdapter;
         if (var6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
            var6 = null;
         }

         var6.notifyDataSetChanged();
         return;
      }
   }

   public final void showAllWallets() {
      this.walletDetailsFiltered.clear();
      Iterator var10000 = this.walletDetailsOriginal.iterator();
      Intrinsics.checkNotNullExpressionValue(var10000, "iterator(...)");
      Iterator var1 = var10000;

      while(var1.hasNext()) {
         Object var3 = var1.next();
         Intrinsics.checkNotNullExpressionValue(var3, "next(...)");
         WalletDataClass bank = (WalletDataClass)var3;
         this.walletDetailsFiltered.add(bank);
      }

      WalletAdapter var4 = this.allWalletAdapter;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
         var4 = null;
      }

      var4.deselectSelectedItem();
      var4 = this.allWalletAdapter;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
         var4 = null;
      }

      var4.notifyDataSetChanged();
   }

   public final void makeRecyclerViewJustBelowEditText() {
      Log.d("View will be gone now", "working fine");
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView19.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView24.setVisibility(8);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.linearLayout2.setVisibility(8);
   }

   public final void removeRecyclerViewFromBelowEditText() {
      Log.d("View will be gone now", "working fine");
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView19.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView24.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.linearLayout2.setVisibility(0);
   }

   private final void showOverlayInCurrentBottomSheet() {
      this.overlayViewCurrentBottomSheet = new View(this.requireContext());
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         var10000.setBackgroundColor(Color.parseColor("#80000000"));
      }

      FragmentWalletBottomSheetBinding var1 = this.binding;
      if (var1 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var1 = null;
      }

      var1.getRoot().addView(this.overlayViewCurrentBottomSheet, -1, -1);
   }

   public final void removeOverlayFromCurrentBottomSheet() {
      View var10000 = this.overlayViewCurrentBottomSheet;
      if (var10000 != null) {
         View it = var10000;
         int var2 = false;
         FragmentWalletBottomSheetBinding var3 = this.binding;
         if (var3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var3 = null;
         }

         var3.getRoot().removeView(it);
      }

   }

   private final void postRequest(Context context, String instrumentTypeValue) {
      Log.d("postRequestCalled", String.valueOf(System.currentTimeMillis()));
      RequestQueue var10000 = Volley.newRequestQueue(context);
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue requestQueue = var10000;
      JSONObject var5 = new JSONObject();
      int var7 = false;
      JSONObject var8 = new JSONObject();
      int var10 = false;
      new WebView(this.requireContext());
      String userAgentHeader = WebSettings.getDefaultUserAgent(this.requireContext());
      DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
      var8.put("screenHeight", String.valueOf(displayMetrics.heightPixels));
      var8.put("screenWidth", String.valueOf(displayMetrics.widthPixels));
      var8.put("acceptHeader", "application/json");
      var8.put("userAgentHeader", userAgentHeader);
      var8.put("browserLanguage", Locale.getDefault().toString());
      SharedPreferences var10002 = this.sharedPreferences;
      if (var10002 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10002 = null;
      }

      var8.put("ipAddress", var10002.getString("ipAddress", "null"));
      var8.put("colorDepth", 24);
      var8.put("javaEnabled", true);
      var8.put("timeZoneOffSet", 330);
      var5.put("browserData", var8);
      JSONObject var9 = new JSONObject();
      int var11 = false;
      var9.put("type", instrumentTypeValue);
      JSONObject var24 = new JSONObject();
      int var15 = false;
      var24.put("token", this.token);
      var9.put("wallet", var24);
      var5.put("instrumentDetails", var9);
      StringBuilder var25 = new StringBuilder();
      String var10001 = this.Base_Session_API_URL;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("Base_Session_API_URL");
         var10001 = null;
      }

      String var6 = var25.append(var10001).append(this.token).toString();
      Listener var18 = WalletBottomSheet::postRequest$lambda$28;
      ErrorListener var19 = WalletBottomSheet::postRequest$lambda$29;
      JsonObjectRequest var17 = new JsonObjectRequest(var5, var6, var18, var19) {
         public Map<String, String> getHeaders() {
            HashMap headers = new HashMap();
            ((Map)headers).put("X-Request-Id", String.valueOf(WalletBottomSheet.this.token));
            return (Map)headers;
         }
      };
      int var20 = false;
      int timeoutMs = 100000;
      int maxRetries = 0;
      float backoffMultiplier = 1.0F;
      var17.setRetryPolicy((RetryPolicy)(new DefaultRetryPolicy(timeoutMs, maxRetries, backoffMultiplier)));
      requestQueue.add((Request)var17);
   }

   public final void logJsonObject(@NotNull JSONObject jsonObject) {
      Intrinsics.checkNotNullParameter(jsonObject, "jsonObject");
      Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
      String jsonStr = gson.toJson(jsonObject);
      Log.d("Request Body Wallet", jsonStr);
   }

   private final void enableProceedButton() {
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      TextView var2 = var10000.textView6;
      var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var2.setTextColor(Color.parseColor(var10001.getString("buttonTextColor", "#000000")));
   }

   private final void disableProceedButton() {
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButtonRelativeLayout.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.disable_button);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(Color.parseColor("#ADACB0"));
   }

   public final void hideLoadingInButton() {
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setTextColor(ContextCompat.getColor(this.requireContext(), 17170443));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      RelativeLayout var1 = var10000.proceedButtonRelativeLayout;
      SharedPreferences var10001 = this.sharedPreferences;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("sharedPreferences");
         var10001 = null;
      }

      var1.setBackgroundColor(Color.parseColor(var10001.getString("primaryButtonColor", "#000000")));
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setBackgroundResource(drawable.button_bg);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(true);
   }

   public final void showLoadingInButton() {
      FragmentWalletBottomSheetBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.textView6.setVisibility(4);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.progressBar.setVisibility(0);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      ProgressBar var3 = var10000.progressBar;
      float[] var2 = new float[]{0.0F, 360.0F};
      ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(var3, "rotation", var2);
      rotateAnimation.setDuration(3000L);
      rotateAnimation.setRepeatCount(-1);
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      var10000.proceedButton.setEnabled(false);
      rotateAnimation.start();
   }

   private final void fetchTransactionDetailsFromSharedPreferences() {
      SharedPreferences sharedPreferences = this.requireContext().getSharedPreferences("TransactionDetails", 0);
      this.token = sharedPreferences.getString("token", "empty");
      Log.d("data fetched from sharedPreferences", String.valueOf(this.token));
      this.successScreenFullReferencePath = sharedPreferences.getString("successScreenFullReferencePath", "empty");
      Log.d("success screen path fetched from sharedPreferences", String.valueOf(this.successScreenFullReferencePath));
   }

   @Nullable
   public final String extractMessageFromErrorResponse(@NotNull String response) {
      Intrinsics.checkNotNullParameter(response, "response");

      try {
         JSONObject jsonObject = new JSONObject(response);
         return jsonObject.getString("message");
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   private static final void onCreateDialog$lambda$2(final WalletBottomSheet this$0, DialogInterface dialog) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNull(dialog, "null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
      BottomSheetDialog d = (BottomSheetDialog)dialog;
      FrameLayout bottomSheet = (FrameLayout)d.findViewById(id.design_bottom_sheet);
      if (bottomSheet != null) {
         this$0.bottomSheetBehavior = BottomSheetBehavior.from((View)bottomSheet);
      }

      if (this$0.bottomSheetBehavior == null) {
         Log.d("bottomSheetBehavior is null", "check here");
      }

      Window window = d.getWindow();
      if (window != null) {
         int var7 = false;
         window.setDimAmount(0.5F);
         window.setBackgroundDrawable((Drawable)(new ColorDrawable(Color.argb(128, 0, 0, 0))));
      }

      int screenHeight = this$0.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.9D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      BottomSheetBehavior var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setMaxHeight(desiredHeight);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setDraggable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setHideable(false);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.setState(3);
      }

      var10000 = this$0.bottomSheetBehavior;
      if (var10000 != null) {
         var10000.addBottomSheetCallback((BottomSheetCallback)(new BottomSheetCallback() {
            public void onStateChanged(View bottomSheet, int newState) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
               switch(newState) {
               case 5:
                  this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
               case 1:
               case 2:
               case 3:
               case 4:
               default:
               }
            }

            public void onSlide(View bottomSheet, float slideOffset) {
               Intrinsics.checkNotNullParameter(bottomSheet, "bottomSheet");
            }
         }));
      }

   }

   private static final Decoder fetchAndUpdateApiInPopularWallets$lambda$7$lambda$4$lambda$3(SourceResult result, Options options, ImageLoader var2) {
      Intrinsics.checkNotNullParameter(result, "result");
      Intrinsics.checkNotNullParameter(options, "options");
      Intrinsics.checkNotNullParameter(var2, "<unused var>");
      return (Decoder)(new SvgDecoder(result.getSource(), options, false, 4, (DefaultConstructorMarker)null));
   }

   private static final void fetchAndUpdateApiInPopularWallets$lambda$7$lambda$5(WalletBottomSheet this$0, int $index, RelativeLayout $relativeLayout, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($relativeLayout, "$relativeLayout");
      Object var10000 = this$0.requireContext().getSystemService("input_method");
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
      InputMethodManager inputMethodManager = (InputMethodManager)var10000;
      FragmentWalletBottomSheetBinding var10001 = this$0.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      inputMethodManager.hideSoftInputFromWindow(var10001.searchView.getWindowToken(), 0);
      this$0.liveDataPopularWalletSelectedOrNot.setValue(true);
      if (this$0.popularWalletsSelected && this$0.popularWalletsSelectedIndex == $index) {
         $relativeLayout.setBackgroundResource(drawable.popular_item_unselected_bg);
         this$0.popularWalletsSelected = false;
         this$0.proceedButtonIsEnabled.setValue(false);
      } else {
         if (this$0.popularWalletsSelectedIndex != -1) {
            this$0.fetchRelativeLayout(this$0.popularWalletsSelectedIndex).setBackgroundResource(drawable.popular_item_unselected_bg);
         }

         $relativeLayout.setBackgroundResource(drawable.selected_popular_item_bg);
         this$0.popularWalletsSelected = true;
         this$0.proceedButtonIsEnabled.setValue(true);
         this$0.popularWalletsSelectedIndex = $index;
      }

   }

   private static final boolean fetchAndUpdateApiInPopularWallets$lambda$7$lambda$6(WalletBottomSheet this$0, ConstraintLayout $constraintLayout, int $index, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($constraintLayout, "$constraintLayout");
      this$0.showToolTipPopularWallets($constraintLayout, ((WalletDataClass)this$0.walletDetailsOriginal.get($index)).getWalletName());
      return true;
   }

   private static final RequestQueue requestQueue_delegate$lambda$9(WalletBottomSheet this$0) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      return Volley.newRequestQueue(this$0.requireContext());
   }

   private static final void onCreateView$lambda$10(WalletBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
   }

   private static final void onCreateView$lambda$11(WalletBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      boolean enabled = false;
      this$0.enableProceedButton();
      enabled = true;
   }

   private static final void onCreateView$lambda$12(WalletBottomSheet this$0, Boolean enableProceedButton) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (enableProceedButton) {
         this$0.enableProceedButton();
      } else {
         this$0.disableProceedButton();
      }

   }

   private static final void onCreateView$lambda$13(WalletBottomSheet this$0, Integer checkPositionObserved) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (checkPositionObserved == null) {
         this$0.disableProceedButton();
      } else {
         this$0.enableProceedButton();
         this$0.checkedPosition = checkPositionObserved;
      }

   }

   private static final void onCreateView$lambda$14(WalletBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      this$0.showLoadingInButton();
      String walletInstrumentTypeValue = "";
      Object var10000 = this$0.liveDataPopularWalletSelectedOrNot.getValue();
      Intrinsics.checkNotNull(var10000);
      if ((Boolean)var10000) {
         walletInstrumentTypeValue = ((WalletDataClass)this$0.walletDetailsOriginal.get(this$0.popularWalletsSelectedIndex)).getInstrumentTypeValue();
      } else {
         ArrayList var3 = this$0.walletDetailsFiltered;
         Integer var10001 = this$0.checkedPosition;
         Intrinsics.checkNotNull(var10001);
         walletInstrumentTypeValue = ((WalletDataClass)var3.get(var10001)).getInstrumentTypeValue();
      }

      Log.d("Selected bank is : ", walletInstrumentTypeValue);
      FragmentWalletBottomSheetBinding var4 = this$0.binding;
      if (var4 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var4 = null;
      }

      var4.errorField.setVisibility(8);
      Context var5 = this$0.requireContext();
      Intrinsics.checkNotNullExpressionValue(var5, "requireContext(...)");
      this$0.postRequest(var5, walletInstrumentTypeValue);
   }

   private static final void onCreateView$lambda$15(WalletBottomSheet this$0, Boolean it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      if (it) {
         WalletAdapter var10000 = this$0.allWalletAdapter;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("allWalletAdapter");
            var10000 = null;
         }

         var10000.deselectSelectedItem();
      } else {
         this$0.unselectItemsInPopularLayout();
      }

   }

   private static final void onCreateView$lambda$16(WalletBottomSheet this$0, View it) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Object var10000 = this$0.requireContext().getSystemService("input_method");
      Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
      InputMethodManager imm = (InputMethodManager)var10000;
      FragmentWalletBottomSheetBinding var10001 = this$0.binding;
      if (var10001 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10001 = null;
      }

      imm.hideSoftInputFromWindow(var10001.searchView.getWindowToken(), 0);
   }

   private static final boolean onCreateView$lambda$17() {
      return true;
   }

   private static final void createColorAnimation$lambda$20$lambda$19(RelativeLayout[] $layouts, ValueAnimator animator) {
      Intrinsics.checkNotNullParameter($layouts, "$layouts");
      Intrinsics.checkNotNullParameter(animator, "animator");
      Object[] $this$forEach$iv = $layouts;
      int $i$f$forEach = false;
      int var4 = 0;

      for(int var5 = $layouts.length; var4 < var5; ++var4) {
         Object element$iv = $this$forEach$iv[var4];
         int var8 = false;
         if (element$iv != null) {
            Object var10001 = animator.getAnimatedValue();
            Intrinsics.checkNotNull(var10001, "null cannot be cast to non-null type kotlin.Int");
            element$iv.setBackgroundColor((Integer)var10001);
         }
      }

   }

   private static final void fetchWalletDetails$lambda$21(WalletBottomSheet this$0, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");

      try {
         JSONArray paymentMethodsArray = response.getJSONObject("configs").getJSONArray("paymentMethods");
         int i = 0;

         for(int var4 = paymentMethodsArray.length(); i < var4; ++i) {
            JSONObject paymentMethod = paymentMethodsArray.getJSONObject(i);
            if (Intrinsics.areEqual(paymentMethod.getString("type"), "Wallet")) {
               String walletName = paymentMethod.getString("title");
               String walletImage = paymentMethod.getString("logoUrl");
               Intrinsics.checkNotNull(walletImage);
               if (StringsKt.startsWith$default(walletImage, "/assets", false, 2, (Object)null)) {
                  walletImage = "https://checkout.boxpay.in" + paymentMethod.getString("logoUrl");
               }

               String walletBrand = paymentMethod.getString("brand");
               String walletInstrumentTypeValue = paymentMethod.getString("instrumentTypeValue");
               ArrayList var10000 = this$0.walletDetailsOriginal;
               Intrinsics.checkNotNull(walletName);
               Intrinsics.checkNotNull(walletImage);
               Intrinsics.checkNotNull(walletBrand);
               Intrinsics.checkNotNull(walletInstrumentTypeValue);
               var10000.add(new WalletDataClass(walletName, walletImage, walletBrand, walletInstrumentTypeValue));
            }
         }

         this$0.showAllWallets();
         this$0.fetchAndUpdateApiInPopularWallets();
         this$0.removeLoadingScreenState();
      } catch (Exception var11) {
         Log.d("Error Occured", var11.toString());
         var11.printStackTrace();
      }

   }

   private static final void fetchWalletDetails$lambda$22(WalletBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", " fetching wallets error response: " + errorResponse);
         FragmentWalletBottomSheetBinding var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.errorField.setVisibility(0);
         var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.textView4.setText((CharSequence)this$0.extractMessageFromErrorResponse(errorResponse));
         this$0.hideLoadingInButton();
      }

   }

   private static final void postRequest$lambda$28(WalletBottomSheet this$0, Context $context, JSONObject response) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Intrinsics.checkNotNullParameter($context, "$context");
      Intrinsics.checkNotNull(response);
      this$0.logJsonObject(response);
      this$0.transactionId = response.getString("transactionId").toString();
      String var10001 = this$0.transactionId;
      Intrinsics.checkNotNull(var10001);
      this$0.updateTransactionIDInSharedPreferences(var10001);
      this$0.hideLoadingInButton();

      try {
         this$0.logJsonObject(response);
         Log.d("error after actionsArray", "Wallet");
         JSONArray actionsArray = response.getJSONArray("actions");
         Log.d("error after status", "Wallet");
         String status = response.getJSONObject("status").getString("status");
         String url = "";
         int i = 0;

         for(int var7 = actionsArray.length(); i < var7; ++i) {
            JSONObject actionObject = actionsArray.getJSONObject(i);
            url = actionObject.getString("url");
            Log.d("url and status", url + '\n' + status);
         }

         if (status.equals("Approved")) {
            PaymentSuccessfulWithDetailsBottomSheet bottomSheet = new PaymentSuccessfulWithDetailsBottomSheet();
            bottomSheet.show(this$0.getParentFragmentManager(), "PaymentSuccessfulWithDetailsBottomSheet");
            this$0.dismissAndMakeButtonsOfMainBottomSheetEnabled();
         } else {
            Intent intent = new Intent($context, OTPScreenWebView.class);
            intent.putExtra("url", url);
            this$0.startActivity(intent);
         }
      } catch (JSONException var9) {
         FragmentWalletBottomSheetBinding var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.errorField.setVisibility(0);
         var10000 = this$0.binding;
         if (var10000 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var10000 = null;
         }

         var10000.textView4.setText((CharSequence)"Error requesting payment");
         Log.e("Error in handling response", var9.toString());
      }

   }

   private static final void postRequest$lambda$29(WalletBottomSheet this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("Error", "Error occurred: " + error.getMessage());
      if (error != null && error.networkResponse != null && error.networkResponse.data != null) {
         byte[] var10000 = error.networkResponse.data;
         Intrinsics.checkNotNullExpressionValue(var10000, "data");
         byte[] var3 = var10000;
         String errorResponse = new String(var3, Charsets.UTF_8);
         Log.e("Error", "Detailed error response: " + errorResponse);
         FragmentWalletBottomSheetBinding var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.errorField.setVisibility(0);
         var4 = this$0.binding;
         if (var4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("binding");
            var4 = null;
         }

         var4.textView4.setText((CharSequence)this$0.extractMessageFromErrorResponse(errorResponse));
         this$0.hideLoadingInButton();
      }

   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"},
      d2 = {"Lcom/example/tray/WalletBottomSheet$Companion;", "", "<init>", "()V", "Tray_release"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
