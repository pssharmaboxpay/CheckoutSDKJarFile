package com.example.tray;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider.Factory;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 0, 0},
   k = 3,
   xi = 48,
   d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003H\n¨\u0006\u0004"},
   d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelProvider$Factory;", "VM", "Landroidx/lifecycle/ViewModel;", "androidx/fragment/app/FragmentViewModelLazyKt$activityViewModels$2"}
)
public final class CancelConfirmationBottomSheet$special$$inlined$activityViewModels$default$2 extends Lambda implements Function0<Factory> {
   // $FF: synthetic field
   final Fragment $this_activityViewModels;

   public CancelConfirmationBottomSheet$special$$inlined$activityViewModels$default$2(Fragment $receiver) {
      super(0);
      this.$this_activityViewModels = $receiver;
   }

   @NotNull
   public final Factory invoke() {
      Factory var10000 = this.$this_activityViewModels.requireActivity().getDefaultViewModelProviderFactory();
      Intrinsics.checkNotNullExpressionValue(var10000, "requireActivity().defaultViewModelProviderFactory");
      return var10000;
   }
}
