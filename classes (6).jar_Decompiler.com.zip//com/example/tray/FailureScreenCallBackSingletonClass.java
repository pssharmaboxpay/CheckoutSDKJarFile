package com.example.tray;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000 \u000e2\u00020\u0001:\u0001\u000eB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\n\u001a\u0004\u0018\u00010\u0005J\u0010\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0005R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t¨\u0006\u000f"},
   d2 = {"Lcom/example/tray/FailureScreenCallBackSingletonClass;", "", "<init>", "()V", "callBackFunctions", "LFailureScreenSharedViewModel;", "getCallBackFunctions", "()LFailureScreenSharedViewModel;", "setCallBackFunctions", "(LFailureScreenSharedViewModel;)V", "getYourObject", "setYourObject", "", "yourObject", "Companion", "Tray_release"}
)
public final class FailureScreenCallBackSingletonClass {
   @NotNull
   public static final FailureScreenCallBackSingletonClass.Companion Companion = new FailureScreenCallBackSingletonClass.Companion((DefaultConstructorMarker)null);
   @Nullable
   private .FailureScreenSharedViewModel callBackFunctions;
   @Nullable
   private static volatile FailureScreenCallBackSingletonClass instance;

   private FailureScreenCallBackSingletonClass() {
   }

   @Nullable
   public final .FailureScreenSharedViewModel getCallBackFunctions() {
      return this.callBackFunctions;
   }

   public final void setCallBackFunctions(@Nullable .FailureScreenSharedViewModel var1) {
      this.callBackFunctions = var1;
   }

   @Nullable
   public final .FailureScreenSharedViewModel getYourObject() {
      return this.callBackFunctions;
   }

   public final void setYourObject(@Nullable .FailureScreenSharedViewModel yourObject) {
      this.callBackFunctions = yourObject;
   }

   // $FF: synthetic method
   public static final FailureScreenCallBackSingletonClass access$getInstance$cp() {
      return instance;
   }

   // $FF: synthetic method
   public static final void access$setInstance$cp(FailureScreenCallBackSingletonClass var0) {
      instance = var0;
   }

   // $FF: synthetic method
   public FailureScreenCallBackSingletonClass(DefaultConstructorMarker $constructor_marker) {
      this();
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0006\u001a\u00020\u0005R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lcom/example/tray/FailureScreenCallBackSingletonClass$Companion;", "", "<init>", "()V", "instance", "Lcom/example/tray/FailureScreenCallBackSingletonClass;", "getInstance", "Tray_release"}
   )
   @SourceDebugExtension({"SMAP\nFailureScreenCallBackSingletonClass.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FailureScreenCallBackSingletonClass.kt\ncom/example/tray/FailureScreenCallBackSingletonClass$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,37:1\n1#2:38\n*E\n"})
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final FailureScreenCallBackSingletonClass getInstance() {
         // $FF: Couldn't be decompiled
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}
