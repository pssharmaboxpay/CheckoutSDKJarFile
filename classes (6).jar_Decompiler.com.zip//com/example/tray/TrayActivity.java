package com.example.tray;

import android.app.Dialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tray.R.dimen;
import com.example.tray.R.id;
import com.example.tray.databinding.ActivityTrayBinding;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONObject;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J&\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\b\u0010\u001c\u001a\u00020\u001dH\u0002J\u0010\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001f\u001a\u00020 H\u0002J\u0012\u0010!\u001a\u00020\"2\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\u001a\u0010#\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020\u00152\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\b\u0010%\u001a\u00020\u001dH\u0016R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\tR\u0012\u0010\n\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0004\n\u0002\u0010\tR\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006&"},
   d2 = {"Lcom/example/tray/TrayActivity;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "<init>", "()V", "currencySymbol", "", "currencyCode", "price", "", "Ljava/lang/Integer;", "quantity", "rotated", "", "binding", "Lcom/example/tray/databinding/ActivityTrayBinding;", "isCardExpanded", "url", "bottomSheetBehavior", "Lcom/google/android/material/bottomsheet/BottomSheetBehavior;", "Landroid/widget/LinearLayout;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "JsonObject", "", "toggleCardViewHeight", "cardView", "Landroidx/cardview/widget/CardView;", "onCreateDialog", "Landroid/app/Dialog;", "onViewCreated", "view", "onStart", "Tray_release"}
)
public final class TrayActivity extends BottomSheetDialogFragment {
   @Nullable
   private String currencySymbol;
   @Nullable
   private String currencyCode;
   @Nullable
   private Integer price = 0;
   @Nullable
   private Integer quantity = 0;
   private boolean rotated;
   private ActivityTrayBinding binding;
   private boolean isCardExpanded;
   @Nullable
   private String url;
   @Nullable
   private BottomSheetBehavior<LinearLayout> bottomSheetBehavior;

   @Nullable
   public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(inflater, "inflater");
      this.binding = ActivityTrayBinding.inflate(inflater, container, false);
      AppCompatDelegate.setDefaultNightMode(1);
      Bundle var10001 = this.getArguments();
      this.url = String.valueOf(var10001 != null ? var10001.getString("REQUIRED_STRING") : null);
      ActivityTrayBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      Intrinsics.checkNotNullExpressionValue(var10000.getRoot(), "getRoot(...)");
      this.JsonObject();
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      return (View)var10000.getRoot();
   }

   private final void JsonObject() {
      RequestQueue var10000 = Volley.newRequestQueue(this.requireContext());
      Intrinsics.checkNotNullExpressionValue(var10000, "newRequestQueue(...)");
      RequestQueue queue = var10000;
      JsonObjectRequest request = new JsonObjectRequest(0, this.url, (JSONObject)null, TrayActivity::JsonObject$lambda$0, TrayActivity::JsonObject$lambda$1);
      queue.add((Request)request);
   }

   private final void toggleCardViewHeight(final CardView cardView) {
      final int initialHeight = cardView.getHeight();
      final int targetHeight = this.isCardExpanded ? this.getResources().getDimensionPixelSize(dimen.collapsed_card_height) : this.getResources().getDimensionPixelSize(dimen.expanded_card_height);
      <undefinedtype> animation = new Animation() {
         protected void applyTransformation(float interpolatedTime, Transformation t) {
            Intrinsics.checkNotNullParameter(t, "t");
            int newHeight = (int)((float)initialHeight + (float)(targetHeight - initialHeight) * interpolatedTime);
            cardView.getLayoutParams().height = newHeight;
            cardView.requestLayout();
         }

         public boolean willChangeBounds() {
            return true;
         }
      };
      animation.setDuration(300L);
      cardView.startAnimation((Animation)animation);
      this.isCardExpanded = !this.isCardExpanded;
   }

   @NotNull
   public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
      Dialog var10000 = super.onCreateDialog(savedInstanceState);
      Intrinsics.checkNotNullExpressionValue(var10000, "onCreateDialog(...)");
      Dialog view = var10000;
      return view;
   }

   public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
      Intrinsics.checkNotNullParameter(view, "view");
      super.onViewCreated(view, savedInstanceState);
      ActivityTrayBinding var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      Intrinsics.checkNotNullExpressionValue(var10000.getRoot(), "getRoot(...)");
      var10000 = this.binding;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("binding");
         var10000 = null;
      }

      LinearLayout var11 = var10000.clayout;
      Intrinsics.checkNotNullExpressionValue(var11, "clayout");
      LinearLayout bottomSheetContent = var11;
      int screenHeight = this.getResources().getDisplayMetrics().heightPixels;
      double percentageOfScreenHeight = 0.9D;
      int desiredHeight = (int)((double)screenHeight * percentageOfScreenHeight);
      LayoutParams layoutParams = bottomSheetContent.getLayoutParams();
      layoutParams.height = desiredHeight;
      bottomSheetContent.setLayoutParams(layoutParams);
      Dialog var12 = this.getDialog();
      LinearLayout coordinatorLayout = var12 != null ? (LinearLayout)var12.findViewById(id.clayout) : null;
      if (coordinatorLayout == null) {
         Log.d("coordinatorLayout null", "Null");
      }

      if (coordinatorLayout != null) {
         coordinatorLayout.setMinimumHeight(Resources.getSystem().getDisplayMetrics().heightPixels);
      }

   }

   public void onStart() {
      super.onStart();
   }

   private static final void JsonObject$lambda$0(JSONObject response) {
      try {
         JSONObject obj = response.getJSONObject("paymentDetails");
         JSONObject paymentDetailsOBJ = obj.getJSONObject("money");
         JSONObject orderJsonObj = obj.getJSONObject("order");
         JSONArray orderJsonArray = orderJsonObj.getJSONArray("items");
         String var5 = orderJsonArray.getJSONObject(0).getString("quantity");
      } catch (Exception var6) {
         Log.d("Error Occured", var6.toString());
         var6.printStackTrace();
      }

   }

   private static final void JsonObject$lambda$1(TrayActivity this$0, VolleyError error) {
      Intrinsics.checkNotNullParameter(this$0, "this$0");
      Log.e("error here", "RESPONSE IS " + error);
      Toast.makeText(this$0.requireContext(), (CharSequence)"Fail to get response", 0).show();
   }
}
