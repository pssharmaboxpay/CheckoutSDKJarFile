package com.example.tray.progressBar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.View;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\r\u001a\u00020\fJ\u0010\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u0013H\u0014J \u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\u0017H\u0002R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001a"},
   d2 = {"Lcom/example/tray/progressBar/CircularProgressBar;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "backgroundPaint", "Landroid/graphics/Paint;", "progressPaint", "progress", "", "max", "setProgress", "", "setMax", "onDraw", "canvas", "Landroid/graphics/Canvas;", "createGradientShader", "Landroid/graphics/Shader;", "centerX", "", "centerY", "startAngle", "Tray_release"}
)
public final class CircularProgressBar extends View {
   @NotNull
   private final Paint backgroundPaint;
   @NotNull
   private final Paint progressPaint;
   private int progress;
   private int max;

   public CircularProgressBar(@NotNull Context context, @Nullable AttributeSet attrs) {
      Intrinsics.checkNotNullParameter(context, "context");
      super(context, attrs);
      this.backgroundPaint = new Paint(1);
      this.progressPaint = new Paint(1);
      this.max = 100;
      this.backgroundPaint.setColor(-3717048);
      this.progressPaint.setStyle(Style.STROKE);
      this.progressPaint.setStrokeCap(Cap.ROUND);
   }

   // $FF: synthetic method
   public CircularProgressBar(Context var1, AttributeSet var2, int var3, DefaultConstructorMarker var4) {
      if ((var3 & 2) != 0) {
         var2 = null;
      }

      this(var1, var2);
   }

   public final void setProgress(int progress) {
      this.progress = progress;
      this.invalidate();
   }

   public final void setMax(int max) {
      this.max = max;
      this.invalidate();
   }

   protected void onDraw(@NotNull Canvas canvas) {
      Intrinsics.checkNotNullParameter(canvas, "canvas");
      super.onDraw(canvas);
      float width = (float)this.getWidth();
      float height = (float)this.getHeight();
      float radius = RangesKt.coerceAtMost(width, height) / (float)2 - (float)20;
      float strokeWidth = 20.0F;
      this.backgroundPaint.setColor(-1579033);
      canvas.drawCircle(width / (float)2, height / (float)2, radius, this.backgroundPaint);
      RectF rectProgress = new RectF(20.0F + strokeWidth / (float)2, 20.0F + strokeWidth / (float)2, width - (float)20 - strokeWidth / (float)2, height - (float)20 - strokeWidth / (float)2);
      float angle = 360.0F * ((float)this.progress / (float)this.max);
      float startAngle = 0.0F;
      RectF rectTrail = new RectF(20.0F, 20.0F, width - (float)20, height - (float)20);
      Paint trailPaint = new Paint(1);
      trailPaint.setColor(820504551);
      canvas.drawArc(rectTrail, startAngle + angle, 360.0F - angle, false, trailPaint);
      this.progressPaint.setStrokeWidth(strokeWidth);
      this.progressPaint.setShader(this.createGradientShader(rectProgress.centerX(), rectProgress.centerY(), startAngle));
      canvas.drawArc(rectProgress, startAngle, angle, false, this.progressPaint);
   }

   private final Shader createGradientShader(float centerX, float centerY, float startAngle) {
      int[] var5 = new int[]{-4530177, -10374408, -4530177};
      int[] gradientColors = var5;
      float adjustedStartAngle = startAngle - 90.0F;
      Shader var10000;
      if (VERSION.SDK_INT >= 21) {
         var10000 = (Shader)(new SweepGradient(centerX, centerY, gradientColors, (float[])null));
      } else {
         SweepGradient gradient = new SweepGradient(centerX, centerY, gradientColors[0], gradientColors[2]);
         Matrix matrix = new Matrix();
         matrix.setRotate(adjustedStartAngle, centerX, centerY);
         gradient.setLocalMatrix(matrix);
         var10000 = (Shader)gradient;
      }

      return var10000;
   }
}
