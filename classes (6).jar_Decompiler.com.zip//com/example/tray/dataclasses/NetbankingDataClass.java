package com.example.tray.dataclasses;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"},
   d2 = {"Lcom/example/tray/dataclasses/NetbankingDataClass;", "", "bankName", "", "bankImage", "bankBrand", "bankInstrumentTypeValue", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getBankName", "()Ljava/lang/String;", "getBankImage", "getBankBrand", "getBankInstrumentTypeValue", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "Tray_release"}
)
public final class NetbankingDataClass {
   @NotNull
   private final String bankName;
   @NotNull
   private final String bankImage;
   @NotNull
   private final String bankBrand;
   @NotNull
   private final String bankInstrumentTypeValue;

   public NetbankingDataClass(@NotNull String bankName, @NotNull String bankImage, @NotNull String bankBrand, @NotNull String bankInstrumentTypeValue) {
      Intrinsics.checkNotNullParameter(bankName, "bankName");
      Intrinsics.checkNotNullParameter(bankImage, "bankImage");
      Intrinsics.checkNotNullParameter(bankBrand, "bankBrand");
      Intrinsics.checkNotNullParameter(bankInstrumentTypeValue, "bankInstrumentTypeValue");
      super();
      this.bankName = bankName;
      this.bankImage = bankImage;
      this.bankBrand = bankBrand;
      this.bankInstrumentTypeValue = bankInstrumentTypeValue;
   }

   @NotNull
   public final String getBankName() {
      return this.bankName;
   }

   @NotNull
   public final String getBankImage() {
      return this.bankImage;
   }

   @NotNull
   public final String getBankBrand() {
      return this.bankBrand;
   }

   @NotNull
   public final String getBankInstrumentTypeValue() {
      return this.bankInstrumentTypeValue;
   }

   @NotNull
   public final String component1() {
      return this.bankName;
   }

   @NotNull
   public final String component2() {
      return this.bankImage;
   }

   @NotNull
   public final String component3() {
      return this.bankBrand;
   }

   @NotNull
   public final String component4() {
      return this.bankInstrumentTypeValue;
   }

   @NotNull
   public final NetbankingDataClass copy(@NotNull String bankName, @NotNull String bankImage, @NotNull String bankBrand, @NotNull String bankInstrumentTypeValue) {
      Intrinsics.checkNotNullParameter(bankName, "bankName");
      Intrinsics.checkNotNullParameter(bankImage, "bankImage");
      Intrinsics.checkNotNullParameter(bankBrand, "bankBrand");
      Intrinsics.checkNotNullParameter(bankInstrumentTypeValue, "bankInstrumentTypeValue");
      return new NetbankingDataClass(bankName, bankImage, bankBrand, bankInstrumentTypeValue);
   }

   // $FF: synthetic method
   public static NetbankingDataClass copy$default(NetbankingDataClass var0, String var1, String var2, String var3, String var4, int var5, Object var6) {
      if ((var5 & 1) != 0) {
         var1 = var0.bankName;
      }

      if ((var5 & 2) != 0) {
         var2 = var0.bankImage;
      }

      if ((var5 & 4) != 0) {
         var3 = var0.bankBrand;
      }

      if ((var5 & 8) != 0) {
         var4 = var0.bankInstrumentTypeValue;
      }

      return var0.copy(var1, var2, var3, var4);
   }

   @NotNull
   public String toString() {
      return "NetbankingDataClass(bankName=" + this.bankName + ", bankImage=" + this.bankImage + ", bankBrand=" + this.bankBrand + ", bankInstrumentTypeValue=" + this.bankInstrumentTypeValue + ')';
   }

   public int hashCode() {
      int result = this.bankName.hashCode();
      result = result * 31 + this.bankImage.hashCode();
      result = result * 31 + this.bankBrand.hashCode();
      result = result * 31 + this.bankInstrumentTypeValue.hashCode();
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof NetbankingDataClass)) {
         return false;
      } else {
         NetbankingDataClass var2 = (NetbankingDataClass)other;
         if (!Intrinsics.areEqual(this.bankName, var2.bankName)) {
            return false;
         } else if (!Intrinsics.areEqual(this.bankImage, var2.bankImage)) {
            return false;
         } else if (!Intrinsics.areEqual(this.bankBrand, var2.bankBrand)) {
            return false;
         } else {
            return Intrinsics.areEqual(this.bankInstrumentTypeValue, var2.bankInstrumentTypeValue);
         }
      }
   }
}
