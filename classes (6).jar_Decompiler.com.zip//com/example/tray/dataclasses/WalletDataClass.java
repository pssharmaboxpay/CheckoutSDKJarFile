package com.example.tray.dataclasses;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J1\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"},
   d2 = {"Lcom/example/tray/dataclasses/WalletDataClass;", "", "walletName", "", "walletImage", "walletBrand", "instrumentTypeValue", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getWalletName", "()Ljava/lang/String;", "getWalletImage", "getWalletBrand", "getInstrumentTypeValue", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "Tray_release"}
)
public final class WalletDataClass {
   @NotNull
   private final String walletName;
   @NotNull
   private final String walletImage;
   @NotNull
   private final String walletBrand;
   @NotNull
   private final String instrumentTypeValue;

   public WalletDataClass(@NotNull String walletName, @NotNull String walletImage, @NotNull String walletBrand, @NotNull String instrumentTypeValue) {
      Intrinsics.checkNotNullParameter(walletName, "walletName");
      Intrinsics.checkNotNullParameter(walletImage, "walletImage");
      Intrinsics.checkNotNullParameter(walletBrand, "walletBrand");
      Intrinsics.checkNotNullParameter(instrumentTypeValue, "instrumentTypeValue");
      super();
      this.walletName = walletName;
      this.walletImage = walletImage;
      this.walletBrand = walletBrand;
      this.instrumentTypeValue = instrumentTypeValue;
   }

   @NotNull
   public final String getWalletName() {
      return this.walletName;
   }

   @NotNull
   public final String getWalletImage() {
      return this.walletImage;
   }

   @NotNull
   public final String getWalletBrand() {
      return this.walletBrand;
   }

   @NotNull
   public final String getInstrumentTypeValue() {
      return this.instrumentTypeValue;
   }

   @NotNull
   public final String component1() {
      return this.walletName;
   }

   @NotNull
   public final String component2() {
      return this.walletImage;
   }

   @NotNull
   public final String component3() {
      return this.walletBrand;
   }

   @NotNull
   public final String component4() {
      return this.instrumentTypeValue;
   }

   @NotNull
   public final WalletDataClass copy(@NotNull String walletName, @NotNull String walletImage, @NotNull String walletBrand, @NotNull String instrumentTypeValue) {
      Intrinsics.checkNotNullParameter(walletName, "walletName");
      Intrinsics.checkNotNullParameter(walletImage, "walletImage");
      Intrinsics.checkNotNullParameter(walletBrand, "walletBrand");
      Intrinsics.checkNotNullParameter(instrumentTypeValue, "instrumentTypeValue");
      return new WalletDataClass(walletName, walletImage, walletBrand, instrumentTypeValue);
   }

   // $FF: synthetic method
   public static WalletDataClass copy$default(WalletDataClass var0, String var1, String var2, String var3, String var4, int var5, Object var6) {
      if ((var5 & 1) != 0) {
         var1 = var0.walletName;
      }

      if ((var5 & 2) != 0) {
         var2 = var0.walletImage;
      }

      if ((var5 & 4) != 0) {
         var3 = var0.walletBrand;
      }

      if ((var5 & 8) != 0) {
         var4 = var0.instrumentTypeValue;
      }

      return var0.copy(var1, var2, var3, var4);
   }

   @NotNull
   public String toString() {
      return "WalletDataClass(walletName=" + this.walletName + ", walletImage=" + this.walletImage + ", walletBrand=" + this.walletBrand + ", instrumentTypeValue=" + this.instrumentTypeValue + ')';
   }

   public int hashCode() {
      int result = this.walletName.hashCode();
      result = result * 31 + this.walletImage.hashCode();
      result = result * 31 + this.walletBrand.hashCode();
      result = result * 31 + this.instrumentTypeValue.hashCode();
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof WalletDataClass)) {
         return false;
      } else {
         WalletDataClass var2 = (WalletDataClass)other;
         if (!Intrinsics.areEqual(this.walletName, var2.walletName)) {
            return false;
         } else if (!Intrinsics.areEqual(this.walletImage, var2.walletImage)) {
            return false;
         } else if (!Intrinsics.areEqual(this.walletBrand, var2.walletBrand)) {
            return false;
         } else {
            return Intrinsics.areEqual(this.instrumentTypeValue, var2.instrumentTypeValue);
         }
      }
   }
}
