package com.example.tray.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import coil.Coil;
import coil.ImageLoader;
import coil.decode.Decoder;
import coil.decode.SvgDecoder;
import coil.fetch.SourceResult;
import coil.request.ImageRequest;
import coil.request.Options;
import coil.request.ImageRequest.Builder;
import com.example.tray.R.color;
import com.example.tray.R.drawable;
import com.example.tray.databinding.WalletItemBinding;
import com.example.tray.dataclasses.WalletDataClass;
import com.skydoves.balloon.Balloon;
import com.skydoves.balloon.BalloonAnimation;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {2, 0, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001.BE\u0012\u0016\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0006j\b\u0012\u0004\u0012\u00020\u0005`\u0004\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\u001c\u0010 \u001a\u00060\u0002R\u00020\u00002\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0014H\u0016J\b\u0010$\u001a\u00020\u0014H\u0016J\u001c\u0010%\u001a\u00020&2\n\u0010'\u001a\u00060\u0002R\u00020\u00002\u0006\u0010(\u001a\u00020\u0014H\u0016J\u0018\u0010)\u001a\u00020&2\u0006\u0010(\u001a\u00020\u00142\u0006\u0010*\u001a\u00020+H\u0002J\u0006\u0010,\u001a\u00020&J\u0006\u0010-\u001a\u00020\u0014R \u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u00050\u0006j\b\u0012\u0004\u0012\u00020\u0005`\u0004X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0012R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00140\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001b\u0010\u001a\u001a\n \u001c*\u0004\u0018\u00010\u001b0\u001b¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001e¨\u0006/"},
   d2 = {"Lcom/example/tray/adapters/WalletAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/example/tray/adapters/WalletAdapter$WalletAdapterViewHolder;", "walletDetails", "Lkotlin/collections/ArrayList;", "Lcom/example/tray/dataclasses/WalletDataClass;", "Ljava/util/ArrayList;", "recyclerView", "Landroidx/recyclerview/widget/RecyclerView;", "liveDataPopularItemSelectedOrNot", "Landroidx/lifecycle/MutableLiveData;", "", "context", "Landroid/content/Context;", "searchView", "Landroid/widget/SearchView;", "<init>", "(Ljava/util/ArrayList;Landroidx/recyclerview/widget/RecyclerView;Landroidx/lifecycle/MutableLiveData;Landroid/content/Context;Landroid/widget/SearchView;)V", "Ljava/util/ArrayList;", "checkedPosition", "", "checkPositionLiveData", "getCheckPositionLiveData", "()Landroidx/lifecycle/MutableLiveData;", "setCheckPositionLiveData", "(Landroidx/lifecycle/MutableLiveData;)V", "sharedPreferences", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "getSharedPreferences", "()Landroid/content/SharedPreferences;", "Landroid/content/SharedPreferences;", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "getItemCount", "onBindViewHolder", "", "holder", "position", "handleRadioButtonClick", "imageView", "Landroid/widget/ImageView;", "deselectSelectedItem", "getCheckedPosition", "WalletAdapterViewHolder", "Tray_release"}
)
public final class WalletAdapter extends Adapter<WalletAdapter.WalletAdapterViewHolder> {
   @NotNull
   private final ArrayList<WalletDataClass> walletDetails;
   @NotNull
   private final RecyclerView recyclerView;
   @NotNull
   private MutableLiveData<Boolean> liveDataPopularItemSelectedOrNot;
   @NotNull
   private final Context context;
   @NotNull
   private final SearchView searchView;
   private int checkedPosition;
   @NotNull
   private MutableLiveData<Integer> checkPositionLiveData;
   private final SharedPreferences sharedPreferences;

   public WalletAdapter(@NotNull ArrayList<WalletDataClass> walletDetails, @NotNull RecyclerView recyclerView, @NotNull MutableLiveData<Boolean> liveDataPopularItemSelectedOrNot, @NotNull Context context, @NotNull SearchView searchView) {
      Intrinsics.checkNotNullParameter(walletDetails, "walletDetails");
      Intrinsics.checkNotNullParameter(recyclerView, "recyclerView");
      Intrinsics.checkNotNullParameter(liveDataPopularItemSelectedOrNot, "liveDataPopularItemSelectedOrNot");
      Intrinsics.checkNotNullParameter(context, "context");
      Intrinsics.checkNotNullParameter(searchView, "searchView");
      super();
      this.walletDetails = walletDetails;
      this.recyclerView = recyclerView;
      this.liveDataPopularItemSelectedOrNot = liveDataPopularItemSelectedOrNot;
      this.context = context;
      this.searchView = searchView;
      this.checkedPosition = -1;
      this.checkPositionLiveData = new MutableLiveData();
      this.sharedPreferences = this.context.getSharedPreferences("TransactionDetails", 0);
   }

   @NotNull
   public final MutableLiveData<Integer> getCheckPositionLiveData() {
      return this.checkPositionLiveData;
   }

   public final void setCheckPositionLiveData(@NotNull MutableLiveData<Integer> var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.checkPositionLiveData = var1;
   }

   public final SharedPreferences getSharedPreferences() {
      return this.sharedPreferences;
   }

   @NotNull
   public WalletAdapter.WalletAdapterViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
      Intrinsics.checkNotNullParameter(parent, "parent");
      WalletItemBinding var10003 = WalletItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
      Intrinsics.checkNotNullExpressionValue(var10003, "inflate(...)");
      return new WalletAdapter.WalletAdapterViewHolder(var10003);
   }

   public int getItemCount() {
      return this.walletDetails.size();
   }

   public void onBindViewHolder(@NotNull WalletAdapter.WalletAdapterViewHolder holder, int position) {
      Intrinsics.checkNotNullParameter(holder, "holder");
      holder.bind(position);
   }

   private final void handleRadioButtonClick(int position, ImageView imageView) {
      if (this.checkedPosition != position) {
         ViewHolder var4 = this.recyclerView.findViewHolderForAdapterPosition(this.checkedPosition);
         WalletAdapter.WalletAdapterViewHolder previousCheckedViewHolder = var4 instanceof WalletAdapter.WalletAdapterViewHolder ? (WalletAdapter.WalletAdapterViewHolder)var4 : null;
         ImageView var10;
         WalletItemBinding var10000;
         if (previousCheckedViewHolder != null) {
            var10000 = previousCheckedViewHolder.getBinding();
            if (var10000 != null) {
               var10 = var10000.radioButton;
               if (var10 != null) {
                  var10.setBackgroundResource(drawable.custom_radio_unchecked);
               }
            }
         }

         imageView.setBackgroundResource(drawable.custom_radio_checked);
         Drawable radioButtonDrawable = imageView.getBackground();
         if (radioButtonDrawable instanceof LayerDrawable) {
            Log.d("Drawable found", "success");
            LayerDrawable layerDrawable = (LayerDrawable)radioButtonDrawable;
            Drawable var7 = layerDrawable.getDrawable(0);
            GradientDrawable shapeDrawable = var7 instanceof GradientDrawable ? (GradientDrawable)var7 : null;
            if (shapeDrawable != null) {
               shapeDrawable.setColor(Color.parseColor(this.sharedPreferences.getString("primaryButtonColor", "#0D8EFF")));
            }

            imageView.setBackground((Drawable)layerDrawable);
         } else {
            Log.d("Drawable found", "failure in handle click");
         }

         ViewHolder var11 = this.recyclerView.findViewHolderForAdapterPosition(position);
         WalletAdapter.WalletAdapterViewHolder clickedViewHolder = var11 instanceof WalletAdapter.WalletAdapterViewHolder ? (WalletAdapter.WalletAdapterViewHolder)var11 : null;
         if (clickedViewHolder != null) {
            var10000 = clickedViewHolder.getBinding();
            if (var10000 != null) {
               var10 = var10000.radioButton;
               if (var10 != null) {
                  var10.setBackgroundResource(drawable.custom_radio_checked);
               }
            }
         }

         this.checkedPosition = position;
         this.checkPositionLiveData.setValue(this.checkedPosition);
      }

   }

   public final void deselectSelectedItem() {
      if (this.checkedPosition != -1) {
         ViewHolder var2 = this.recyclerView.findViewHolderForAdapterPosition(this.checkedPosition);
         WalletAdapter.WalletAdapterViewHolder previousCheckedViewHolder = var2 instanceof WalletAdapter.WalletAdapterViewHolder ? (WalletAdapter.WalletAdapterViewHolder)var2 : null;
         if (previousCheckedViewHolder != null) {
            WalletItemBinding var10000 = previousCheckedViewHolder.getBinding();
            if (var10000 != null) {
               ImageView var3 = var10000.radioButton;
               if (var3 != null) {
                  var3.setBackgroundResource(drawable.custom_radio_unchecked);
               }
            }
         }

         this.checkedPosition = -1;
         this.checkPositionLiveData.setValue(-1);
      }

   }

   public final int getCheckedPosition() {
      return this.checkedPosition;
   }

   @Metadata(
      mv = {2, 0, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\f"},
      d2 = {"Lcom/example/tray/adapters/WalletAdapter$WalletAdapterViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "binding", "Lcom/example/tray/databinding/WalletItemBinding;", "<init>", "(Lcom/example/tray/adapters/WalletAdapter;Lcom/example/tray/databinding/WalletItemBinding;)V", "getBinding", "()Lcom/example/tray/databinding/WalletItemBinding;", "bind", "", "position", "", "Tray_release"}
   )
   @SourceDebugExtension({"SMAP\nWalletAdapter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WalletAdapter.kt\ncom/example/tray/adapters/WalletAdapter$WalletAdapterViewHolder\n+ 2 Extensions.kt\ncoil/-SingletonExtensions\n+ 3 Balloon.kt\ncom/skydoves/balloon/BalloonKt\n*L\n1#1,222:1\n54#2,3:223\n24#2:226\n59#2,6:227\n133#3:233\n*S KotlinDebug\n*F\n+ 1 WalletAdapter.kt\ncom/example/tray/adapters/WalletAdapter$WalletAdapterViewHolder\n*L\n78#1:223,3\n78#1:226\n78#1:227,6\n122#1:233\n*E\n"})
   public final class WalletAdapterViewHolder extends ViewHolder {
      @NotNull
      private final WalletItemBinding binding;

      public WalletAdapterViewHolder(@NotNull WalletItemBinding binding) {
         Intrinsics.checkNotNullParameter(binding, "binding");
         super((View)binding.getRoot());
         this.binding = binding;
      }

      @NotNull
      public final WalletItemBinding getBinding() {
         return this.binding;
      }

      public final void bind(int position) {
         WalletItemBinding var2 = this.binding;
         WalletAdapter var3 = WalletAdapter.this;
         int var5 = false;
         this.binding.walletNameTextView.setText((CharSequence)((WalletDataClass)var3.walletDetails.get(position)).getWalletName());
         Drawable radioButtonDrawable = var2.radioButton.getBackground();
         if (radioButtonDrawable instanceof LayerDrawable) {
            Log.d("Drawable found", "success");
            LayerDrawable layerDrawablex = (LayerDrawable)radioButtonDrawable;
            Drawable var8 = layerDrawablex.getDrawable(0);
            GradientDrawable shapeDrawablex = var8 instanceof GradientDrawable ? (GradientDrawable)var8 : null;
            Log.d("set color function", String.valueOf(var3.getSharedPreferences().getString("primaryButtonColor", "#0D8EFF")));
            if (shapeDrawablex != null) {
               shapeDrawablex.setColor(Color.parseColor(var3.getSharedPreferences().getString("primaryButtonColor", "#0D8EFF")));
            }

            var2.radioButton.setBackground((Drawable)layerDrawablex);
         } else {
            Log.d("Drawable found", "failure");
         }

         String walletName = ((WalletDataClass)var3.walletDetails.get(position)).getWalletName();
         String walletImage = ((WalletDataClass)var3.walletDetails.get(position)).getWalletImage();
         DisplayMetrics displayMetrics = var3.context.getResources().getDisplayMetrics();
         int screenWidth = displayMetrics.widthPixels;
         float averageWidthPerCharacter = var2.walletNameTextView.getPaint().measureText("A");
         Log.d("char before ellipsis", "" + screenWidth + ' ' + averageWidthPerCharacter);
         int maxCharacters = (int)((float)screenWidth / averageWidthPerCharacter);
         if (walletName.length() > maxCharacters) {
            TextView var10000 = var2.walletNameTextView;
            StringBuilder var10001 = new StringBuilder();
            String var10002 = walletName.substring(0, maxCharacters);
            Intrinsics.checkNotNullExpressionValue(var10002, "substring(...)");
            var10000.setText((CharSequence)var10001.append(var10002).append("...").toString());
         } else {
            var2.walletNameTextView.setText((CharSequence)walletName);
         }

         ImageView var28 = this.binding.walletLogo;
         Intrinsics.checkNotNullExpressionValue(var28, "walletLogo");
         ImageView $this$load_u24default$iv = var28;
         Context context$iv = $this$load_u24default$iv.getContext();
         int $i$f$createBalloon = false;
         ImageLoader imageLoader$iv = Coil.imageLoader(context$iv);
         int $i$f$load = false;
         Builder var26 = (new Builder($this$load_u24default$iv.getContext())).data(walletImage).target($this$load_u24default$iv);
         int var19 = false;
         var26.decoderFactory(WalletAdapter.WalletAdapterViewHolder::bind$lambda$5$lambda$1$lambda$0);
         var26.size(80, 80);
         ImageRequest request$iv = var26.build();
         imageLoader$iv.enqueue(request$iv);
         if (position == var3.checkedPosition) {
            Log.d("Drawable found", "failure if condition wallet");
            if (radioButtonDrawable instanceof LayerDrawable) {
               Log.d("Drawable found", "success");
               LayerDrawable layerDrawable = (LayerDrawable)radioButtonDrawable;
               Drawable var27 = layerDrawable.getDrawable(0);
               GradientDrawable shapeDrawable = var27 instanceof GradientDrawable ? (GradientDrawable)var27 : null;
               if (shapeDrawable != null) {
                  shapeDrawable.setColor(Color.parseColor(var3.getSharedPreferences().getString("primaryButtonColor", "#0D8EFF")));
               }

               var2.radioButton.setBackground((Drawable)layerDrawable);
            } else {
               Log.d("Drawable found", "failure");
            }
         } else {
            Log.d("Drawable found", "failure else condition wallet");
            var2.radioButton.setBackgroundResource(drawable.custom_radio_unchecked);
         }

         String radioButtonColor = var3.getSharedPreferences().getString("primaryButtonColor", "#0D8EFF");
         Log.d("radioButtonColor wallet", String.valueOf(radioButtonColor));
         this.binding.getRoot().setOnClickListener(WalletAdapter.WalletAdapterViewHolder::bind$lambda$5$lambda$2);
         context$iv = var3.context;
         $i$f$createBalloon = false;
         com.skydoves.balloon.Balloon.Builder var31 = new com.skydoves.balloon.Balloon.Builder(context$iv);
         var19 = false;
         var31.setArrowSize(10);
         var31.setWidthRatio(0.3F);
         var31.setHeight(65);
         var31.setArrowPosition(0.5F);
         var31.setCornerRadius(4.0F);
         var31.setAlpha(0.9F);
         var31.setText((CharSequence)walletName);
         var31.setTextColorResource(color.colorEnd);
         var31.setBackgroundColorResource(color.tooltip_bg);
         var31.setBalloonAnimation(BalloonAnimation.FADE);
         var31.setLifecycleOwner(var31.getLifecycleOwner());
         Balloon balloon = var31.build();
         this.binding.getRoot().setOnLongClickListener(WalletAdapter.WalletAdapterViewHolder::bind$lambda$5$lambda$4);
      }

      private static final Decoder bind$lambda$5$lambda$1$lambda$0(SourceResult result, Options options, ImageLoader var2) {
         Intrinsics.checkNotNullParameter(result, "result");
         Intrinsics.checkNotNullParameter(options, "options");
         Intrinsics.checkNotNullParameter(var2, "<unused var>");
         return (Decoder)(new SvgDecoder(result.getSource(), options, false, 4, (DefaultConstructorMarker)null));
      }

      private static final void bind$lambda$5$lambda$2(WalletAdapter this$0, WalletAdapter.WalletAdapterViewHolder this$1, View it) {
         Intrinsics.checkNotNullParameter(this$0, "this$0");
         Intrinsics.checkNotNullParameter(this$1, "this$1");
         Log.d("keyboard should hide now", "WalletAdapter");
         Object var10000 = this$0.context.getSystemService("input_method");
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
         InputMethodManager inputMethodManager = (InputMethodManager)var10000;
         inputMethodManager.hideSoftInputFromWindow(this$0.searchView.getWindowToken(), 0);
         int var10001 = this$1.getAdapterPosition();
         ImageView var10002 = this$1.binding.radioButton;
         Intrinsics.checkNotNullExpressionValue(var10002, "radioButton");
         this$0.handleRadioButtonClick(var10001, var10002);
         this$0.liveDataPopularItemSelectedOrNot.setValue(false);
      }

      private static final boolean bind$lambda$5$lambda$4(Balloon $balloon, WalletAdapter.WalletAdapterViewHolder this$0, View view) {
         Intrinsics.checkNotNullParameter($balloon, "$balloon");
         Intrinsics.checkNotNullParameter(this$0, "this$0");
         CardView var10001 = this$0.binding.getRoot();
         Intrinsics.checkNotNullExpressionValue(var10001, "getRoot(...)");
         Balloon.showAlignTop$default($balloon, (View)var10001, 0, 0, 6, (Object)null);
         $balloon.dismissWithDelay(2000L);
         return true;
      }
   }
}
